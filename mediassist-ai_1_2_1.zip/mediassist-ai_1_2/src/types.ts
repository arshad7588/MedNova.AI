export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role?: 'patient' | 'doctor' | 'pharmacy' | 'admin' | '';
  verified?: boolean;
  age?: number;
  gender?: string;
  allergies?: string;
  chronicDiseases?: string;
  emergencyContact?: string;
  createdAt: string;
}

export interface Reminder {
  id?: string;
  userId: string;
  medicineName: string;
  dosage: string;
  time: string;
  frequency: string;
  active: boolean;
  createdAt: string;
}

export interface HealthRecord {
  id?: string;
  userId: string;
  type: 'prescription' | 'lab_report' | 'other';
  title: string;
  content: string;
  date: string;
  imageUrl?: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
  isSystemAction?: boolean;
  actionLabel?: string;
  onAction?: () => void | Promise<void>;
}

export interface ChatSession {
  id: string;
  userId: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: string;
}

export interface Prescription {
  id?: string;
  doctorId: string;
  patientId: string;
  medicines: {
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }[];
  notes?: string;
  date: string;
}

// NEW
export interface Medicine {
  id?: string;
  name: string;
  genericName: string;
  imageUrl?: string;
  uses: string;
  dosage: string;
  sideEffects: string;
  safety: string;
  moa: string; // Mechanism of Action
  price: number;
  manufacturer: string;
  category: string;
  stock: number;
  createdAt: string;
}
