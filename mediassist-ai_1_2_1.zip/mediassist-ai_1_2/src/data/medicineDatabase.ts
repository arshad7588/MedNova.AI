export interface Medicine {
  id: string;
  genericName: string;
  brandNames: string[];
  dosageStrengths: string[];
  type: 'Tablet' | 'Capsule' | 'Syrup' | 'Injection' | 'Ointment' | 'Eye/Ear Drops' | 'Other';
  commonUsage: string;
}

export const medicineDatabase: Medicine[] = [
  {
    id: '1',
    genericName: 'Paracetamol',
    brandNames: ['Crocin', 'Calpol', 'Dolo'],
    dosageStrengths: ['500 mg', '650 mg'],
    type: 'Tablet',
    commonUsage: 'Fever, Pain relief'
  },
  {
    id: '2',
    genericName: 'Paracetamol',
    brandNames: ['Calpol Peadiatric', 'Crocin Suspension'],
    dosageStrengths: ['120 mg/5ml', '250 mg/5ml'],
    type: 'Syrup',
    commonUsage: 'Fever, Pain relief for children'
  },
  {
    id: '3',
    genericName: 'Paroxetine',
    brandNames: ['Paxil', 'Pexeva'],
    dosageStrengths: ['10 mg', '20 mg', '30 mg', '40 mg'],
    type: 'Tablet',
    commonUsage: 'Depression, Anxiety'
  },
  {
    id: '4',
    genericName: 'Amoxicillin',
    brandNames: ['Amoxil', 'Moxatag'],
    dosageStrengths: ['250 mg', '500 mg'],
    type: 'Capsule',
    commonUsage: 'Bacterial infections'
  },
  {
    id: '5',
    genericName: 'Amoxicillin + Clavulanate',
    brandNames: ['Augmentin', 'Clavam'],
    dosageStrengths: ['625 mg', '1000 mg'],
    type: 'Tablet',
    commonUsage: 'Bacterial infections'
  },
  {
    id: '6',
    genericName: 'Ambroxol',
    brandNames: ['Ambrodil', 'Mucolite'],
    dosageStrengths: ['15 mg/5ml', '30 mg/5ml'],
    type: 'Syrup',
    commonUsage: 'Cough, Mucus clearance'
  },
  {
    id: '7',
    genericName: 'Pantoprazole',
    brandNames: ['Pan', 'Pantocid'],
    dosageStrengths: ['40 mg'],
    type: 'Tablet',
    commonUsage: 'Acidity, Acid reflux'
  },
  {
    id: '8',
    genericName: 'Pantoprazole + Domperidone',
    brandNames: ['Pan-D', 'Pantocid DSR'],
    dosageStrengths: ['40 mg/30 mg'],
    type: 'Capsule',
    commonUsage: 'Acidity, Nausea'
  },
  {
    id: '9',
    genericName: 'Cetirizine',
    brandNames: ['Zyrtec', 'Cetzine'],
    dosageStrengths: ['10 mg'],
    type: 'Tablet',
    commonUsage: 'Allergies'
  },
  {
    id: '10',
    genericName: 'Diclofenac',
    brandNames: ['Voveran', 'Voltaren'],
    dosageStrengths: ['50 mg', '75 mg'],
    type: 'Injection',
    commonUsage: 'Severe pain relief'
  },
  {
    id: '11',
    genericName: 'Diclofenac',
    brandNames: ['Volini', 'Omnigel'],
    dosageStrengths: ['1%'],
    type: 'Ointment',
    commonUsage: 'Muscle pain, Joint pain'
  },
  {
    id: '12',
    genericName: 'Ciprofloxacin',
    brandNames: ['Ciplox'],
    dosageStrengths: ['0.3%'],
    type: 'Eye/Ear Drops',
    commonUsage: 'Eye or Ear bacterial infections'
  },
  {
    id: '13',
    genericName: 'Azithromycin',
    brandNames: ['Zithromax', 'Azee'],
    dosageStrengths: ['250 mg', '500 mg'],
    type: 'Tablet',
    commonUsage: 'Bacterial infections'
  },
  {
    id: '14',
    genericName: 'Metformin',
    brandNames: ['Glucophage', 'Glycomet'],
    dosageStrengths: ['500 mg', '850 mg', '1000 mg'],
    type: 'Tablet',
    commonUsage: 'Type 2 Diabetes'
  },
  {
    id: '15',
    genericName: 'Ibuprofen',
    brandNames: ['Advil', 'Motrin', 'Brufen'],
    dosageStrengths: ['200 mg', '400 mg'],
    type: 'Tablet',
    commonUsage: 'Pain relief, Fever, Inflammation'
  }
];
