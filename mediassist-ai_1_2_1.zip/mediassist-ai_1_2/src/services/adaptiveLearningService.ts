import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, getDocs, addDoc, updateDoc, doc, limit, orderBy, Timestamp, setDoc, getDoc } from 'firebase/firestore';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface LearnedPattern {
  type: string;
  value: any;
  confidence: number;
  description: string;
}

export interface UserInsights {
  userId: string;
  patterns: LearnedPattern[];
  lastAnalyzed: string;
}

export const recordInteraction = async (feature: string, action: string, metadata: any = {}) => {
  if (!auth.currentUser) return;
  
  const path = 'interactions';
  try {
    await addDoc(collection(db, path), {
      userId: auth.currentUser.uid,
      feature,
      action,
      metadata,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};

export const getLearnedContext = async (feature?: string): Promise<string> => {
  if (!auth.currentUser) return "";
  
  const path = 'userInsights';
  try {
    const docRef = doc(db, path, auth.currentUser.uid);
    const docSnap = await getDoc(docRef);
    
    if (!docSnap.exists()) return "";
    
    const data = docSnap.data() as UserInsights;
    const relevantPatterns = feature 
      ? data.patterns.filter(p => p.type.toLowerCase().includes(feature.toLowerCase()) || p.description.toLowerCase().includes(feature.toLowerCase()))
      : data.patterns;
      
    if (relevantPatterns.length === 0) return "";
    
    return `
    ADAPTIVE LEARNING INSIGHTS (Learned from user's past behavior):
    ${relevantPatterns.map(p => `- ${p.description} (Confidence: ${Math.round(p.confidence * 100)}%)`).join('\n')}
    `;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return "";
  }
};

export const analyzeUserPatterns = async () => {
  if (!auth.currentUser) return;
  
  const userId = auth.currentUser.uid;
  
  try {
    // 1. Fetch recent activity logs
    const activityRef = collection(db, 'activityHistory');
    const q = query(activityRef, where('userId', '==', userId), orderBy('timestamp', 'desc'), limit(50));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) return;
    
    const logs = querySnapshot.docs.map(doc => doc.data());
    const logsText = JSON.stringify(logs);
    
    // 2. Use AI to identify patterns
    const prompt = `
    Analyze these user activity logs for a health assistant app and identify "Adaptive Learning" patterns.
    Look for:
    - Preferred times for checking symptoms or medicines.
    - Frequently asked health concerns.
    - Tone of voice (anxious, technical, casual).
    - Adherence patterns (if mentioned).
    - Language preferences.
    
    LOGS:
    ${logsText}
    
    Return a JSON object with this structure:
    {
      "patterns": [
        { "type": "string", "value": "any", "confidence": number (0-1), "description": "Human readable description" }
      ]
    }
    `;
    
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    
    const result = JSON.parse(response.text || "{}");
    
    if (result.patterns) {
      // 3. Save insights to Firestore
      const insightsRef = doc(db, 'userInsights', userId);
      await setDoc(insightsRef, {
        userId,
        patterns: result.patterns,
        lastAnalyzed: new Date().toISOString()
      }, { merge: true });
    }
    
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'activityHistory');
  }
};
