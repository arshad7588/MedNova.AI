import { db, storage } from '../firebase';
import { 
  collection, 
  addDoc, 
  getDoc, 
  doc, 
  query, 
  where, 
  getDocs, 
  limit 
} from 'firebase/firestore';
import { ref, uploadString, getDownloadURL } from 'firebase/storage';
import { GoogleGenAI, Type } from "@google/genai";
import { Medicine } from '../types';
import levenshtein from 'js-levenshtein';

// Common medical abbreviations and short forms
const MEDICAL_SHORT_FORMS: Record<string, string> = {
  'PCM': 'Paracetamol',
  'PARA': 'Paracetamol',
  'AMOX': 'Amoxicillin',
  'CEF': 'Ceftriaxone',
  'AZI': 'Azithromycin',
  'MET': 'Metformin',
  'ATR': 'Atorvastatin',
  'AML': 'Amlodipine',
  'PAN': 'Pantoprazole',
  'OMP': 'Omeprazole',
  'DIC': 'Diclofenac',
  'IBU': 'Ibuprofen',
  'CET': 'Cetirizine',
  'LEV': 'Levocetirizine',
  'MON': 'Montelukast',
  'SAL': 'Salbutamol',
  'BUD': 'Budesonide',
  'DEX': 'Dexamethasone',
  'PRED': 'Prednisolone',
  'AUG': 'Augmentin',
  'CAL': 'Calpol',
  'DOL': 'Dolo',
  'CRO': 'Crocin',
  'CIP': 'Ciprofloxacin',
  'NOR': 'Norfloxacin',
  'OFL': 'Ofloxacin',
  'TAX': 'Taxim',
  'MONO': 'Monocef',
  'ZIFI': 'Zifi',
  'TEL': 'Telmisartan',
  'LOS': 'Losartan',
  'GLI': 'Glimepiride',
  'TEN': 'Teneligliptin',
  'VIL': 'Vildagliptin',
  'SIT': 'Sitagliptin',
};

export const expandShortForm = (text: string): string => {
  const upper = text.toUpperCase().trim();
  // Check for direct match
  if (MEDICAL_SHORT_FORMS[upper]) return MEDICAL_SHORT_FORMS[upper];
  
  // Check for partial matches or common prefixes
  for (const [short, full] of Object.entries(MEDICAL_SHORT_FORMS)) {
    if (upper.startsWith(short) && upper.length <= short.length + 2) {
      return full;
    }
  }
  
  return text;
};

let medicinesCache: Medicine[] | null = null;

export const getAllMedicines = async (): Promise<Medicine[]> => {
  if (medicinesCache) return medicinesCache;
  
  const q = collection(db, 'medicines');
  const snapshot = await getDocs(q);
  const medicines: Medicine[] = [];
  snapshot.forEach((doc) => {
    medicines.push({ id: doc.id, ...doc.data() } as Medicine);
  });
  medicinesCache = medicines;
  return medicines;
};

export const fuzzySearchMedicines = async (searchTerm: string): Promise<{ medicine: Medicine; score: number; confidence: 'High' | 'Medium' | 'Low' }[]> => {
  const expanded = expandShortForm(searchTerm);
  const medicines = await getAllMedicines();
  
  const results: { medicine: Medicine; score: number; confidence: 'High' | 'Medium' | 'Low' }[] = [];
  
  const searchLower = expanded.toLowerCase();

  medicines.forEach((med) => {
    const nameLower = med.name.toLowerCase();
    const genericLower = med.genericName.toLowerCase();

    // 1. Direct Match (Highest Priority)
    if (nameLower === searchLower || genericLower === searchLower) {
      results.push({ medicine: med, score: 1.0, confidence: 'High' });
      return;
    }

    // 2. Substring Match
    if (nameLower.includes(searchLower) || searchLower.includes(nameLower)) {
      const score = Math.min(nameLower.length, searchLower.length) / Math.max(nameLower.length, searchLower.length);
      results.push({ medicine: med, score: score * 0.9, confidence: score > 0.8 ? 'High' : 'Medium' });
      return;
    }

    // 3. Levenshtein Distance
    const nameDist = levenshtein(searchLower, nameLower);
    const genericDist = levenshtein(searchLower, genericLower);
    const bestDist = Math.min(nameDist, genericDist);
    
    const maxLen = Math.max(searchLower.length, nameLower.length);
    const similarity = 1 - (bestDist / maxLen);
    
    if (similarity > 0.4) {
      let confidence: 'High' | 'Medium' | 'Low' = 'Low';
      if (similarity > 0.85) confidence = 'High';
      else if (similarity > 0.6) confidence = 'Medium';
      
      results.push({ medicine: med, score: similarity, confidence });
    }
  });
  
  // Deduplicate by medicine ID and keep highest score
  const uniqueResults = results.reduce((acc, curr) => {
    const existing = acc.find(r => r.medicine.id === curr.medicine.id);
    if (!existing) {
      acc.push(curr);
    } else if (curr.score > existing.score) {
      acc[acc.indexOf(existing)] = curr;
    }
    return acc;
  }, [] as typeof results);

  return uniqueResults.sort((a, b) => b.score - a.score).slice(0, 3);
};

// NEW
export const uploadMedicineImage = async (base64Image: string, medicineName: string): Promise<string> => {
  const sanitizedName = medicineName.replace(/[^a-zA-Z0-9]/g, '_');
  const mimeType = base64Image.split(';')[0].split(':')[1] || "image/jpeg";
  const extension = mimeType.split('/')[1] || "jpg";
  const storageRef = ref(storage, `medicines/${sanitizedName}_${Date.now()}.${extension}`);
  const base64Data = base64Image.split(',')[1];
  await uploadString(storageRef, base64Data, 'base64', { contentType: mimeType });
  return await getDownloadURL(storageRef);
};

// NEW
export const addMedicineWithAI = async (medicineName: string, base64Image?: string): Promise<Medicine> => {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Provide detailed medical information for the medicine: ${medicineName}. 
    Return a JSON object with the following fields:
    {
      "genericName": "The scientific/generic name of the drug",
      "uses": "Detailed list of conditions it treats",
      "dosage": "Standard dosage information",
      "side_effects": "Common and serious side effects",
      "safety": "Safety warnings and precautions",
      "moa": "Mechanism of action - how it works in the body"
    }`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          genericName: { type: Type.STRING },
          uses: { type: Type.STRING },
          dosage: { type: Type.STRING },
          side_effects: { type: Type.STRING },
          safety: { type: Type.STRING },
          moa: { type: Type.STRING },
        },
        required: ["genericName", "uses", "dosage", "side_effects", "safety", "moa"]
      }
    }
  });

  const responseText = response.text || "{}";
  let aiData: any = {};
  try {
    const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
    aiData = JSON.parse(cleaned);
  } catch (e) {
    console.error("Failed to parse AI response:", e);
  }

  let imageUrl = "";
  if (base64Image) {
    try {
      imageUrl = await uploadMedicineImage(base64Image, medicineName);
    } catch (e) {
      console.error("Failed to upload image:", e);
    }
  }

  const medicine: Medicine = {
    name: medicineName,
    genericName: aiData.genericName || "Unknown",
    imageUrl,
    uses: aiData.uses || "Information not available.",
    dosage: aiData.dosage || "Information not available.",
    sideEffects: aiData.side_effects || "Information not available.",
    safety: aiData.safety || "Information not available.",
    moa: aiData.moa || "Information not available.",
    price: 0,
    manufacturer: "Unknown",
    category: "General",
    stock: 0,
    createdAt: new Date().toISOString(),
  };

  const docRef = await addDoc(collection(db, 'medicines'), medicine);
  medicinesCache = null; // Clear cache to include new medicine
  return { ...medicine, id: docRef.id };
};

// NEW
export const getMedicineDetails = async (medicineId: string): Promise<Medicine | null> => {
  const docRef = doc(db, 'medicines', medicineId);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return { id: docSnap.id, ...docSnap.data() } as Medicine;
  }
  return null;
};

// NEW
export const getAlternativesByGeneric = async (genericName: string, currentMedicineId?: string): Promise<Medicine[]> => {
  const q = query(
    collection(db, 'medicines'), 
    where('genericName', '==', genericName),
    limit(10)
  );
  const querySnapshot = await getDocs(q);
  const alternatives: Medicine[] = [];
  querySnapshot.forEach((doc) => {
    if (doc.id !== currentMedicineId) {
      alternatives.push({ id: doc.id, ...doc.data() } as Medicine);
    }
  });
  return alternatives;
};
