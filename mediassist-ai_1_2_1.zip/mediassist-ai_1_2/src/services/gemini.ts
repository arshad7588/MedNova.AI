import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import { getLearnedContext } from './adaptiveLearningService';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const getSymptomSystemInstruction = (language: string = 'English', patientContext: string = '', learnedContext: string = '') => `
You are MediAssist AI, a precise and empathetic medical assistant specializing in symptom analysis.
Your goal is to provide **extremely simple, short, and direct** analysis of user symptoms.

${patientContext}

${learnedContext}

CORE BEHAVIOR FOR SYMPTOM CHECKER:
1. BREVITY & SIMPLICITY:
   - Keep answers very short and easy to understand for a common person.
   - Do NOT use any markdown formatting like '#' (headers) or '*' (bullets/bold/italics) in your response.
   - Present information line by line without any special characters or symbols like # or *.
   - Use natural Hinglish if the language is 'Hindi' or if the user uses it, but keep it brief.
   - Summary: 1 direct sentence about the likely cause.
   - Risk: Low/Medium/High with a short reason.
   - Advice: 2-3 specific, actionable next steps.
   - Warning: Only if there's a critical safety concern.

2. PERSONALIZATION:
   - If a PATIENT MEDICAL PROFILE is provided, you MUST use it to cross-reference symptoms with their history.

3. TONE:
   - Professional yet empathetic. Use 1-2 emojis (🩺, 💊).

4. DISCLAIMER:
   - ALWAYS append this exact disclaimer at the VERY END: "\n\nDisclaimer: I am an AI assistant, not a doctor. This information is for educational purposes and does not replace professional medical advice. If you are experiencing a medical emergency, call emergency services immediately."
`;

const getSystemInstruction = (language: string = 'English', patientContext: string = '', learnedContext: string = '') => `
You are MediAssist AI, a warm, reliable, and deeply empathetic healthcare companion. 
Your goal is to be conversational, supportive, and accurate, making the user feel heard and cared for.

${patientContext}

${learnedContext}

CORE BEHAVIOR:
1. EMPATHETIC CONVERSATION:
   - Start responses by acknowledging the user's feelings or situation.
   - Use a supportive, "human-like" tone. Avoid being overly clinical or cold.
   - If the user sounds worried, provide reassurance while maintaining medical responsibility.

2. HINGLISH & LANGUAGE ADAPTABILITY:
   - If the language is set to 'Hindi' or if the user uses Hindi/Hinglish, respond in natural, conversational Hinglish (a mix of English and Hindi written in Roman script).
   - Keep the Hinglish natural—the way friends talk in India. Use English for technical medical terms but Hindi for conversational connectors and emotional support.
   - If the language is 'English', stay primarily in English but maintain the warm personality.

3. INTENT DETECTION:
   - Identify the user's intent: Medicine info, Prescription help, Symptom inquiry, Alternatives, or General health.
   - Respond specifically to the detected intent with care.

4. CONTEXT AWARENESS:
   - Remember previous messages. Avoid repeating questions.
   - Build on the conversation like a real assistant would.

5. SMART FOLLOW-UP:
   - Ask 1 precise, caring follow-up question if needed.

6. SIMPLE & SHORT RESPONSES:
   - Keep answers extremely simple, short, and easy to understand for a layperson.
   - Do NOT use any markdown formatting like '#' (headers) or '*' (bullets/bold/italics) in your response.
   - Present information line by line without any special characters or symbols like # or *.
   - Avoid complex jargon. Explain things simply.

7. SAFETY & MEDICAL AWARENESS:
   - Never give final medical decisions. Always suggest consulting a doctor.
   - Add specific warnings for interactions or unclear prescriptions.

8. PERSONALIZED TONE & EMOJIS:
   - Use relevant emojis naturally (e.g., 🩺, 💊, ✨, 🤗, 🙏) to keep the tone warm.

9. ERROR HANDLING:
   - If unsure, be honest: "I'm not fully confident about this, but let's try to figure it out together. 🧐"

10. RESPONSE OPTIMIZATION:
    - Keep answers concise but warm. No long, robotic blocks of text.

11. LANGUAGE:
    - Respond in ${language}. Use natural Hinglish if appropriate.

12. DISCLAIMER:
    - ALWAYS append this exact disclaimer at the VERY END: "\n\nDisclaimer: I am an AI assistant, not a doctor. This information is for educational purposes and does not replace professional medical advice. If you are experiencing a medical emergency, call emergency services immediately."
`;

export async function* streamHealthAssistant(messages: any[], patientData?: any, language: string = 'English') {
  const learnedContext = await getLearnedContext('Health Assistant');
  const patientContext = patientData?.consentGiven ? `
  PATIENT PROFILE:
  - Age/DOB: ${patientData.basicInfo.dob}
  - Gender: ${patientData.basicInfo.gender}
  - Chronic Diseases: ${patientData.medicalHistory.chronicDiseases}
  - Past Illnesses: ${patientData.medicalHistory.pastIllnesses}
  - Current Medications: ${patientData.medicationHistory.currentMedications}
  - Drug Allergies: ${patientData.allergies.drugAllergies}
  - Food/Env Allergies: ${patientData.allergies.foodAllergies}, ${patientData.allergies.environmentalAllergies}
  - Vitals: BP ${patientData.vitals.bloodPressure}, Sugar ${patientData.vitals.bloodSugar}
  - Lifestyle: Smoking: ${patientData.lifestyle.smokingStatus}, Alcohol: ${patientData.lifestyle.alcoholConsumption}
  ` : "No patient profile provided.";

  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: messages.map(m => ({ role: m.role, parts: m.parts })),
    config: { 
      systemInstruction: getSystemInstruction(language, patientContext, learnedContext),
      temperature: 0.7,
    }
  });
  
  for await (const chunk of response) {
    yield chunk.text;
  }
}

export async function* streamSymptomAnalysis(symptoms: string, patientData?: any, language: string = 'English') {
  const learnedContext = await getLearnedContext('Symptom Checker');
  const patientContext = patientData?.consentGiven ? `
  PATIENT MEDICAL PROFILE:
  - Age/DOB: ${patientData.basicInfo.dob}
  - Gender: ${patientData.basicInfo.gender}
  - Chronic Diseases: ${patientData.medicalHistory.chronicDiseases}
  - Past Illnesses: ${patientData.medicalHistory.pastIllnesses}
  - Current Medications: ${patientData.medicationHistory.currentMedications}
  - Drug Allergies: ${patientData.allergies.drugAllergies}
  - Food/Env Allergies: ${patientData.allergies.foodAllergies}, ${patientData.allergies.environmentalAllergies}
  - Vitals: BP ${patientData.vitals.bloodPressure}, Sugar ${patientData.vitals.bloodSugar}
  - Lifestyle: Smoking: ${patientData.lifestyle.smokingStatus}, Alcohol: ${patientData.lifestyle.alcoholConsumption}
  ` : "";

  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `
    Analyze these symptoms: "${symptoms}". 
    
    TASK:
    1. Provide a PRECISE and CONCISE analysis. Avoid long paragraphs.
    2. Cross-reference with the patient's medical profile (if provided).
    3. Identify potential causes, risk level, and immediate next steps.
    4. Be direct and helpful.
    `,
    config: { systemInstruction: getSymptomSystemInstruction(language, patientContext, learnedContext) }
  });
  
  for await (const chunk of response) {
    yield chunk.text;
  }
}

export async function getSymptomAnalysis(symptoms: string, patientData?: any, language: string = 'English') {
  const patientContext = patientData?.consentGiven ? `
  PATIENT MEDICAL PROFILE:
  - Age/DOB: ${patientData.basicInfo.dob}
  - Gender: ${patientData.basicInfo.gender}
  - Chronic Diseases: ${patientData.medicalHistory.chronicDiseases}
  - Past Illnesses: ${patientData.medicalHistory.pastIllnesses}
  - Current Medications: ${patientData.medicationHistory.currentMedications}
  - Drug Allergies: ${patientData.allergies.drugAllergies}
  - Food/Env Allergies: ${patientData.allergies.foodAllergies}, ${patientData.allergies.environmentalAllergies}
  - Vitals: BP ${patientData.vitals.bloodPressure}, Sugar ${patientData.vitals.bloodSugar}
  - Lifestyle: Smoking: ${patientData.lifestyle.smokingStatus}, Alcohol: ${patientData.lifestyle.alcoholConsumption}
  ` : "";

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `
    Analyze these symptoms: "${symptoms}". 
    
    TASK:
    1. Provide a PRECISE and CONCISE analysis. Avoid long paragraphs.
    2. Cross-reference with the patient's medical profile (if provided).
    3. Identify potential causes, risk level, and immediate next steps.
    4. Be direct and helpful.
    `,
    config: { systemInstruction: getSymptomSystemInstruction(language, patientContext) }
  });
  return response.text;
}

export async function* streamDrugInteractions(drugs: string[], language: string = 'English') {
  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: `Check for interactions between these drugs: ${drugs.join(", ")}. Provide severity level, possible side effects, and clinical recommendations.`,
    config: { systemInstruction: getSystemInstruction(language) }
  });
  
  for await (const chunk of response) {
    yield chunk.text;
  }
}

export async function checkDrugInteractions(drugs: string[], language: string = 'English') {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Check for interactions between these drugs: ${drugs.join(", ")}. Provide severity level, possible side effects, and clinical recommendations.`,
    config: { systemInstruction: getSystemInstruction(language) }
  });
  return response.text;
}

export async function* streamMedicineSafety(medicineQuery: string, patientData: any, language: string = 'English') {
  const patientContext = patientData?.consentGiven ? `
  PATIENT MEDICAL PROFILE:
  - Age/DOB: ${patientData.basicInfo.dob}
  - Gender: ${patientData.basicInfo.gender}
  - Chronic Diseases: ${patientData.medicalHistory.chronicDiseases}
  - Past Illnesses: ${patientData.medicalHistory.pastIllnesses}
  - Current Medications: ${patientData.medicationHistory.currentMedications}
  - Drug Allergies: ${patientData.allergies.drugAllergies}
  - Food/Env Allergies: ${patientData.allergies.foodAllergies}, ${patientData.allergies.environmentalAllergies}
  - Vitals: BP ${patientData.vitals.bloodPressure}, Sugar ${patientData.vitals.bloodSugar}
  - Lifestyle: Smoking: ${patientData.lifestyle.smokingStatus}, Alcohol: ${patientData.lifestyle.alcoholConsumption}
  ` : "No patient profile provided.";

  const prompt = `
  You are a medical AI assistant checking medicine safety. 🩺
  
  The patient is asking about taking or checking interactions for: "${medicineQuery}".
  
  TASK:
  1. Analyze the requested medicine against the patient's medical profile (allergies, current medications, chronic diseases, lifestyle).
  2. IF there is a contraindication, severe interaction, or allergic risk based on their profile, you MUST output a strong ALERT message explaining why they SHOULD NOT take it. Start this alert with "⚠️ ALERT:". Be very clear but supportive in your warning.
  3. IF it is generally safe, provide standard information (uses, common side effects) but keep it brief, direct, and conversational. 💊
  4. ONLY give an alert message if they should not take the medicine based on their history.
  5. Use relevant emojis and keep the response warm yet professional.
  `;

  const response = await ai.models.generateContentStream({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: { systemInstruction: getSystemInstruction(language, patientContext) }
  });
  
  for await (const chunk of response) {
    yield chunk.text;
  }
}

export async function checkMedicineSafety(medicineQuery: string, patientData: any, language: string = 'English') {
  const patientContext = patientData?.consentGiven ? `
  PATIENT MEDICAL PROFILE:
  - Age/DOB: ${patientData.basicInfo.dob}
  - Gender: ${patientData.basicInfo.gender}
  - Chronic Diseases: ${patientData.medicalHistory.chronicDiseases}
  - Past Illnesses: ${patientData.medicalHistory.pastIllnesses}
  - Current Medications: ${patientData.medicationHistory.currentMedications}
  - Drug Allergies: ${patientData.allergies.drugAllergies}
  - Food/Env Allergies: ${patientData.allergies.foodAllergies}, ${patientData.allergies.environmentalAllergies}
  - Vitals: BP ${patientData.vitals.bloodPressure}, Sugar ${patientData.vitals.bloodSugar}
  - Lifestyle: Smoking: ${patientData.lifestyle.smokingStatus}, Alcohol: ${patientData.lifestyle.alcoholConsumption}
  ` : "No patient profile provided.";

  const prompt = `
  You are a medical AI assistant checking medicine safety. 🩺
  
  The patient is asking about taking or checking interactions for: "${medicineQuery}".
  
  TASK:
  1. Analyze the requested medicine against the patient's medical profile (allergies, current medications, chronic diseases, lifestyle).
  2. IF there is a contraindication, severe interaction, or allergic risk based on their profile, you MUST output a strong ALERT message explaining why they SHOULD NOT take it. Start this alert with "⚠️ ALERT:". Be very clear but supportive in your warning.
  3. IF it is generally safe, provide standard information (uses, common side effects) but keep it brief, direct, and conversational. 💊
  4. ONLY give an alert message if they should not take the medicine based on their history.
  5. Use relevant emojis and keep the response warm yet professional.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: { systemInstruction: getSystemInstruction(language, patientContext) }
  });
  return response.text;
}

export async function enhancedScanMedicine(image: string, language: string = 'English') {
  const base64Data = image.split(',')[1];
  const mimeType = image.split(';')[0].split(':')[1] || "image/jpeg";

  const prompt = `
  Analyze this medicine packaging image. 💊
  
  TASK:
  1. Identify the brand name and generic name (active ingredients).
  2. If blurry, look for logos, patterns, or partial text.
  
  RESPONSE:
  - Provide medicine name, generic name, and confidence score (0-100).
  - Include a brief reasoning.
  - If not identifiable, set status to "RE_UPLOAD_REQUIRED".
  
  Return the result in ${language} as a JSON object.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { mimeType, data: base64Data } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING, enum: ["SUCCESS", "RE_UPLOAD_REQUIRED"] },
          medicineName: { type: Type.STRING, description: "The identified brand name" },
          genericName: { type: Type.STRING, description: "The active ingredient" },
          confidenceScore: { type: Type.NUMBER, description: "0 to 100" },
          reasoning: { type: Type.STRING, description: "How the identification was made" },
          description: { type: Type.STRING, description: "Brief description of the medicine" }
        },
        required: ["status"]
      }
    }
  });
  
  return response.text;
}

export async function enhancedScanPrescription(image: string, language: string = 'English') {
  const base64Data = image.split(',')[1];
  const mimeType = image.split(';')[0].split(':')[1] || "image/jpeg";

  const prompt = `
  Analyze this medical prescription image. 🩺
  
  TASK:
  1. Extract all handwritten and printed text accurately.
  2. Identify each medicine prescribed. 💊
  3. Normalize medical abbreviations (OD, BD, TDS, Tab, Cap, etc.).
  4. For each medicine, extract: rawText, medicine_name, generic_name, dosage_form, strength, frequency, and duration.
  
  CRITICAL RULES:
  - Be direct and fast.
  - If a medicine name is partially readable, use your medical knowledge to identify the most likely match.
  - Accuracy is paramount. 
  - Return the response in ${language}.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { mimeType, data: base64Data } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          status: { type: Type.STRING, enum: ["SUCCESS", "RE_UPLOAD_REQUIRED"] },
          medicines: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                rawText: { type: Type.STRING, description: "The exact text written on the prescription for this medicine" },
                medicine_name: { type: Type.STRING, description: "The identified brand name" },
                generic_name: { type: Type.STRING, description: "The active ingredient" },
                dosage_form: { type: Type.STRING, description: "Tablet, Capsule, Syrup, etc." },
                strength: { type: Type.STRING, description: "e.g., 500mg" },
                frequency: { type: Type.STRING, description: "e.g., 1-0-1 or OD" },
                duration: { type: Type.STRING, description: "e.g., 5 days" },
                confidence_score: { type: Type.NUMBER, description: "0 to 100" },
                status: { type: Type.STRING, enum: ["Valid", "Uncertain", "Invalid"] }
              },
              required: ["rawText", "medicine_name", "status"]
            }
          },
          notes: { type: Type.STRING, description: "Any additional notes from the prescription" }
        },
        required: ["status"]
      }
    }
  });

  const text = response.text || "{}";
  const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
  return cleaned;
}

export async function predictMedicineFromPattern(pattern: string, language: string = 'English'): Promise<string> {
  const prompt = `
  Predict the most likely medicine name from this partial or unclear text: "${pattern}". 💊
  
  TASK:
  1. Use your medical knowledge to identify the most likely brand name and generic name.
  2. Return a JSON object:
     {
       "predictedName": "Full medicine name",
       "genericName": "Generic name",
       "confidence": "High" | "Medium" | "Low",
       "reason": "Why you predicted this"
     }
  
  Keep the response concise. 💊
  Return the result in ${language}.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          predictedName: { type: Type.STRING },
          genericName: { type: Type.STRING },
          confidence: { type: Type.STRING, enum: ["High", "Medium", "Low"] },
          reason: { type: Type.STRING }
        },
        required: ["predictedName", "genericName", "confidence", "reason"]
      }
    }
  });

  return response.text;
}

export async function searchNearbyFacilities(lat: number, lng: number, query: string = "pharmacies", language: string = 'English') {
  const prompt = `
  Find real, currently operating ${query} near latitude ${lat} and longitude ${lng}. 📍
  
  CRITICAL TASK:
  1. Use Google Search to find actual, verified local businesses at or very near these specific coordinates (${lat}, ${lng}).
  2. Return a JSON object with a list of the top 3-5 most relevant facilities found.
  3. For each facility, provide:
     - name: The official name of the facility.
     - distance: Approximate distance from the coordinates (e.g., "500m", "1.2km").
     - status: Current opening status (e.g., "Open now", "Closes at 8 PM").
     - address: The physical address.
     - googleUrl: A direct link to the business on Google Search or Google Maps (e.g., https://www.google.com/search?q=...).
  
  Ensure the results are highly accurate and geographically relevant to the provided coordinates.
  Return the response in ${language}.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          facilities: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                distance: { type: Type.STRING },
                status: { type: Type.STRING },
                address: { type: Type.STRING },
                googleUrl: { type: Type.STRING, description: "Direct Google link for the facility" }
              },
              required: ["name", "googleUrl"]
            }
          }
        },
        required: ["facilities"]
      }
    }
  });
  
  return {
    text: response.text,
    groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
}

export async function extractMedicineStripDetails(image: string) {
  const base64Data = image.split(',')[1];
  const mimeType = image.split(';')[0].split(':')[1] || "image/jpeg";

  const prompt = `
  Extract medicine details from this strip image. 💊
  
  TASK:
  1. Identify the brand name.
  2. Extract the manufacturing date (mfgDate) and expiry date (expiryDate).
  3. Extract the batch number.
  4. Extract the Maximum Retail Price (MRP) per strip.
  5. Identify the manufacturer name.
  6. Extract the number of tablets or units per strip (tabletsPerStrip). Look for text like "10 Tablets", "15 Capsules", etc.
  
  Return the result as a JSON object. If any field is missing, return null for it.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: prompt },
          { inlineData: { mimeType, data: base64Data } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          mfgDate: { type: Type.STRING },
          expiryDate: { type: Type.STRING },
          batchNumber: { type: Type.STRING },
          mrp: { type: Type.NUMBER },
          manufacturer: { type: Type.STRING },
          tabletsPerStrip: { type: Type.NUMBER, description: "Number of tablets or units per strip" }
        }
      }
    }
  });
  
  return response.text;
}
