import React, { createContext, useContext, useState, useEffect } from 'react';

export interface PatientData {
  consentGiven: boolean;
  basicInfo: {
    fullName: string; dob: string; gender: string; bloodGroup: string;
    email: string; address: string; emergencyContact: string; patientId: string;
  };
  medicalHistory: {
    pastIllnesses: string; chronicDiseases: string; previousHospitalizations: string;
    surgicalHistory: string; familyHistory: string; geneticDiseases: string;
  };
  medicationHistory: { currentMedications: string; pastMedications: string; dosageAndFrequency: string; duration: string; prescribingDoctor: string; pharmacyRecords: string; };
  allergies: { drugAllergies: string; foodAllergies: string; environmentalAllergies: string; reactionDetails: string; };
  diagnostics: { reports: string; };
  prescriptions: { records: string; };
  vitals: { bloodPressure: string; heartRate: string; bodyTemperature: string; bloodSugar: string; oxygenSaturation: string; weightBmi: string; };
  vaccinations: { records: string; };
  lifestyle: { smokingStatus: string; alcoholConsumption: string; dietType: string; };
}

export const defaultPatientData: PatientData = {
  consentGiven: false,
  basicInfo: { fullName: '', dob: '', gender: '', bloodGroup: '', email: '', address: '', emergencyContact: '', patientId: '' },
  medicalHistory: { pastIllnesses: '', chronicDiseases: '', previousHospitalizations: '', surgicalHistory: '', familyHistory: '', geneticDiseases: '' },
  medicationHistory: { currentMedications: '', pastMedications: '', dosageAndFrequency: '', duration: '', prescribingDoctor: '', pharmacyRecords: '' },
  allergies: { drugAllergies: '', foodAllergies: '', environmentalAllergies: '', reactionDetails: '' },
  diagnostics: { reports: '' },
  prescriptions: { records: '' },
  vitals: { bloodPressure: '', heartRate: '', bodyTemperature: '', bloodSugar: '', oxygenSaturation: '', weightBmi: '' },
  vaccinations: { records: '' },
  lifestyle: { smokingStatus: '', alcoholConsumption: '', dietType: '' }
};

interface PatientContextType {
  patientData: PatientData;
  updatePatientData: (section: keyof PatientData, data: any) => void;
  setConsent: (given: boolean) => void;
  clearData: () => void;
}

const PatientContext = createContext<PatientContextType | undefined>(undefined);

export function PatientProvider({ children }: { children: React.ReactNode }) {
  const [patientData, setPatientData] = useState<PatientData>(() => {
    const saved = localStorage.getItem('mediassist_patient_data');
    return saved ? JSON.parse(saved) : defaultPatientData;
  });

  useEffect(() => {
    if (patientData.consentGiven) {
      localStorage.setItem('mediassist_patient_data', JSON.stringify(patientData));
    } else {
      localStorage.removeItem('mediassist_patient_data');
    }
  }, [patientData]);

  const updatePatientData = (section: keyof PatientData, data: any) => {
    setPatientData(prev => ({
      ...prev,
      [section]: typeof data === 'object' && data !== null ? { ...(prev[section] as any), ...data } : data
    }));
  };

  const setConsent = (given: boolean) => {
    setPatientData(prev => ({ ...prev, consentGiven: given }));
  };

  const clearData = () => {
    setPatientData(defaultPatientData);
    localStorage.removeItem('mediassist_patient_data');
  };

  return (
    <PatientContext.Provider value={{ patientData, updatePatientData, setConsent, clearData }}>
      {children}
    </PatientContext.Provider>
  );
}

export function usePatient() {
  const context = useContext(PatientContext);
  if (context === undefined) {
    throw new Error('usePatient must be used within a PatientProvider');
  }
  return context;
}
