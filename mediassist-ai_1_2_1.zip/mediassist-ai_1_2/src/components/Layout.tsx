import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, MessageSquare, Bell, User, Globe, Activity, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const { user, userProfile } = useAuth();
  
  const isAdmin = user?.email?.toLowerCase() === 'arshad.sheikh7588@gmail.com' || userProfile?.role === 'admin';
  const isPharmacist = userProfile?.role === 'pharmacist' || userProfile?.role === 'pharmacy' || isAdmin;
  
  const hideNav = ['/', '/login', '/signup', '/forgot-password'].includes(location.pathname);
  const isPharmacistView = location.pathname.startsWith('/pharmacist');

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col font-sans transition-colors duration-300">
      {user && !hideNav && isPharmacist && (
        <div className="bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 sticky top-0 z-50">
          <div className="max-w-lg mx-auto flex">
            <Link 
              to="/home" 
              className={`flex-1 py-4 text-center text-sm font-bold transition-all border-b-2 flex items-center justify-center gap-2 ${
                !isPharmacistView 
                  ? 'border-emerald-600 text-emerald-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <Activity size={18} />
              Patient
            </Link>
            <Link 
              to="/pharmacist" 
              className={`flex-1 py-4 text-center text-sm font-bold transition-all border-b-2 flex items-center justify-center gap-2 ${
                isPharmacistView 
                  ? 'border-blue-600 text-blue-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              <ShieldCheck size={18} />
              Pharmacist
            </Link>
          </div>
        </div>
      )}

      <main className={`flex-1 ${!hideNav ? 'pb-20 md:pb-0' : ''}`}>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {children}
        </motion.div>
      </main>

      {!hideNav && !isPharmacistView && (
        <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 px-10 py-4 flex justify-between items-center md:hidden z-50">
          <NavLink to="/home" icon={<Home size={28} />} active={location.pathname === '/home'} />
          <NavLink to="/assistant" icon={<MessageSquare size={28} />} active={location.pathname === '/assistant'} />
          <NavLink to="/global-search" icon={<Globe size={28} />} active={location.pathname === '/global-search'} />
          <NavLink to="/reminders" icon={<Bell size={28} />} active={location.pathname === '/reminders'} />
          <NavLink to="/profile" icon={<User size={28} />} active={location.pathname === '/profile'} />
        </nav>
      )}
    </div>
  );
}

function NavLink({ to, icon, active }: { to: string; icon: React.ReactNode; active: boolean }) {
  return (
    <Link to={to} className={`flex items-center justify-center transition-all ${active ? 'text-emerald-600' : 'text-slate-300 dark:text-slate-600'}`}>
      {icon}
    </Link>
  );
}
