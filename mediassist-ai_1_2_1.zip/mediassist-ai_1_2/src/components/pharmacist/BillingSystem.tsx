import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Plus, 
  Minus, 
  Trash2, 
  ShoppingCart, 
  User, 
  Phone, 
  Receipt, 
  CheckCircle2,
  X,
  CreditCard,
  Banknote,
  ArrowRight
} from 'lucide-react';
import { usePharmacy } from '../../contexts/PharmacyContext';
import { motion, AnimatePresence } from 'motion/react';

interface CartItem {
  id: string;
  name: string;
  quantity: number;
  price: number; // Price per unit (strip or tablet)
  batchNumber: string;
  sellMode: 'strip' | 'unit';
  tabletsPerStrip: number;
  mrpPerStrip: number;
}

export default function BillingSystem() {
  const { inventory, addSale } = usePharmacy();
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'card'>('cash');
  const [showSuccess, setShowSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const filteredInventory = useMemo(() => {
    if (!searchTerm) return [];
    return inventory.filter(item => 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
      item.quantity > 0
    ).slice(0, 5);
  }, [searchTerm, inventory]);

  const addToCart = (item: any) => {
    const existing = cart.find(c => c.id === item.id && c.sellMode === 'strip');
    if (existing) {
      const maxQty = Math.floor(item.quantity / item.tabletsPerStrip);
      if (existing.quantity < maxQty) {
        setCart(cart.map(c => (c.id === item.id && c.sellMode === 'strip') ? { ...c, quantity: c.quantity + 1 } : c));
      }
    } else {
      setCart([...cart, { 
        id: item.id, 
        name: item.name, 
        quantity: 1, 
        price: item.mrp,
        batchNumber: item.batchNumber,
        sellMode: 'strip',
        tabletsPerStrip: item.tabletsPerStrip,
        mrpPerStrip: item.mrp
      }]);
    }
    setSearchTerm('');
  };

  const updateCartQuantity = (id: string, sellMode: 'strip' | 'unit', delta: number) => {
    setCart(cart.map(c => {
      if (c.id === id && c.sellMode === sellMode) {
        const invItem = inventory.find(i => i.id === id);
        if (!invItem) return c;

        const newQty = Math.max(0, c.quantity + delta);
        const totalUnitsNeeded = sellMode === 'strip' ? newQty * invItem.tabletsPerStrip : newQty;
        
        // Check if enough total units available (considering other cart items for same medicine)
        const otherUnitsInCart = cart
          .filter(other => other.id === id && other.sellMode !== sellMode)
          .reduce((sum, other) => sum + (other.sellMode === 'strip' ? other.quantity * other.tabletsPerStrip : other.quantity), 0);

        if (totalUnitsNeeded + otherUnitsInCart <= invItem.quantity) {
          return { ...c, quantity: newQty };
        }
      }
      return c;
    }).filter(c => c.quantity > 0));
  };

  const toggleSellMode = (id: string, currentMode: 'strip' | 'unit') => {
    setCart(cart.map(c => {
      if (c.id === id && c.sellMode === currentMode) {
        const newMode = currentMode === 'strip' ? 'unit' : 'strip';
        const price = newMode === 'strip' ? c.mrpPerStrip : (c.mrpPerStrip / c.tabletsPerStrip);
        return { ...c, sellMode: newMode, price };
      }
      return c;
    }));
  };

  const total = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.quantity), 0), [cart]);

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setLoading(true);
    try {
      await addSale({
        customerName,
        customerPhone,
        items: cart.map(c => ({
          id: c.id,
          name: c.name,
          quantity: c.quantity,
          price: c.price,
          sellMode: c.sellMode,
          unitPrice: c.sellMode === 'unit' ? c.price : (c.price / c.tabletsPerStrip)
        })),
        total,
        paymentMethod
      });
      setShowSuccess(true);
      setCart([]);
      setCustomerName('');
      setCustomerPhone('');
    } catch (error) {
      console.error('Checkout failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Billing</h1>
          <p className="text-slate-500 text-sm">Create new sales invoice</p>
        </div>
        <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
          <Receipt size={24} />
        </div>
      </div>

      <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
        <div className="space-y-4">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <User size={18} className="text-blue-600" />
            Customer Details
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text"
                placeholder="Customer Name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="tel"
                placeholder="Phone Number"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4 pt-4 border-t border-slate-50">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <ShoppingCart size={18} className="text-blue-600" />
            Add Medicines
          </h3>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text"
              placeholder="Search medicine name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            
            <AnimatePresence>
              {searchTerm && filteredInventory.length > 0 && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-100 rounded-2xl shadow-xl z-20 overflow-hidden"
                >
                  {filteredInventory.map(item => (
                    <button
                      key={item.id}
                      onClick={() => addToCart(item)}
                      className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
                    >
                      <div className="text-left">
                        <p className="font-bold text-slate-900">{item.name}</p>
                        <p className="text-[10px] text-slate-400">
                          Stock: {Math.floor(item.quantity / item.tabletsPerStrip)} strips 
                          {item.quantity % item.tabletsPerStrip > 0 && ` + ${item.quantity % item.tabletsPerStrip} tablets`}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-blue-600">₹{item.mrp}/strip</p>
                        <p className="text-[8px] text-slate-400">₹{(item.mrp / item.tabletsPerStrip).toFixed(2)}/tablet</p>
                      </div>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <div className="space-y-3 pt-4">
          {cart.map(item => (
            <motion.div 
              layout
              key={`${item.id}-${item.sellMode}`}
              className="flex flex-col p-4 bg-slate-50 rounded-3xl space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="font-bold text-slate-900 text-sm">{item.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <button 
                      onClick={() => item.sellMode !== 'strip' && toggleSellMode(item.id, item.sellMode)}
                      className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                        item.sellMode === 'strip' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-white text-slate-500 border border-slate-100'
                      }`}
                    >
                      By Strip
                    </button>
                    <button 
                      onClick={() => item.sellMode !== 'unit' && toggleSellMode(item.id, item.sellMode)}
                      className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                        item.sellMode === 'unit' 
                          ? 'bg-blue-600 text-white' 
                          : 'bg-white text-slate-500 border border-slate-100'
                      }`}
                    >
                      By Unit
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-bold text-blue-600">
                    {item.sellMode === 'strip' 
                      ? `${item.quantity} strips` 
                      : `${item.quantity} units`}
                  </p>
                  <p className="text-[8px] text-slate-400">
                    Total: {item.sellMode === 'strip' ? item.quantity * item.tabletsPerStrip : item.quantity} tablets
                  </p>
                </div>
                <button 
                  onClick={() => updateCartQuantity(item.id, item.sellMode, -item.quantity)}
                  className="p-2 ml-2 text-slate-300 hover:text-rose-500"
                >
                  <Trash2 size={18} />
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400">
                    {item.sellMode === 'strip' ? 'Price per strip' : 'Price per tablet'}
                  </p>
                  <p className="text-xs font-bold text-slate-700">₹{item.price.toFixed(2)}</p>
                  {item.sellMode === 'strip' && (
                    <p className="text-[8px] text-slate-400 font-medium">
                      (₹{(item.price / item.tabletsPerStrip).toFixed(2)} / unit)
                    </p>
                  )}
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="flex items-center bg-white rounded-xl border border-slate-100 p-1">
                    <button 
                      onClick={() => updateCartQuantity(item.id, item.sellMode, -1)}
                      className="w-8 h-8 flex items-center justify-center text-slate-400"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="w-10 text-center font-bold text-slate-900 text-sm">{item.quantity}</span>
                    <button 
                      onClick={() => updateCartQuantity(item.id, item.sellMode, 1)}
                      className="w-8 h-8 flex items-center justify-center text-blue-600"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <div className="text-right min-w-[80px]">
                    <p className="text-[10px] text-slate-400">Subtotal</p>
                    <p className="font-bold text-slate-900">₹{(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50/50 p-2 rounded-xl text-[10px] text-blue-600 flex flex-col gap-1">
                <div className="flex items-center gap-2">
                  <ArrowRight size={12} />
                  <span>
                    {item.sellMode === 'strip' 
                      ? `Calculation: ${item.quantity} strips × ₹${item.price.toFixed(2)} = ₹${(item.price * item.quantity).toFixed(2)}`
                      : `Calculation: ${item.quantity} units × ₹${item.price.toFixed(2)} = ₹${(item.price * item.quantity).toFixed(2)}`
                    }
                  </span>
                </div>
                <div className="flex items-center gap-2 opacity-70">
                  <div className="w-3" />
                  <span>Unit Breakdown: 1 strip (₹{item.mrpPerStrip}) ÷ {item.tabletsPerStrip} tablets = ₹{(item.mrpPerStrip / item.tabletsPerStrip).toFixed(2)} per tablet</span>
                </div>
              </div>
            </motion.div>
          ))}
          {cart.length === 0 && (
            <div className="text-center py-8 bg-slate-50 rounded-[32px] border-2 border-dashed border-slate-100">
              <ShoppingCart className="mx-auto text-slate-200 mb-2" size={32} />
              <p className="text-slate-400 text-sm italic">Cart is empty</p>
            </div>
          )}
        </div>

        {cart.length > 0 && (
          <div className="pt-6 border-t border-slate-100 space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">Total Amount</span>
              <span className="text-2xl font-bold text-slate-900">₹{total.toFixed(2)}</span>
            </div>

            <div className="space-y-3">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Payment Method</p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { id: 'cash', icon: Banknote, label: 'Cash' },
                  { id: 'upi', icon: ArrowRight, label: 'UPI' },
                  { id: 'card', icon: CreditCard, label: 'Card' }
                ].map(method => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id as any)}
                    className={`flex flex-col items-center gap-2 p-3 rounded-2xl border transition-all ${
                      paymentMethod === method.id 
                        ? 'bg-blue-50 border-blue-200 text-blue-600' 
                        : 'bg-white border-slate-100 text-slate-400'
                    }`}
                  >
                    <method.icon size={20} />
                    <span className="text-[10px] font-bold">{method.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleCheckout}
              disabled={loading}
              className="w-full bg-blue-600 text-white font-bold py-5 rounded-3xl shadow-xl shadow-blue-100 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <CheckCircle2 size={20} />
                  Complete Checkout
                </>
              )}
            </button>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showSuccess && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-md"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="relative bg-white rounded-[40px] p-10 text-center max-w-sm w-full shadow-2xl"
            >
              <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 size={40} />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Sale Successful!</h2>
              <p className="text-slate-500 mb-8">The invoice has been generated and inventory updated.</p>
              <button 
                onClick={() => setShowSuccess(false)}
                className="w-full bg-slate-900 text-white font-bold py-4 rounded-2xl"
              >
                Done
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
