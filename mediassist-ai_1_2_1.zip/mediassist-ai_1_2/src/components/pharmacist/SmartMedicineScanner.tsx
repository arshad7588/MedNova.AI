import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, Loader2, CheckCircle2, AlertCircle, Package, Edit2, Save, X, RotateCcw, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { extractMedicineStripDetails } from '../../services/gemini';
import { usePharmacy } from '../../contexts/PharmacyContext';

export default function SmartMedicineScanner() {
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [extractedData, setExtractedData] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [success, setSuccess] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { addItem } = usePharmacy();

  useEffect(() => {
    if (isCameraOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [isCameraOpen]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setCameraError(null);
    } catch (err) {
      console.error('Error accessing camera:', err);
      setCameraError('Could not access camera. Please check permissions.');
      setIsCameraOpen(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
  };

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        setIsCameraOpen(false);
        handleScan(dataUrl);
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        handleScan(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async (imgData: string) => {
    setLoading(true);
    try {
      const result = await extractMedicineStripDetails(imgData);
      const data = JSON.parse(result);
      setExtractedData(data);
    } catch (error) {
      console.error('Extraction failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToInventory = async () => {
    if (!extractedData) return;
    setLoading(true);
    try {
      await addItem({
        name: extractedData.name || 'Unknown Medicine',
        quantity: quantity * (extractedData.tabletsPerStrip || 10), // Total tablets
        tabletsPerStrip: extractedData.tabletsPerStrip || 10,
        batchNumber: extractedData.batchNumber || '',
        mrp: extractedData.mrp || 0,
        mfgDate: extractedData.mfgDate || '',
        expiryDate: extractedData.expiryDate || '',
        supplier: extractedData.manufacturer || '',
        category: 'tablet', // Default
        lowStockThreshold: 10
      });
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        setExtractedData(null);
        setImage(null);
      }, 2000);
    } catch (error) {
      console.error('Failed to add to inventory:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Smart Scanner</h1>
          <p className="text-slate-500 text-sm">Scan medicine strips to auto-fill inventory</p>
        </div>
      </div>

      {!extractedData ? (
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <div 
            className="aspect-[3/4] bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center overflow-hidden relative cursor-pointer hover:bg-slate-100 transition-colors"
          >
            {isCameraOpen ? (
              <div className="absolute inset-0 bg-black">
                <video 
                  ref={videoRef} 
                  autoPlay 
                  playsInline 
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-6 px-6">
                  <button 
                    onClick={() => setIsCameraOpen(false)}
                    className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white"
                  >
                    <X size={24} />
                  </button>
                  <button 
                    onClick={captureImage}
                    className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-blue-600 shadow-xl scale-110 active:scale-95 transition-transform"
                  >
                    <div className="w-12 h-12 border-4 border-blue-600 rounded-full" />
                  </button>
                  <div className="w-12 h-12" /> {/* Spacer */}
                </div>
                <div className="absolute top-6 left-0 right-0 text-center">
                  <span className="bg-black/40 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
                    Align medicine strip within frame
                  </span>
                </div>
              </div>
            ) : image ? (
              <div className="relative w-full h-full">
                <img src={image} alt="Preview" className="w-full h-full object-cover" />
                <button 
                  onClick={() => { setImage(null); setIsCameraOpen(true); }}
                  className="absolute bottom-4 right-4 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center text-slate-600 shadow-lg"
                >
                  <RotateCcw size={20} />
                </button>
              </div>
            ) : (
              <div 
                onClick={() => setIsCameraOpen(true)}
                className="flex flex-col items-center justify-center w-full h-full"
              >
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mb-4">
                  <Camera size={32} />
                </div>
                <p className="text-slate-500 font-medium">Capture Medicine Strip</p>
                <p className="text-slate-400 text-xs mt-1">Tap to open camera</p>
              </div>
            )}
            
            {loading && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center z-10">
                <Loader2 className="w-10 h-10 text-blue-600 animate-spin mb-4" />
                <p className="text-blue-600 font-bold animate-pulse">Analyzing Strip...</p>
              </div>
            )}
          </div>

          <canvas ref={canvasRef} className="hidden" />

          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleImageUpload}
            accept="image/*"
            className="hidden" 
          />
          
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => setIsCameraOpen(true)}
              className="bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-center gap-2"
            >
              <Camera size={20} />
              Open Camera
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="bg-slate-100 text-slate-600 font-bold py-4 rounded-2xl flex items-center justify-center gap-2"
            >
              <Upload size={20} />
              Upload
            </button>
          </div>

          {cameraError && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-start gap-3">
              <AlertCircle className="text-rose-500 shrink-0" size={20} />
              <p className="text-xs text-rose-700">{cameraError}</p>
            </div>
          )}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 flex items-center gap-2">
              <CheckCircle2 className="text-emerald-500" size={20} />
              Medicine Detected
            </h3>
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="text-blue-600 text-sm font-bold flex items-center gap-1"
            >
              {isEditing ? <X size={16} /> : <Edit2 size={16} />}
              {isEditing ? 'Cancel' : 'Edit Details'}
            </button>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Medicine Name</label>
                {isEditing ? (
                  <input 
                    type="text" 
                    value={extractedData.name} 
                    onChange={(e) => setExtractedData({...extractedData, name: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                ) : (
                  <p className="text-lg font-bold text-slate-900">{extractedData.name || 'Unknown'}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Batch Number</label>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={extractedData.batchNumber} 
                      onChange={(e) => setExtractedData({...extractedData, batchNumber: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="text-sm font-medium text-slate-700">{extractedData.batchNumber || 'N/A'}</p>
                  )}
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tablets per Strip</label>
                  {isEditing ? (
                    <input 
                      type="number" 
                      value={extractedData.tabletsPerStrip || 10} 
                      onChange={(e) => setExtractedData({...extractedData, tabletsPerStrip: parseInt(e.target.value)})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="text-sm font-medium text-slate-700">{extractedData.tabletsPerStrip || 10} tablets</p>
                  )}
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">MRP (₹ per strip)</label>
                  {isEditing ? (
                    <input 
                      type="number" 
                      value={extractedData.mrp} 
                      onChange={(e) => setExtractedData({...extractedData, mrp: parseFloat(e.target.value)})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="text-sm font-medium text-slate-700">₹{extractedData.mrp || '0'}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mfg Date</label>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={extractedData.mfgDate} 
                      onChange={(e) => setExtractedData({...extractedData, mfgDate: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="text-sm font-medium text-slate-700">{extractedData.mfgDate || 'N/A'}</p>
                  )}
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expiry Date</label>
                  {isEditing ? (
                    <input 
                      type="text" 
                      value={extractedData.expiryDate} 
                      onChange={(e) => setExtractedData({...extractedData, expiryDate: e.target.value})}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  ) : (
                    <p className="text-sm font-bold text-rose-600">{extractedData.expiryDate || 'N/A'}</p>
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Manufacturer</label>
                {isEditing ? (
                  <input 
                    type="text" 
                    value={extractedData.manufacturer} 
                    onChange={(e) => setExtractedData({...extractedData, manufacturer: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                ) : (
                  <p className="text-sm font-medium text-slate-700">{extractedData.manufacturer || 'N/A'}</p>
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Number of Strips</label>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600 font-bold"
                >
                  -
                </button>
                <span className="text-xl font-bold text-slate-900 w-12 text-center">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600 font-bold"
                >
                  +
                </button>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <button 
                onClick={() => { setExtractedData(null); setImage(null); }}
                className="flex-1 bg-slate-100 text-slate-600 font-bold py-4 rounded-2xl"
              >
                Retake
              </button>
              <button 
                onClick={handleAddToInventory}
                disabled={loading}
                className="flex-[2] bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? <Loader2 className="animate-spin" size={20} /> : <Package size={20} />}
                Add to Inventory
              </button>
            </div>
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {success && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 pointer-events-none"
          >
            <div className="bg-emerald-600 text-white px-8 py-4 rounded-3xl shadow-2xl flex items-center gap-3">
              <CheckCircle2 size={24} />
              <span className="font-bold">Added to Inventory!</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
