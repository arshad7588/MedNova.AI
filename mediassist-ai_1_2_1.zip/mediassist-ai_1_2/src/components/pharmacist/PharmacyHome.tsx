import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  AlertCircle, 
  Package, 
  Clock, 
  ArrowUpRight, 
  ArrowDownRight,
  Bell
} from 'lucide-react';
import { usePharmacy } from '../../contexts/PharmacyContext';
import { motion } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';

export default function PharmacyHome() {
  const { inventory, sales } = usePharmacy();

  // Analytics logic
  const totalItems = inventory.length;
  const lowStockItems = inventory.filter(item => item.quantity <= item.lowStockThreshold);
  const expiringSoon = inventory.filter(item => {
    const expiry = new Date(item.expiryDate);
    const today = new Date();
    const diff = expiry.getTime() - today.getTime();
    return diff > 0 && diff < 30 * 24 * 60 * 60 * 1000; // 30 days
  });
  const expiredItems = inventory.filter(item => new Date(item.expiryDate) < new Date());

  const totalSales = sales.reduce((acc, sale) => acc + sale.total, 0);
  
  // Mock data for charts
  const salesData = [
    { name: 'Mon', sales: 4000 },
    { name: 'Tue', sales: 3000 },
    { name: 'Wed', sales: 2000 },
    { name: 'Thu', sales: 2780 },
    { name: 'Fri', sales: 1890 },
    { name: 'Sat', sales: 2390 },
    { name: 'Sun', sales: 3490 },
  ];

  const stats = [
    { 
      label: 'Total Inventory', 
      value: totalItems, 
      icon: Package, 
      color: 'bg-blue-50 text-blue-600',
      trend: '+12%',
      trendUp: true
    },
    { 
      label: 'Total Sales', 
      value: `₹${totalSales.toLocaleString()}`, 
      icon: TrendingUp, 
      color: 'bg-emerald-50 text-emerald-600',
      trend: '+8%',
      trendUp: true
    },
    { 
      label: 'Low Stock', 
      value: lowStockItems.length, 
      icon: AlertCircle, 
      color: 'bg-amber-50 text-amber-600',
      trend: '-2',
      trendUp: false
    },
    { 
      label: 'Expiring Soon', 
      value: expiringSoon.length, 
      icon: Clock, 
      color: 'bg-rose-50 text-rose-600',
      trend: 'Alert',
      trendUp: false
    },
  ];

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Pharmacy Dashboard</h1>
          <p className="text-slate-500 text-sm">Real-time insights for your store</p>
        </div>
        <button className="p-2 bg-white rounded-xl border border-slate-200 relative">
          <Bell size={20} className="text-slate-600" />
          {(lowStockItems.length > 0 || expiringSoon.length > 0) && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
          )}
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm"
          >
            <div className={`w-10 h-10 ${stat.color} rounded-2xl flex items-center justify-center mb-3`}>
              <stat.icon size={20} />
            </div>
            <div className="text-xl font-bold text-slate-900">{stat.value}</div>
            <div className="text-xs text-slate-500 mb-2">{stat.label}</div>
            <div className={`text-[10px] font-bold flex items-center gap-0.5 ${stat.trendUp ? 'text-emerald-600' : 'text-rose-600'}`}>
              {stat.trendUp ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
              {stat.trend}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 mb-6 flex items-center gap-2">
            <BarChart3 size={16} className="text-emerald-600" />
            Weekly Sales Revenue
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="sales" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <h3 className="text-sm font-bold text-slate-900 mb-6 flex items-center gap-2">
            <TrendingUp size={16} className="text-blue-600" />
            Stock Movement Trends
          </h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#94a3b8' }} 
                />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <h3 className="text-sm font-bold text-slate-900 mb-4">Critical Alerts</h3>
        <div className="space-y-3">
          {lowStockItems.slice(0, 3).map((item, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-amber-50 rounded-2xl border border-amber-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center text-amber-600">
                  <AlertCircle size={16} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">{item.name}</p>
                  <p className="text-[10px] text-amber-700">Low stock: {item.quantity} units left</p>
                </div>
              </div>
              <button className="text-[10px] font-bold text-amber-700 underline">Restock</button>
            </div>
          ))}
          {expiringSoon.slice(0, 3).map((item, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-rose-50 rounded-2xl border border-rose-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-rose-100 rounded-lg flex items-center justify-center text-rose-600">
                  <Clock size={16} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">{item.name}</p>
                  <p className="text-[10px] text-rose-700">Expiring on: {new Date(item.expiryDate).toLocaleDateString()}</p>
                </div>
              </div>
              <button className="text-[10px] font-bold text-rose-700 underline">Remove</button>
            </div>
          ))}
          {lowStockItems.length === 0 && expiringSoon.length === 0 && (
            <p className="text-center text-slate-400 text-xs py-4 italic">No critical alerts at the moment.</p>
          )}
        </div>
      </div>
    </div>
  );
}
