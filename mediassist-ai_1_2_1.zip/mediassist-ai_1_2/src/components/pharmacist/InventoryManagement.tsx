import React, { useState } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  AlertTriangle, 
  Edit2, 
  Trash2, 
  Filter, 
  ChevronRight,
  MoreVertical,
  X,
  Scan
} from 'lucide-react';
import { usePharmacy } from '../../contexts/PharmacyContext';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';

export default function InventoryManagement() {
  const { inventory, updateItem, deleteItem, addItem } = usePharmacy();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [editingItem, setEditingItem] = useState<any>(null);
  const [isAdding, setIsAdding] = useState(false);

  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    if (filter === 'low') return matchesSearch && item.quantity <= item.lowStockThreshold;
    if (filter === 'expired') return matchesSearch && new Date(item.expiryDate) < new Date();
    return matchesSearch;
  });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const data = Object.fromEntries(formData.entries());
    
    const tabletsPerStrip = parseInt(data.tabletsPerStrip as string) || 1;
    const numStrips = parseInt(data.numStrips as string) || 0;
    const mrp = parseFloat(data.mrp as string) || 0;
    const lowStockThreshold = parseInt(data.lowStockThreshold as string) || 10;

    const itemData = {
      name: data.name as string,
      quantity: numStrips * tabletsPerStrip, // Total tablets
      tabletsPerStrip: tabletsPerStrip,
      mrp: mrp, // Price per strip
      expiryDate: data.expiryDate as string,
      batchNumber: data.batchNumber as string,
      category: data.category as string,
      location: data.location as string,
      lowStockThreshold: lowStockThreshold
    };

    if (isAdding) {
      await addItem(itemData);
      setIsAdding(false);
    } else if (editingItem) {
      await updateItem(editingItem.id, itemData);
      setEditingItem(null);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Inventory</h1>
          <p className="text-slate-500 text-sm">Manage your medicine stock</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => navigate('/pharmacist/scan')}
            className="w-12 h-12 bg-slate-100 text-slate-600 rounded-2xl flex items-center justify-center shadow-sm"
            title="Scan Medicine"
          >
            <Scan size={24} />
          </button>
          <button 
            onClick={() => setIsAdding(true)}
            className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-100"
            title="Add Manually"
          >
            <Plus size={24} />
          </button>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {['all', 'low', 'expired'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              filter === f 
                ? 'bg-blue-600 text-white shadow-md' 
                : 'bg-white text-slate-500 border border-slate-100'
            }`}
          >
            {f === 'all' && 'All Stock'}
            {f === 'low' && 'Low Stock'}
            {f === 'expired' && 'Expired'}
          </button>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input
          type="text"
          placeholder="Search medicines..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-white border border-slate-100 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-sm"
        />
      </div>

      <div className="space-y-4">
        {filteredInventory.map((item, i) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between group"
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                item.quantity <= item.lowStockThreshold ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'
              }`}>
                <Package size={24} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900">{item.name}</h3>
                <div className="flex flex-col gap-1 mt-1">
                  <div className="flex items-center gap-2 text-[10px] font-bold">
                    <span className="text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                      {Math.floor(item.quantity / item.tabletsPerStrip)} strips 
                      {item.quantity % item.tabletsPerStrip > 0 && ` + ${item.quantity % item.tabletsPerStrip} tablets`}
                    </span>
                    {item.quantity < item.tabletsPerStrip && item.quantity > 0 && (
                      <span className="text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full flex items-center gap-1">
                        <AlertTriangle size={10} />
                        Loose Stock
                      </span>
                    )}
                    <span className="text-slate-400">Total: {item.quantity} units</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-slate-500">
                    <span>Exp: {new Date(item.expiryDate).toLocaleDateString()}</span>
                    <span>•</span>
                    <span>Loc: {item.location || 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setEditingItem(item)}
                className="p-2 text-slate-400 hover:text-blue-600 transition-colors"
              >
                <Edit2 size={18} />
              </button>
              <button 
                onClick={() => { if(confirm('Delete this item?')) deleteItem(item.id); }}
                className="p-2 text-slate-400 hover:text-rose-600 transition-colors"
              >
                <Trash2 size={18} />
              </button>
            </div>
          </motion.div>
        ))}
        {filteredInventory.length === 0 && (
          <div className="text-center py-12">
            <Package size={48} className="text-slate-200 mx-auto mb-4" />
            <p className="text-slate-400 text-sm italic">No items found in inventory.</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {(isAdding || editingItem) && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => { setIsAdding(false); setEditingItem(null); }}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-lg bg-white rounded-t-[40px] sm:rounded-[40px] p-8 shadow-2xl overflow-y-auto max-h-[90vh]"
            >
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-bold text-slate-900">
                  {isAdding ? 'Add New Medicine' : 'Edit Medicine'}
                </h2>
                <button 
                  onClick={() => { setIsAdding(false); setEditingItem(null); }}
                  className="p-2 bg-slate-50 rounded-full text-slate-400"
                >
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSave} className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Medicine Name</label>
                    <input 
                      name="name"
                      defaultValue={editingItem?.name}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tablets per Strip</label>
                      <input 
                        name="tabletsPerStrip"
                        type="number"
                        defaultValue={Number.isNaN(editingItem?.tabletsPerStrip) ? 10 : (editingItem?.tabletsPerStrip || 10)}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Number of Strips</label>
                      <input 
                        name="numStrips"
                        type="number"
                        defaultValue={editingItem ? (editingItem.tabletsPerStrip > 0 ? Math.floor(editingItem.quantity / editingItem.tabletsPerStrip) : 0) : 0}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">MRP (Price per Strip)</label>
                      <input 
                        name="mrp"
                        type="number"
                        step="0.01"
                        defaultValue={Number.isNaN(editingItem?.mrp) ? 0 : (editingItem?.mrp || 0)}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expiry Date</label>
                      <input 
                        name="expiryDate"
                        type="date"
                        defaultValue={editingItem?.expiryDate}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Batch No.</label>
                      <input 
                        name="batchNumber"
                        defaultValue={editingItem?.batchNumber}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Category</label>
                      <select 
                        name="category"
                        defaultValue={editingItem?.category || 'tablet'}
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="tablet">Tablet</option>
                        <option value="syrup">Syrup</option>
                        <option value="injection">Injection</option>
                        <option value="capsule">Capsule</option>
                        <option value="drops">Drops</option>
                        <option value="ointment">Ointment</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Storage Location</label>
                      <input 
                        name="location"
                        defaultValue={editingItem?.location}
                        placeholder="e.g. Rack A-1"
                        className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Low Stock Alert Threshold</label>
                    <input 
                      name="lowStockThreshold"
                      type="number"
                      defaultValue={Number.isNaN(editingItem?.lowStockThreshold) ? 10 : (editingItem?.lowStockThreshold || 10)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 px-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-5 rounded-3xl shadow-xl shadow-blue-100"
                >
                  {isAdding ? 'Add to Inventory' : 'Save Changes'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
