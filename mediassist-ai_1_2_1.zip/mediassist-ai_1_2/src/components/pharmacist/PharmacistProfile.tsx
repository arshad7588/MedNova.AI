import React from 'react';
import { 
  User, 
  Mail, 
  Phone, 
  Shield, 
  LogOut, 
  ChevronRight, 
  Settings, 
  HelpCircle, 
  FileText,
  Briefcase,
  Award,
  Calendar
} from 'lucide-react';
import { auth } from '../../firebase';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';

export default function PharmacistProfile() {
  const navigate = useNavigate();
  const user = auth.currentUser;

  const handleLogout = async () => {
    try {
      await auth.signOut();
      navigate('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Profile</h1>
          <p className="text-slate-500 text-sm">Manage your pharmacist account</p>
        </div>
        <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center">
          <User size={24} />
        </div>
      </div>

      <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 bg-blue-600 rounded-[24px] flex items-center justify-center text-white text-2xl font-bold">
            {user?.displayName?.[0] || 'P'}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">{user?.displayName || 'Pharmacist'}</h2>
            <p className="text-slate-500 text-sm flex items-center gap-1">
              <Shield size={14} className="text-emerald-500" />
              Verified Pharmacist
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Experience</p>
            <p className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <Briefcase size={16} className="text-blue-500" />
              8+ Years
            </p>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Joined</p>
            <p className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <Calendar size={16} className="text-emerald-500" />
              Jan 2024
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-3 text-sm text-slate-600">
            <Mail size={16} className="text-slate-400" />
            <span>{user?.email || 'pharmacist@medassist.com'}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-slate-600">
            <Phone size={16} className="text-slate-400" />
            <span>+91 98765 43210</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <Award size={18} className="text-amber-500" />
          Certifications & Documents
        </h3>
        <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
          {[
            { icon: FileText, label: 'Pharmacy License', color: 'text-blue-500', bg: 'bg-blue-50' },
            { icon: Award, label: 'Professional Degree', color: 'text-emerald-500', bg: 'bg-emerald-50' },
            { icon: Shield, label: 'Identity Verification', color: 'text-purple-500', bg: 'bg-purple-50' }
          ].map((item, i) => (
            <button
              key={i}
              className="w-full p-5 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${item.bg} ${item.color} rounded-xl flex items-center justify-center`}>
                  <item.icon size={20} />
                </div>
                <span className="font-bold text-slate-700 text-sm">{item.label}</span>
              </div>
              <ChevronRight size={18} className="text-slate-300" />
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <Settings size={18} className="text-slate-600" />
          Account Settings
        </h3>
        <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
          {[
            { icon: Settings, label: 'App Settings', color: 'text-slate-500', bg: 'bg-slate-50' },
            { icon: HelpCircle, label: 'Support & Help', color: 'text-blue-500', bg: 'bg-blue-50' }
          ].map((item, i) => (
            <button
              key={i}
              className="w-full p-5 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${item.bg} ${item.color} rounded-xl flex items-center justify-center`}>
                  <item.icon size={20} />
                </div>
                <span className="font-bold text-slate-700 text-sm">{item.label}</span>
              </div>
              <ChevronRight size={18} className="text-slate-300" />
            </button>
          ))}
          <button
            onClick={handleLogout}
            className="w-full p-5 flex items-center justify-between hover:bg-rose-50 transition-colors group"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-rose-50 text-rose-500 rounded-xl flex items-center justify-center group-hover:bg-rose-100">
                <LogOut size={20} />
              </div>
              <span className="font-bold text-rose-600 text-sm">Logout Account</span>
            </div>
            <ChevronRight size={18} className="text-rose-300" />
          </button>
        </div>
      </div>

      <div className="text-center py-6">
        <p className="text-[10px] font-bold text-slate-300 uppercase tracking-[0.2em]">MedAssist AI v1.0.0</p>
      </div>
    </div>
  );
}
