import React from 'react';
import { 
  Store, 
  Clock, 
  MapPin, 
  Phone, 
  Mail, 
  Settings, 
  ChevronRight, 
  History, 
  TrendingUp, 
  Users,
  ShieldCheck,
  Bell,
  CreditCard
} from 'lucide-react';
import { usePharmacy } from '../../contexts/PharmacyContext';
import { motion } from 'motion/react';

export default function StoreManagement() {
  const { profile, sales } = usePharmacy();

  const recentSales = sales.slice(0, 5);

  return (
    <div className="space-y-6 pb-24">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Store Overview</h1>
          <p className="text-slate-500 text-sm">Manage your pharmacy details</p>
        </div>
        <div className="w-12 h-12 bg-slate-100 text-slate-600 rounded-2xl flex items-center justify-center">
          <Store size={24} />
        </div>
      </div>

      <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-6">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 bg-blue-100 rounded-[24px] flex items-center justify-center text-blue-600">
            <Store size={40} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">{profile?.name || 'MedAssist Pharmacy'}</h2>
            <p className="text-slate-500 text-sm flex items-center gap-1">
              <MapPin size={14} />
              {profile?.address || 'Set your store address'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Opening Hours</p>
            <p className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <Clock size={16} className="text-blue-500" />
              {profile?.openingHours || '09:00 AM - 10:00 PM'}
            </p>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl space-y-1">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">License No.</p>
            <p className="text-sm font-bold text-slate-700 flex items-center gap-2">
              <ShieldCheck size={16} className="text-emerald-500" />
              {profile?.licenseNumber || 'DL-12345/2024'}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-3 text-sm text-slate-600">
            <Phone size={16} className="text-slate-400" />
            <span>{profile?.phone || '+91 98765 43210'}</span>
          </div>
          <div className="flex items-center gap-3 text-sm text-slate-600">
            <Mail size={16} className="text-slate-400" />
            <span>{profile?.email || 'contact@medassist.com'}</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <History size={18} className="text-blue-600" />
            Recent Sales
          </h3>
          <button className="text-blue-600 text-xs font-bold">View All</button>
        </div>

        <div className="space-y-3">
          {recentSales.map((sale, i) => (
            <motion.div
              key={sale.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                  <TrendingUp size={20} />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-sm">{sale.customerName || 'Walk-in Customer'}</p>
                  <p className="text-[10px] text-slate-400">{new Date(sale.timestamp).toLocaleString()}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-slate-900">₹{sale.total.toFixed(2)}</p>
                <p className="text-[10px] text-emerald-600 font-bold uppercase tracking-widest">{sale.paymentMethod}</p>
              </div>
            </motion.div>
          ))}
          {recentSales.length === 0 && (
            <div className="text-center py-8 bg-slate-50 rounded-[32px] border-2 border-dashed border-slate-100">
              <History className="mx-auto text-slate-200 mb-2" size={32} />
              <p className="text-slate-400 text-sm italic">No sales recorded yet</p>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-slate-900 flex items-center gap-2">
          <Settings size={18} className="text-slate-600" />
          Settings & Preferences
        </h3>
        <div className="bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
          {[
            { icon: Bell, label: 'Notifications', color: 'text-blue-500', bg: 'bg-blue-50' },
            { icon: CreditCard, label: 'Payment Methods', color: 'text-emerald-500', bg: 'bg-emerald-50' },
            { icon: Users, label: 'Staff Management', color: 'text-purple-500', bg: 'bg-purple-50' },
            { icon: ShieldCheck, label: 'Security & Privacy', color: 'text-amber-500', bg: 'bg-amber-50' }
          ].map((item, i) => (
            <button
              key={i}
              className="w-full p-5 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-50 last:border-0"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 ${item.bg} ${item.color} rounded-xl flex items-center justify-center`}>
                  <item.icon size={20} />
                </div>
                <span className="font-bold text-slate-700 text-sm">{item.label}</span>
              </div>
              <ChevronRight size={18} className="text-slate-300" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
