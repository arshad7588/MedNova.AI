import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface ReadMoreProps {
  text?: string;
  maxLength?: number;
  className?: string;
}

export default function ReadMore({ text, maxLength = 500, className = '' }: ReadMoreProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!text) return null;

  if (text.length <= maxLength) {
    return (
      <div className={`prose prose-sm max-w-none ${className}`}>
        <ReactMarkdown>{text}</ReactMarkdown>
      </div>
    );
  }

  const displayText = isExpanded ? text : `${text.substring(0, maxLength)}...`;

  return (
    <div className="flex flex-col">
      <div className={`prose prose-sm max-w-none ${className}`}>
        <ReactMarkdown>{displayText}</ReactMarkdown>
      </div>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="mt-2 text-emerald-600 dark:text-emerald-400 font-semibold text-sm flex items-center gap-1 self-start hover:underline"
      >
        {isExpanded ? (
          <>Show Less <ChevronUp size={16} /></>
        ) : (
          <>Read More <ChevronDown size={16} /></>
        )}
      </button>
    </div>
  );
}
