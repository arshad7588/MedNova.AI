import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  setDoc,
  Timestamp,
  orderBy,
  limit,
  increment,
  writeBatch
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { useAuth } from '../context/AuthContext';

interface InventoryItem {
  id: string;
  pharmacistId: string;
  name: string;
  quantity: number; // This will now represent total individual units (tablets)
  tabletsPerStrip: number;
  batchNumber?: string;
  mrp: number; // Price per strip
  mfgDate?: string;
  expiryDate: string;
  supplier?: string;
  category: string;
  location?: string;
  lowStockThreshold: number;
  createdAt: string;
}

interface SaleItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  sellMode: 'strip' | 'unit';
  unitPrice: number;
}

interface Sale {
  id: string;
  pharmacistId: string;
  items: SaleItem[];
  total: number;
  customerName?: string;
  customerPhone?: string;
  paymentMethod: 'cash' | 'upi' | 'card';
  timestamp: string;
}

interface PharmacyProfile {
  pharmacistId: string;
  name: string;
  licenseNumber: string;
  address: string;
  phone: string;
  email: string;
  openingHours?: string;
  settings: {
    notificationsEnabled: boolean;
    lowStockAlerts: boolean;
    expiryAlerts: boolean;
  };
}

interface PharmacyContextType {
  inventory: InventoryItem[];
  sales: Sale[];
  profile: PharmacyProfile | null;
  loading: boolean;
  addItem: (item: Omit<InventoryItem, 'id' | 'pharmacistId' | 'createdAt'>) => Promise<string>;
  updateItem: (id: string, item: Partial<InventoryItem>) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  addSale: (sale: Omit<Sale, 'id' | 'pharmacistId' | 'timestamp'>) => Promise<void>;
  updateProfile: (profile: Partial<PharmacyProfile>) => Promise<void>;
}

const PharmacyContext = createContext<PharmacyContextType | undefined>(undefined);

export function PharmacyProvider({ children }: { children: React.ReactNode }) {
  const { user, userProfile } = useAuth();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [profile, setProfile] = useState<PharmacyProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !userProfile) {
      setInventory([]);
      setSales([]);
      setProfile(null);
      if (!user) setLoading(false);
      return;
    }

    // Only start listeners if the user is a pharmacist or admin
    const isAdmin = user.email?.toLowerCase() === 'arshad.sheikh7588@gmail.com' || 
                    user.email?.toLowerCase() === 'tubebussines75@gmail.com' || 
                    userProfile.role === 'admin';
    const isPharmacist = userProfile.role === 'pharmacist' || userProfile.role === 'pharmacy' || isAdmin;
    if (!isPharmacist) {
      setInventory([]);
      setSales([]);
      setProfile(null);
      setLoading(false);
      return;
    }

    const pharmacistId = user.uid;

    // Listen to Inventory
    const inventoryQuery = query(
      collection(db, 'pharmacyInventory'),
      where('pharmacistId', '==', pharmacistId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeInventory = onSnapshot(inventoryQuery, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as InventoryItem));
      setInventory(items);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'pharmacyInventory');
    });

    // Listen to Sales
    const salesQuery = query(
      collection(db, 'pharmacySales'),
      where('pharmacistId', '==', pharmacistId),
      orderBy('timestamp', 'desc'),
      limit(100)
    );

    const unsubscribeSales = onSnapshot(salesQuery, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Sale));
      setSales(items);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'pharmacySales');
    });

    // Listen to Profile
    const profileDoc = doc(db, 'pharmacyProfiles', pharmacistId);
    const unsubscribeProfile = onSnapshot(profileDoc, (doc) => {
      if (doc.exists()) {
        setProfile(doc.data() as PharmacyProfile);
      } else {
        setProfile(null);
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `pharmacyProfiles/${pharmacistId}`);
      setLoading(false);
    });

    return () => {
      unsubscribeInventory();
      unsubscribeSales();
      unsubscribeProfile();
    };
  }, [user, userProfile]);

  const addItem = async (item: Omit<InventoryItem, 'id' | 'pharmacistId' | 'createdAt'>) => {
    if (!user) return '';
    const path = 'pharmacyInventory';
    try {
      const docRef = await addDoc(collection(db, path), {
        ...item,
        pharmacistId: user.uid,
        createdAt: new Date().toISOString()
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
      return '';
    }
  };

  const updateItem = async (id: string, item: Partial<InventoryItem>) => {
    const path = `pharmacyInventory/${id}`;
    try {
      await updateDoc(doc(db, 'pharmacyInventory', id), item);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  const deleteItem = async (id: string) => {
    const path = `pharmacyInventory/${id}`;
    try {
      await deleteDoc(doc(db, 'pharmacyInventory', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  };

  const addSale = async (sale: Omit<Sale, 'id' | 'pharmacistId' | 'timestamp'>) => {
    if (!user) return;
    const path = 'pharmacySales';
    try {
      console.log('Attempting to add sale:', {
        ...sale,
        pharmacistId: user.uid,
        timestamp: new Date().toISOString()
      });
      const batch = writeBatch(db);
      
      // Update inventory for each item
      for (const item of sale.items) {
        const itemRef = doc(db, 'pharmacyInventory', item.id);
        const invItem = inventory.find(i => i.id === item.id);
        if (invItem) {
          const deduction = item.sellMode === 'strip' 
            ? item.quantity * invItem.tabletsPerStrip 
            : item.quantity;
          
          batch.update(itemRef, {
            quantity: increment(-deduction)
          });
        }
      }

      // Add sale record
      const saleRef = doc(collection(db, path));
      batch.set(saleRef, {
        ...sale,
        pharmacistId: user.uid,
        timestamp: new Date().toISOString()
      });

      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  const updateProfile = async (newProfile: Partial<PharmacyProfile>) => {
    if (!user) return;
    const pharmacistId = user.uid;
    const path = `pharmacyProfiles/${pharmacistId}`;
    try {
      await setDoc(doc(db, 'pharmacyProfiles', pharmacistId), newProfile, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  };

  return (
    <PharmacyContext.Provider value={{ 
      inventory, 
      sales, 
      profile, 
      loading, 
      addItem, 
      updateItem, 
      deleteItem, 
      addSale, 
      updateProfile 
    }}>
      {children}
    </PharmacyContext.Provider>
  );
}

export function usePharmacy() {
  const context = useContext(PharmacyContext);
  if (context === undefined) {
    throw new Error('usePharmacy must be used within a PharmacyProvider');
  }
  return context;
}
