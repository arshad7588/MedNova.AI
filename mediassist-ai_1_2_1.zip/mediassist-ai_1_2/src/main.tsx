import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import { doc, getDocFromServer } from 'firebase/firestore';
import { db } from './firebase';
import App from './App.tsx';
import './index.css';
import { SettingsProvider } from './context/SettingsContext';
import { PatientProvider } from './context/PatientContext';
import { AuthProvider } from './context/AuthContext';

// Validate Connection to Firestore
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. The client is offline.");
    }
  }
}
testConnection();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <SettingsProvider>
        <PatientProvider>
          <App />
        </PatientProvider>
      </SettingsProvider>
    </AuthProvider>
  </StrictMode>,
);
