import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';
import { recordInteraction, analyzeUserPatterns } from '../services/adaptiveLearningService';

export const logActivity = async (featureName: string, queryOrAction: string, response?: string) => {
  if (!auth.currentUser) return;
  
  const path = 'activityHistory';
  try {
    await addDoc(collection(db, path), {
      userId: auth.currentUser.uid,
      feature: featureName,
      action: queryOrAction,
      response: response || null,
      timestamp: new Date().toISOString()
    });
    
    // Record interaction for adaptive learning
    await recordInteraction(featureName, queryOrAction, { response: !!response });
    
    // Periodically analyze patterns (e.g., every 5 activities)
    // For now, let's just trigger it to show it works
    analyzeUserPatterns();
    
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
};
