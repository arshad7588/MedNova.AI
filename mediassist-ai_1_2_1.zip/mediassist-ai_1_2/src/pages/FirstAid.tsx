import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Flame, Wind, Bone, Heart, ChevronRight, Droplet, Skull, Activity, Sun, Thermometer, Bug, Eye, Droplets, Zap, Waves, AlertTriangle, Brain, FlaskConical, Snowflake, Smile } from 'lucide-react';

export default function FirstAid() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<any | null>(null);

  const guides = [
    { id: 'burns', name: 'Burns', icon: <Flame />, color: 'text-orange-500', bg: 'bg-orange-50', content: '1. Cool the burn with running cool (not cold) water for at least 10 minutes.\n2. Remove jewelry or tight clothing before the area swells.\n3. Do not break blisters.\n4. Apply a sterile gauze bandage loosely.\n5. Take a pain reliever if needed.' },
    { id: 'choking', name: 'Choking', icon: <Wind />, color: 'text-blue-500', bg: 'bg-blue-50', content: '1. Give 5 back blows between the shoulder blades with the heel of your hand.\n2. Give 5 abdominal thrusts (Heimlich maneuver).\n3. Alternate between 5 blows and 5 thrusts until the blockage is dislodged.' },
    { id: 'fractures', name: 'Fractures', icon: <Bone />, color: 'text-slate-500', bg: 'bg-slate-50', content: '1. Stop any bleeding by applying pressure with a sterile bandage.\n2. Immobilize the injured area. Do not try to realign the bone.\n3. Apply ice packs to limit swelling and help relieve pain.\n4. Treat for shock if the person feels faint or is breathing in short, rapid breaths.' },
    { id: 'heart-attack', name: 'Heart Attack', icon: <Heart />, color: 'text-red-500', bg: 'bg-red-50', content: '1. Call emergency services immediately.\n2. Have the person sit down, rest, and try to keep calm.\n3. Loosen any tight clothing.\n4. Ask if the person takes any chest pain medication, such as nitroglycerin, and help them take it.\n5. If the person is unconscious and not breathing, begin CPR.' },
    { id: 'bleeding', name: 'Severe Bleeding', icon: <Droplet />, color: 'text-red-600', bg: 'bg-red-50', content: '1. Apply direct pressure to the wound with a clean cloth.\n2. Maintain pressure until bleeding stops.\n3. Elevate the injured area if possible.\n4. Do not remove the cloth; add more layers if blood soaks through.\n5. Seek medical help for severe bleeding.' },
    { id: 'poisoning', name: 'Poisoning', icon: <Skull />, color: 'text-purple-500', bg: 'bg-purple-50', content: '1. Call poison control or emergency services immediately.\n2. Do not induce vomiting unless instructed by a professional.\n3. If the poison is on the skin, wash with water for 15-20 minutes.\n4. If inhaled, move the person to fresh air.\n5. Keep the poison container or label for medical professionals.' },
    { id: 'seizures', name: 'Seizures', icon: <Activity />, color: 'text-indigo-500', bg: 'bg-indigo-50', content: '1. Ease the person to the floor and clear the area of hard or sharp objects.\n2. Place something soft and flat under their head.\n3. Turn them gently onto one side to keep the airway clear.\n4. Do not hold them down or try to stop their movements.\n5. Do not put anything in their mouth.\n6. Time the seizure and call for help if it lasts longer than 5 minutes.' },
    { id: 'heat-stroke', name: 'Heat Stroke', icon: <Sun />, color: 'text-yellow-500', bg: 'bg-yellow-50', content: '1. Move the person to a cooler place immediately.\n2. Call emergency services.\n3. Lower their body temperature with cool cloths or a cool bath.\n4. Do not give them anything to drink if they are not alert.\n5. Monitor their breathing and be ready to perform CPR if necessary.' },
    { id: 'hypothermia', name: 'Hypothermia', icon: <Thermometer />, color: 'text-cyan-500', bg: 'bg-cyan-50', content: '1. Move the person to a warm, dry place.\n2. Remove any wet clothing.\n3. Warm the center of their body first (chest, neck, head, groin) using an electric blanket or skin-to-skin contact.\n4. Offer warm, non-alcoholic beverages if they are conscious.\n5. Seek medical attention immediately.' },
    { id: 'snake-bite', name: 'Snake Bite', icon: <Bug />, color: 'text-emerald-600', bg: 'bg-emerald-50', content: '1. Keep the person calm and still to slow the spread of venom.\n2. Keep the bitten area below the level of the heart.\n3. Remove any tight clothing or jewelry near the bite.\n4. Do not cut the wound or attempt to suck out the venom.\n5. Do not apply ice or a tourniquet.\n6. Seek emergency medical help immediately.' },
    { id: 'insect-sting', name: 'Insect Sting', icon: <Bug />, color: 'text-lime-500', bg: 'bg-lime-50', content: '1. Remove the stinger promptly by scraping it with a straight edge (like a credit card).\n2. Wash the area with soap and water.\n3. Apply a cold pack to reduce swelling.\n4. Use hydrocortisone cream or calamine lotion for itching.\n5. Watch for signs of a severe allergic reaction (trouble breathing, swelling of face/throat) and seek immediate help if they occur.' },
    { id: 'eye-injury', name: 'Eye Injury', icon: <Eye />, color: 'text-blue-400', bg: 'bg-blue-50', content: '1. Do not rub the eye.\n2. If there is a chemical in the eye, flush it with water for at least 15 minutes.\n3. If an object is embedded, do not try to remove it.\n4. Cover both eyes with a sterile dressing to prevent eye movement.\n5. Seek professional medical care immediately.' },
    { id: 'nosebleed', name: 'Nosebleed', icon: <Droplets />, color: 'text-red-400', bg: 'bg-red-50', content: '1. Have the person sit upright and lean slightly forward.\n2. Pinch the soft part of the nose shut against the facial bones.\n3. Hold pressure for 10-15 minutes without letting go to check.\n4. Apply a cold compress to the bridge of the nose.\n5. If bleeding persists after 20 minutes, seek medical attention.' },
    { id: 'sprains', name: 'Sprains and Strains', icon: <Activity />, color: 'text-teal-500', bg: 'bg-teal-50', content: '1. Rest the injured limb.\n2. Ice the area for 20 minutes at a time, several times a day.\n3. Compress the area with an elastic wrap or bandage.\n4. Elevate the injured limb above the level of the heart if possible.\n5. Seek medical advice if there is severe pain, numbness, or inability to move the joint.' },
    { id: 'electric-shock', name: 'Electric Shock', icon: <Zap />, color: 'text-yellow-600', bg: 'bg-yellow-50', content: '1. Do not touch the person if they are still in contact with the electrical source.\n2. Turn off the source of electricity if possible, or move the source away using a dry, non-conducting object (like wood or plastic).\n3. Call emergency services.\n4. Once safe, check for breathing and a pulse. Begin CPR if necessary.\n5. Cover any burns with a sterile dressing.' },
    { id: 'drowning', name: 'Drowning', icon: <Waves />, color: 'text-cyan-600', bg: 'bg-cyan-50', content: '1. Remove the person from the water.\n2. Check for breathing. If they are not breathing, begin CPR immediately.\n3. Call for emergency medical help.\n4. Do not attempt to clear water from their lungs by abdominal thrusts.\n5. Keep the person warm with blankets to prevent hypothermia.' },
    { id: 'anaphylaxis', name: 'Allergic Reaction (Anaphylaxis)', icon: <AlertTriangle />, color: 'text-rose-500', bg: 'bg-rose-50', content: '1. Call emergency services immediately.\n2. Ask if they carry an epinephrine auto-injector (EpiPen) and help them use it if needed.\n3. Have the person lie still on their back.\n4. Loosen tight clothing and cover them with a blanket.\n5. Do not give them anything to drink.' },
    { id: 'asthma', name: 'Asthma Attack', icon: <Wind />, color: 'text-sky-500', bg: 'bg-sky-50', content: '1. Help the person sit upright and remain calm.\n2. Assist them in using their prescribed rescue inhaler.\n3. If they don\'t have an inhaler or if symptoms don\'t improve after using it, call emergency services.\n4. Keep them away from known asthma triggers.\n5. Monitor their breathing until help arrives.' },
    { id: 'concussion', name: 'Concussion / Head Injury', icon: <Brain />, color: 'text-fuchsia-500', bg: 'bg-fuchsia-50', content: '1. Have the person rest and avoid any strenuous activity.\n2. Apply a cold compress to the injury site to reduce swelling.\n3. Monitor for signs of a severe injury: vomiting, unequal pupils, confusion, or loss of consciousness.\n4. If any severe signs appear, call emergency services immediately.\n5. Do not give them pain medication without medical advice.' },
    { id: 'fainting', name: 'Fainting', icon: <Activity />, color: 'text-slate-400', bg: 'bg-slate-100', content: '1. Position the person on their back.\n2. Elevate their legs above heart level (about 12 inches) if possible.\n3. Loosen any restrictive clothing.\n4. If they don\'t regain consciousness within 1 minute, call emergency services.\n5. If they do wake up, encourage them to remain lying down for a few minutes.' },
    { id: 'chemical-burns', name: 'Chemical Burns', icon: <FlaskConical />, color: 'text-green-500', bg: 'bg-green-50', content: '1. Remove the chemical from the skin immediately. Brush off dry chemicals with a gloved hand.\n2. Flush the area with cool running water for at least 20 minutes.\n3. Remove any contaminated clothing or jewelry while flushing.\n4. Wrap the burned area loosely with a dry, sterile dressing.\n5. Seek emergency medical attention.' },
    { id: 'frostbite', name: 'Frostbite', icon: <Snowflake />, color: 'text-blue-300', bg: 'bg-blue-50', content: '1. Move the person to a warm environment.\n2. Handle the frostbitten area gently; do not rub it.\n3. Warm the affected area gradually by soaking it in warm (not hot) water.\n4. Do not use direct heat sources like heating pads or fires.\n5. Seek medical help as soon as possible.' },
    { id: 'dental', name: 'Dental Emergency', icon: <Smile />, color: 'text-pink-500', bg: 'bg-pink-50', content: '1. Handle the tooth by the crown (top), not the root.\n2. Rinse the tooth gently with water if it\'s dirty. Do not scrub it.\n3. Try to reinsert the tooth into the socket and hold it in place.\n4. If that\'s not possible, store the tooth in a container of milk or the person\'s saliva.\n5. See a dentist immediately (within 30 minutes if possible).' },
    { id: 'stroke', name: 'Stroke', icon: <Activity />, color: 'text-red-700', bg: 'bg-red-50', content: '1. Think FAST: Face drooping, Arm weakness, Speech difficulty, Time to call emergency services.\n2. Call for help immediately if you observe any of these signs.\n3. Note the time when symptoms first appeared.\n4. Do not give the person anything to eat or drink.\n5. Keep them comfortable and monitor their breathing while waiting for help.' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900">First Aid Guide</h1>
      </header>

      <div className="p-6">
        {!selected ? (
          <div className="grid gap-4">
            {guides.map(guide => (
              <button
                key={guide.id}
                onClick={() => setSelected(guide)}
                className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4 text-left hover:bg-slate-50 transition-all"
              >
                <div className={`w-12 h-12 ${guide.bg} ${guide.color} rounded-2xl flex items-center justify-center`}>
                  {React.cloneElement(guide.icon as React.ReactElement<any>, { size: 24 })}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-800">{guide.name}</h3>
                  <p className="text-slate-400 text-xs">Emergency instructions</p>
                </div>
                <ChevronRight className="text-slate-300" size={20} />
              </button>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm relative overflow-hidden">
              <div className={`absolute top-0 right-0 w-32 h-32 ${selected.bg} rounded-bl-full flex items-center justify-center p-6 opacity-50`}>
                {React.cloneElement(selected.icon as React.ReactElement<any>, { size: 48, className: selected.color })}
              </div>
              
              <h2 className={`text-3xl font-black ${selected.color} mb-6`}>{selected.name}</h2>
              
              <div className="space-y-6 relative z-10">
                {selected.content.split('\n').map((step: string, i: number) => (
                  <div key={i} className="flex gap-4">
                    <div className={`w-8 h-8 ${selected.bg} ${selected.color} rounded-full flex items-center justify-center font-bold shrink-0`}>
                      {i + 1}
                    </div>
                    <p className="text-slate-700 font-medium leading-relaxed">{step.replace(/^\d+\.\s/, '')}</p>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => setSelected(null)}
              className="w-full bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl"
            >
              Back to Guides
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
