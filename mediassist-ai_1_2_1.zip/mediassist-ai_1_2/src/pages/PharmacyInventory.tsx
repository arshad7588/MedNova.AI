import React from 'react';
import { Package, Plus, Search, AlertTriangle } from 'lucide-react';

export default function PharmacyInventory() {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Pharmacy Inventory</h1>
          <p className="text-slate-500">Manage medicine stock and supplies</p>
        </div>
        <button className="bg-emerald-600 text-white px-6 py-3 rounded-2xl font-semibold flex items-center gap-2 hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100">
          <Plus size={20} />
          Add Item
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
            <Package size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">1,248</div>
          <div className="text-sm text-slate-500">Total Items</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-red-50 rounded-xl flex items-center justify-center text-red-600 mb-4">
            <AlertTriangle size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">12</div>
          <div className="text-sm text-slate-500">Low Stock Items</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 mb-4">
            <AlertTriangle size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">5</div>
          <div className="text-sm text-slate-500">Expiring Soon</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="Search inventory..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
        </div>
        <div className="p-6">
          <p className="text-slate-500 text-center py-12">No inventory items found.</p>
        </div>
      </div>
    </div>
  );
}
