import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '../firebase';
import { Mail, Lock, LogIn, Chrome } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Get role from query params
  const queryParams = new URLSearchParams(location.search);
  const requestedRole = queryParams.get('role') || 'patient';

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      const docRef = doc(db, 'users', result.user.uid);
      const docSnap = await getDoc(docRef);
      
      if (docSnap.exists()) {
        const userData = docSnap.data();
        if (userData.role === 'pharmacist') {
          navigate('/pharmacist');
        } else {
          navigate('/home');
        }
      } else {
        // This shouldn't happen with email/password login usually, but just in case
        navigate('/home');
      }
    } catch (err: any) {
      if (err.code === 'auth/network-request-failed') {
        setError('Network error: Please check your internet connection or disable ad-blockers and try again.');
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      
      // Check if user profile exists, if not create it
      const docRef = doc(db, 'users', result.user.uid);
      const docSnap = await getDoc(docRef);
      
      if (!docSnap.exists()) {
        await setDoc(docRef, {
          uid: result.user.uid,
          name: result.user.displayName || 'User',
          email: result.user.email,
          role: requestedRole,
          createdAt: new Date().toISOString()
        });
        
        if (requestedRole === 'pharmacist') {
          navigate('/pharmacist');
        } else {
          navigate('/home');
        }
      } else {
        const userData = docSnap.data();
        if (userData.role === 'pharmacist') {
          navigate('/pharmacist');
        } else {
          navigate('/home');
        }
      }
    } catch (err: any) {
      if (err.code === 'auth/network-request-failed') {
        setError('Network error: Please check your internet connection or disable ad-blockers and try again.');
      } else {
        setError(err.message);
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col p-6">
      <div className="mt-12 mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Welcome Back</h2>
        <p className="text-slate-500">Log in to your health portal</p>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 text-sm flex flex-col gap-2">
          <span>{error}</span>
          {error.includes('Network error') && (
            <button 
              onClick={() => window.location.reload()} 
              className="text-red-700 font-bold underline text-left"
            >
              Click here to refresh the page
            </button>
          )}
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-4">
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="email"
            placeholder="Email Address"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="password"
            placeholder="Password"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <div className="text-right">
          <Link to="/forgot-password" title="Forgot Password?" className="text-emerald-600 font-medium">Forgot Password?</Link>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-emerald-600 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
        >
          {loading ? 'Logging in...' : <><LogIn size={20} /> Log In</>}
        </button>
      </form>

      <div className="my-8 flex items-center gap-4 text-slate-400">
        <div className="flex-1 h-px bg-slate-200"></div>
        <span className="text-sm">OR</span>
        <div className="flex-1 h-px bg-slate-200"></div>
      </div>

      <button
        onClick={handleGoogleLogin}
        className="w-full bg-white border border-slate-200 text-slate-700 font-semibold py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-50 transition-all"
      >
        <Chrome size={20} className="text-red-500" />
        Continue with Google
      </button>

      <p className="mt-auto text-center text-slate-500 pb-6">
        Don't have an account? <Link to="/signup" className="text-emerald-600 font-bold">Sign Up</Link>
      </p>
    </div>
  );
}
