import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Info, AlertTriangle, ShieldCheck, Activity, Layers, Package, Bell, MessageSquare, Send, Sparkles, Thermometer, ShoppingCart, Star, Truck, Shield, RotateCcw } from 'lucide-react';
import { Medicine, ChatMessage } from '../types';
import { getMedicineDetails, getAlternativesByGeneric } from '../services/medicineService';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'motion/react';

export default function MedicineDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [medicine, setMedicine] = useState<Medicine | null>(null);
  const [alternatives, setAlternatives] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  
  // AI Expert State
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!id) return;
      setLoading(true);
      try {
        const details = await getMedicineDetails(id);
        if (details) {
          setMedicine(details);
          const alts = await getAlternativesByGeneric(details.genericName, id);
          setAlternatives(alts);
          
          // Initial AI Message
          setChatMessages([
            {
              role: 'model',
              parts: [{ text: `Hello! I'm your AI expert for **${details.name}**. You can ask me anything about its interactions, specific precautions, or what to do if you miss a dose.` }]
            }
          ]);
        }
      } catch (error) {
        console.error("Error fetching medicine details:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !medicine) return;

    const userMsg: ChatMessage = { role: 'user', parts: [{ text: input }] };
    setChatMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      const chat = ai.chats.create({
        model: "gemini-3-flash-preview",
        config: {
          systemInstruction: `You are a specialized medical AI expert for the medicine: ${medicine.name} (${medicine.genericName}). 
          Context about this medicine:
          - Uses: ${medicine.uses}
          - Dosage: ${medicine.dosage}
          - Side Effects: ${medicine.sideEffects}
          - Safety: ${medicine.safety}
          
          Provide accurate, extremely simple, and short information. 
          Do NOT use any markdown formatting like '#' or '*' in your response.
          Present information line by line without any special characters.
          Always include a disclaimer that you are an AI and the user should consult their doctor.`,
        },
      });

      const responseStream = await chat.sendMessageStream({ message: input });
      let fullResponse = '';
      let displayedLines: string[] = [];
      let currentBuffer = '';
      
      // Add placeholder
      setChatMessages(prev => [...prev, { role: 'model', parts: [{ text: '' }] }]);

      for await (const chunk of responseStream) {
        const text = chunk.text || "";
        fullResponse += text;
        currentBuffer += text;

        if (currentBuffer.includes('\n')) {
          const lines = currentBuffer.split('\n');
          const completeLines = lines.slice(0, -1);
          displayedLines = [...displayedLines, ...completeLines];
          currentBuffer = lines[lines.length - 1];
          
          const textToShow = displayedLines.join('\n') + (currentBuffer ? '\n' + currentBuffer : '');
          setChatMessages(prev => {
            const newMsgs = [...prev];
            newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: textToShow }] };
            return newMsgs;
          });
          
          // Professional line-by-line delay
          await new Promise(resolve => setTimeout(resolve, 150));
        } else {
          const textToShow = displayedLines.join('\n') + (displayedLines.length > 0 ? '\n' : '') + currentBuffer;
          setChatMessages(prev => {
            const newMsgs = [...prev];
            newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: textToShow }] };
            return newMsgs;
          });
        }
      }
      
      // Final update
      setChatMessages(prev => {
        const newMsgs = [...prev];
        newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: fullResponse }] };
        return newMsgs;
      });
    } catch (error: any) {
      console.error("AI Error:", error);
      let errorMessage = "Sorry, I'm having trouble connecting right now. Please try again later. 💊";
      
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 'PERMISSION_DENIED' || error?.status === 403) {
        errorMessage = "I don't have permission to access the AI service. This usually means the API key is invalid or lacks permissions. Please check your settings.";
      } else if (error?.message?.includes('quota') || error?.message?.includes('limit')) {
        errorMessage = "The AI service is currently at its limit. Please try again in a few minutes. 💊";
      }

      setChatMessages(prev => [...prev, { role: 'model', parts: [{ text: errorMessage }] }]);
    } finally {
      setIsTyping(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!medicine) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-white p-6">
        <p className="text-slate-500 mb-4 font-bold">Medicine not found.</p>
        <button onClick={() => navigate(-1)} className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-bold">Go Back</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pb-40 font-sans">
      {/* Dynamic Header */}
      <header className="bg-white/80 backdrop-blur-xl p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)} 
            className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-50 transition-colors text-slate-600"
          >
            <ArrowLeft size={22} />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-black text-slate-900 truncate text-base tracking-tight m-0 leading-none">{medicine.name}</h1>
            <p className="text-[9px] uppercase tracking-[0.2em] text-emerald-600 font-black mt-1">Medicine Details</p>
          </div>
        </div>
        <button 
          onClick={() => navigate('/reminders')}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-50 text-slate-600 transition-colors"
        >
          <Bell size={22} />
        </button>
      </header>

      <div className="max-w-2xl mx-auto">
        {/* Product Hero Section */}
        <div className="bg-slate-50 p-10 flex flex-col items-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-100/50 rounded-full -mr-32 -mt-32 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-blue-100/50 rounded-full -ml-24 -mb-24 blur-3xl" />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative z-10 w-full max-w-xs aspect-square bg-white rounded-[3rem] shadow-2xl shadow-slate-200 flex items-center justify-center p-8 border border-white"
          >
            {medicine.imageUrl ? (
              <img src={medicine.imageUrl} alt={medicine.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            ) : (
              <Package size={120} className="text-slate-100" />
            )}
            
            <div className="absolute -top-4 -right-4 bg-white px-4 py-2 rounded-2xl shadow-lg border border-slate-50 flex items-center gap-2">
              <Star size={16} className="text-amber-400 fill-amber-400" />
              <span className="text-sm font-black text-slate-900">4.8</span>
              <span className="text-[10px] text-slate-400 font-bold">(1.2k)</span>
            </div>
          </motion.div>
        </div>

        {/* Product Info Section */}
        <div className="p-8 space-y-8 -mt-8 bg-white rounded-t-[3rem] relative z-20 shadow-[0_-20px_40px_rgba(0,0,0,0.02)]">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest">
                {medicine.category || 'Medicine'}
              </span>
              <span className="text-xs text-slate-400 font-bold">ID: MED-{medicine.id?.slice(-6).toUpperCase()}</span>
            </div>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight leading-tight">{medicine.name}</h2>
            <p className="text-emerald-600 font-black text-xs uppercase tracking-[0.2em]">{medicine.genericName}</p>
            <p className="text-slate-400 text-sm font-bold">Manufacturer: <span className="text-slate-900">{medicine.manufacturer || 'Generic Pharma'}</span></p>
          </div>

          <div className="flex items-end gap-4">
            <div className="space-y-1">
              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Typical Dosage</p>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-black text-slate-900">{medicine.dosage || 'Consult Doctor'}</span>
              </div>
            </div>
          </div>

          {/* Trust Badges Removed */}

          {/* Detailed Info Tabs (Simplified as sections) */}
          <div className="space-y-8">
            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-lg flex items-center justify-center">
                  <Activity size={16} />
                </div>
                <h3 className="font-black text-slate-900 text-sm uppercase tracking-widest">Product Overview</h3>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">{medicine.uses}</p>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
                  <Info size={16} />
                </div>
                <h3 className="font-black text-slate-900 text-sm uppercase tracking-widest">Usage & Dosage</h3>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">{medicine.dosage}</p>
            </section>

            <section className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-red-50 text-red-600 rounded-lg flex items-center justify-center">
                  <AlertTriangle size={16} />
                </div>
                <h3 className="font-black text-slate-900 text-sm uppercase tracking-widest">Side Effects</h3>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed font-medium">{medicine.sideEffects}</p>
            </section>
          </div>

          {/* AI Medicine Expert */}
          <section className="bg-slate-900 rounded-[3rem] p-8 text-white overflow-hidden relative shadow-2xl shadow-slate-200">
            <div className="absolute top-0 right-0 p-12 opacity-10">
              <Sparkles size={160} />
            </div>
            
            <div className="relative z-10 space-y-8">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-emerald-500 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <MessageSquare size={28} />
                </div>
                <div>
                  <h3 className="font-black text-xl m-0 tracking-tight">AI Clinical Expert</h3>
                  <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em]">Verified Medical AI</p>
                </div>
              </div>

              <div className="bg-slate-800/40 backdrop-blur-sm rounded-[2rem] p-6 max-h-[300px] overflow-y-auto space-y-6 custom-scrollbar border border-white/5">
                {chatMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[90%] p-4 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'user' 
                        ? 'bg-emerald-600 text-white rounded-tr-none shadow-lg shadow-emerald-900/20' 
                        : 'bg-slate-700/80 text-slate-100 rounded-tl-none border border-white/5'
                    }`}>
                      {msg.parts[0].text}
                    </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="bg-slate-700/80 text-emerald-400 p-4 rounded-2xl rounded-tl-none text-[10px] font-black animate-pulse uppercase tracking-widest">
                      Analyzing medical data...
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              <form onSubmit={handleSendMessage} className="flex gap-3">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about safety, interactions..."
                  className="flex-1 bg-slate-800/80 border-none rounded-2xl px-6 py-4 text-sm focus:ring-2 focus:ring-emerald-500 placeholder:text-slate-500"
                />
                <button 
                  type="submit"
                  disabled={isTyping || !input.trim()}
                  className="bg-emerald-500 text-white w-14 h-14 rounded-2xl flex items-center justify-center disabled:opacity-50 transition-transform active:scale-90 shadow-lg shadow-emerald-500/20"
                >
                  <Send size={24} />
                </button>
              </form>
            </div>
          </section>

          {/* Alternatives */}
          {alternatives.length > 0 && (
            <section className="space-y-6 pt-4">
              <div className="flex items-center justify-between px-2">
                <h3 className="font-black text-slate-900 text-xl m-0 tracking-tight">Similar Substitutes</h3>
                <span className="text-[10px] text-emerald-600 font-black uppercase tracking-[0.2em]">Medical Alternatives</span>
              </div>
              <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
                {alternatives.map((alt) => (
                  <button
                    key={alt.id}
                    onClick={() => navigate(`/medicine/${alt.id}`)}
                    className="min-w-[160px] bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col items-center gap-3 text-center hover:border-emerald-500 transition-all hover:shadow-md group"
                  >
                    <div className="w-24 h-24 bg-slate-50 rounded-2xl flex items-center justify-center shrink-0 group-hover:bg-emerald-50 transition-colors">
                      {alt.imageUrl ? (
                        <img src={alt.imageUrl} alt={alt.name} className="w-full h-full object-contain p-2" referrerPolicy="no-referrer" />
                      ) : (
                        <Package size={32} className="text-slate-200" />
                      )}
                    </div>
                    <div className="w-full">
                      <h4 className="font-bold text-slate-900 truncate m-0 text-xs">{alt.name}</h4>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">{alt.genericName || 'Alternative'}</p>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-2xl border-t border-slate-100 p-6 z-50 flex items-center gap-4">
        <button 
          onClick={() => navigate('/reminders')}
          className="flex-1 bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-2xl shadow-emerald-100 flex items-center justify-center gap-3 active:scale-95 transition-transform"
        >
          <Bell size={20} />
          Set Medication Reminder
        </button>
      </div>
    </div>
  );
}
