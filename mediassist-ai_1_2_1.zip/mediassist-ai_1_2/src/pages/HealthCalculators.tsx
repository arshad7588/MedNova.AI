import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calculator, Heart, Activity, Droplets } from 'lucide-react';

export default function HealthCalculators() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'bmi' | 'heart' | 'diabetes'>('bmi');

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900">Health Calculators</h1>
      </header>

      <div className="p-6">
        <div className="flex bg-white p-1 rounded-2xl border border-slate-100 shadow-sm mb-8">
          <button 
            onClick={() => setActiveTab('bmi')}
            className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'bmi' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
          >
            BMI
          </button>
          <button 
            onClick={() => setActiveTab('heart')}
            className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'heart' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
          >
            Heart Rate
          </button>
          <button 
            onClick={() => setActiveTab('diabetes')}
            className={`flex-1 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === 'diabetes' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
          >
            Diabetes
          </button>
        </div>

        {activeTab === 'bmi' && <BMICalculator />}
        {activeTab === 'heart' && <HeartRateCalculator />}
        {activeTab === 'diabetes' && <DiabetesRisk />}
      </div>
    </div>
  );
}

function GaugeChart({ value, min, max, zones, label }: { value: number, min: number, max: number, zones: { color: string, length: number, gap: number }[], label: string }) {
  const percentage = Math.min(Math.max((value - min) / (max - min), 0), 1);
  const angle = percentage * 180;

  return (
    <div className="flex flex-col items-center my-6">
      <svg viewBox="0 0 100 55" className="w-64 h-36 overflow-visible">
        {zones.map((zone, idx) => (
          <path 
            key={idx}
            d="M 10 50 A 40 40 0 0 1 90 50" 
            fill="none" 
            stroke={zone.color} 
            strokeWidth="10" 
            strokeDasharray={`${zone.gap === 0 ? zone.length : `0 ${zone.gap} ${zone.length}`} 1000`} 
            strokeLinecap="butt" 
          />
        ))}
        
        {/* Needle */}
        <g transform={`translate(50, 50) rotate(${angle - 90})`} className="transition-transform duration-1000 ease-out">
          <polygon points="-2,0 2,0 0,-38" fill="#1e293b" />
          <circle cx="0" cy="0" r="4" fill="#1e293b" />
        </g>
      </svg>
      <div className="mt-2 text-center">
        <span className="text-3xl font-black text-slate-900">{value}</span>
        <p className="text-sm font-bold text-slate-500">{label}</p>
      </div>
    </div>
  );
}

function BMICalculator() {
  const [gender, setGender] = useState('male');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [bmi, setBmi] = useState<number | null>(null);

  const calculate = () => {
    const w = parseFloat(weight);
    const h = parseFloat(height) / 100;
    if (w && h) {
      setBmi(parseFloat((w / (h * h)).toFixed(1)));
    }
  };

  const getStatus = (val: number) => {
    if (val < 18.5) return { label: 'Underweight', color: 'text-red-500' };
    if (val < 25) return { label: 'Normal', color: 'text-emerald-500' };
    if (val < 30) return { label: 'Overweight', color: 'text-orange-500' };
    return { label: 'Obese', color: 'text-red-500' };
  };

  // BMI Gauge Zones (Total length 125.66, Range 10-40)
  const bmiZones = [
    { color: '#ef4444', length: 35.6, gap: 0 }, // Underweight (<18.5)
    { color: '#10b981', length: 27.2, gap: 35.6 }, // Normal (18.5-24.9)
    { color: '#f97316', length: 20.9, gap: 62.8 }, // Overweight (25-29.9)
    { color: '#ef4444', length: 41.9, gap: 83.7 }, // Obese (>=30)
  ];

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
      <div className="flex items-center gap-3 text-emerald-600">
        <Activity size={24} />
        <h2 className="font-bold text-lg">BMI Calculator</h2>
      </div>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Gender</label>
            <select className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Age</label>
            <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={age} onChange={(e) => setAge(e.target.value)} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Weight (kg)</label>
            <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={weight} onChange={(e) => setWeight(e.target.value)} />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Height (cm)</label>
            <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={height} onChange={(e) => setHeight(e.target.value)} />
          </div>
        </div>
        <button onClick={calculate} className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl">Calculate BMI</button>
      </div>

      {bmi && (
        <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
          <GaugeChart value={bmi} min={10} max={40} zones={bmiZones} label="BMI" />
          <div className="text-center mt-4">
            <p className={`text-xl font-black ${getStatus(bmi).color}`}>{getStatus(bmi).label}</p>
            <p className="text-slate-500 text-sm mt-2">
              {bmi < 18.5 && "You are underweight. Consider consulting a doctor or dietitian."}
              {bmi >= 18.5 && bmi < 25 && "You have a normal body weight. Great job!"}
              {bmi >= 25 && bmi < 30 && "You are overweight. Regular exercise and a balanced diet can help."}
              {bmi >= 30 && "You are in the obese category. It is highly recommended to consult a healthcare provider."}
            </p>
          </div>

          {bmi && (
            <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/30">
                <h4 className="text-emerald-700 dark:text-emerald-400 font-bold text-sm mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                  {bmi >= 18.5 && bmi < 25 ? "How to maintain" : "What to do"}
                </h4>
                <ul className="text-xs text-emerald-800 dark:text-emerald-300 space-y-1 list-disc pl-4">
                  {bmi < 18.5 ? (
                    <>
                      <li>Eat 5-6 smaller, nutrient-dense meals daily.</li>
                      <li>Add healthy fats like nuts and avocados.</li>
                      <li>Incorporate protein-rich snacks between meals.</li>
                      <li>Focus on strength training to build muscle.</li>
                    </>
                  ) : bmi < 25 ? (
                    <>
                      <li>Keep up the balanced diet and portion control.</li>
                      <li>Stay active with 30 mins of daily movement.</li>
                      <li>Prioritize consistent sleep and hydration.</li>
                      <li>Continue regular health check-ups annually.</li>
                    </>
                  ) : (
                    <>
                      <li>Practice portion control and mindful eating.</li>
                      <li>Increase daily steps and physical activity.</li>
                      <li>Focus on high-fiber, whole-food choices.</li>
                      <li>Set realistic, sustainable weight loss goals.</li>
                    </>
                  )}
                </ul>
              </div>
              <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-2xl border border-red-100 dark:border-red-900/30">
                <h4 className="text-red-700 dark:text-red-400 font-bold text-sm mb-2 flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  What to avoid
                </h4>
                <ul className="text-xs text-red-800 dark:text-red-300 space-y-1 list-disc pl-4">
                  {bmi < 18.5 ? (
                    <>
                      <li>Don't skip meals or fast for long periods.</li>
                      <li>Don't fill up on water right before eating.</li>
                      <li>Don't rely on empty-calorie junk foods.</li>
                      <li>Don't over-exercise without enough calories.</li>
                    </>
                  ) : bmi < 25 ? (
                    <>
                      <li>Don't become sedentary or stop exercising.</li>
                      <li>Don't ignore small weight fluctuations.</li>
                      <li>Don't start restrictive diets unnecessarily.</li>
                      <li>Don't neglect muscle-strengthening activities.</li>
                    </>
                  ) : (
                    <>
                      <li>Don't follow extreme or "crash" diets.</li>
                      <li>Don't drink liquid calories (sodas, juices).</li>
                      <li>Don't eat late at night or while distracted.</li>
                      <li>Don't get discouraged by slow progress.</li>
                    </>
                  )}
                </ul>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function HeartRateCalculator() {
  const [gender, setGender] = useState('male');
  const [age, setAge] = useState('');
  const [resting, setResting] = useState('');
  const [result, setResult] = useState<any>(null);

  const calculate = () => {
    const a = parseInt(age);
    const r = parseInt(resting);
    if (a && r) {
      const max = 220 - a;
      const targetMin = Math.round(max * 0.5);
      const targetMax = Math.round(max * 0.85);
      setResult({ max, targetMin, targetMax, resting: r });
    }
  };

  // Resting HR Zones (Total length 125.66, Range 40-140)
  // <60 (Low): 20/100 -> 25.1
  // 60-100 (Normal): 40/100 -> 50.3
  // >100 (High): 40/100 -> 50.3
  const hrZones = [
    { color: '#3b82f6', length: 25.1, gap: 0 }, // Low (<60)
    { color: '#10b981', length: 50.3, gap: 25.1 }, // Normal (60-100)
    { color: '#ef4444', length: 50.3, gap: 75.4 }, // High (>100)
  ];

  const getStatus = (val: number) => {
    if (val < 60) return { label: 'Low (Bradycardia)', color: 'text-blue-500' };
    if (val <= 100) return { label: 'Normal', color: 'text-emerald-500' };
    return { label: 'High (Tachycardia)', color: 'text-red-500' };
  };

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
      <div className="flex items-center gap-3 text-red-500">
        <Heart size={24} />
        <h2 className="font-bold text-lg">Heart Rate Zones</h2>
      </div>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Gender</label>
            <select className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Age</label>
            <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={age} onChange={(e) => setAge(e.target.value)} />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase">Resting Heart Rate (bpm)</label>
          <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={resting} onChange={(e) => setResting(e.target.value)} />
        </div>
        <button onClick={calculate} className="w-full bg-red-500 text-white font-bold py-4 rounded-2xl">Calculate Zones</button>
      </div>

      {result && (
        <div className="space-y-4">
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100">
            <GaugeChart value={result.resting} min={40} max={140} zones={hrZones} label="Resting HR" />
            <div className="text-center mt-4">
              <p className={`text-xl font-black ${getStatus(result.resting).color}`}>{getStatus(result.resting).label}</p>
            </div>
          </div>
          
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center">
            <span className="text-slate-500 font-medium">Max Heart Rate</span>
            <span className="text-xl font-bold text-slate-900">{result.max} bpm</span>
          </div>
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex justify-between items-center">
            <span className="text-emerald-700 font-medium">Target Zone (50-85%)</span>
            <span className="text-xl font-bold text-emerald-700">{result.targetMin} - {result.targetMax} bpm</span>
          </div>
        </div>
      )}
    </div>
  );
}

function DiabetesRisk() {
  const [gender, setGender] = useState('male');
  const [age, setAge] = useState('');
  const [bmi, setBmi] = useState('');
  const [factors, setFactors] = useState({
    familyHistory: false,
    highBP: false,
    inactive: false,
  });
  const [riskScore, setRiskScore] = useState<number | null>(null);

  const calculate = () => {
    let score = 0;
    const a = parseInt(age);
    const b = parseFloat(bmi);
    
    if (a >= 45 && a <= 54) score += 2;
    if (a >= 55 && a <= 64) score += 3;
    if (a >= 65) score += 4;
    
    if (b >= 25 && b < 30) score += 1;
    if (b >= 30) score += 3;
    
    if (factors.familyHistory) score += 3;
    if (factors.highBP) score += 2;
    if (factors.inactive) score += 1;
    
    setRiskScore(score);
  };

  const getStatus = (val: number) => {
    if (val <= 3) return { label: 'Low Risk', color: 'text-emerald-500' };
    if (val <= 6) return { label: 'Moderate Risk', color: 'text-orange-500' };
    return { label: 'High Risk', color: 'text-red-500' };
  };

  // Risk Zones (Total length 125.66, Range 0-12)
  // Low (0-3): 3/12 -> 25% -> 31.4
  // Moderate (3-6): 3/12 -> 25% -> 31.4
  // High (6-12): 6/12 -> 50% -> 62.8
  const riskZones = [
    { color: '#10b981', length: 31.4, gap: 0 }, // Low
    { color: '#f97316', length: 31.4, gap: 31.4 }, // Moderate
    { color: '#ef4444', length: 62.8, gap: 62.8 }, // High
  ];

  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
      <div className="flex items-center gap-3 text-blue-500">
        <Droplets size={24} />
        <h2 className="font-bold text-lg">Diabetes Risk Estimator</h2>
      </div>
      <p className="text-slate-500 text-sm">This is a simplified risk assessment based on common factors.</p>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Gender</label>
            <select className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase">Age</label>
            <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={age} onChange={(e) => setAge(e.target.value)} />
          </div>
        </div>
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase">BMI (Body Mass Index)</label>
          <input type="number" className="w-full bg-slate-50 rounded-2xl p-4 outline-none" value={bmi} onChange={(e) => setBmi(e.target.value)} />
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-400 uppercase">Risk Factors</label>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
            <span className="text-slate-700 text-sm font-medium">Family history of diabetes</span>
            <input type="checkbox" checked={factors.familyHistory} onChange={(e) => setFactors({...factors, familyHistory: e.target.checked})} className="w-6 h-6 rounded-lg border-slate-300 text-blue-600 focus:ring-blue-500" />
          </div>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
            <span className="text-slate-700 text-sm font-medium">High blood pressure</span>
            <input type="checkbox" checked={factors.highBP} onChange={(e) => setFactors({...factors, highBP: e.target.checked})} className="w-6 h-6 rounded-lg border-slate-300 text-blue-600 focus:ring-blue-500" />
          </div>
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
            <span className="text-slate-700 text-sm font-medium">Inactive lifestyle</span>
            <input type="checkbox" checked={factors.inactive} onChange={(e) => setFactors({...factors, inactive: e.target.checked})} className="w-6 h-6 rounded-lg border-slate-300 text-blue-600 focus:ring-blue-500" />
          </div>
        </div>

        <button onClick={calculate} className="w-full bg-blue-500 text-white font-bold py-4 rounded-2xl">Estimate Risk</button>
      </div>

      {riskScore !== null && (
        <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 mt-6">
          <GaugeChart value={riskScore} min={0} max={12} zones={riskZones} label="Risk Score" />
          <div className="text-center mt-4">
            <p className={`text-xl font-black ${getStatus(riskScore).color}`}>{getStatus(riskScore).label}</p>
            <p className="text-slate-500 text-sm mt-2">
              {riskScore <= 3 && "Your risk is low. Maintain a healthy lifestyle."}
              {riskScore > 3 && riskScore <= 6 && "You have a moderate risk. Consider improving your diet and exercise."}
              {riskScore > 6 && "You have a high risk. It is recommended to consult a doctor for a proper checkup."}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
