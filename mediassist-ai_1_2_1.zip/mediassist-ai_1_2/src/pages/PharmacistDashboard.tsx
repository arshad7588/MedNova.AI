import React, { useState } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Scan, 
  Package, 
  Receipt, 
  Store, 
  User 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Components
import PharmacyHome from '../components/pharmacist/PharmacyHome';
import SmartMedicineScanner from '../components/pharmacist/SmartMedicineScanner';
import InventoryManagement from '../components/pharmacist/InventoryManagement';
import BillingSystem from '../components/pharmacist/BillingSystem';
import StoreManagement from '../components/pharmacist/StoreManagement';
import PharmacistProfile from '../components/pharmacist/PharmacistProfile';

export default function PharmacistDashboard() {
  const navigate = useNavigate();
  const location = useLocation();

  const tabs = [
    { id: 'home', icon: LayoutDashboard, label: 'Home', path: '/pharmacist' },
    { id: 'scan', icon: Scan, label: 'Scan', path: '/pharmacist/scan' },
    { id: 'inventory', icon: Package, label: 'Stock', path: '/pharmacist/inventory' },
    { id: 'billing', icon: Receipt, label: 'Bill', path: '/pharmacist/billing' },
    { id: 'store', icon: Store, label: 'Store', path: '/pharmacist/store' },
    { id: 'profile', icon: User, label: 'Me', path: '/pharmacist/profile' }
  ];

  const currentTab = tabs.find(tab => 
    tab.path === location.pathname || 
    (tab.path !== '/pharmacist' && location.pathname.startsWith(tab.path))
  )?.id || 'home';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Main Content Area */}
      <main className="max-w-lg mx-auto px-6 pt-8 pb-32">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <Routes>
              <Route index element={<PharmacyHome />} />
              <Route path="scan" element={<SmartMedicineScanner />} />
              <Route path="inventory" element={<InventoryManagement />} />
              <Route path="billing" element={<BillingSystem />} />
              <Route path="store" element={<StoreManagement />} />
              <Route path="profile" element={<PharmacistProfile />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-xl border-t border-slate-100 px-6 py-4 z-40">
        <div className="max-w-lg mx-auto flex items-center justify-between">
          {tabs.map((tab) => {
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => navigate(tab.path)}
                className="flex flex-col items-center gap-1 relative group"
              >
                <div className={`p-2 rounded-xl transition-all duration-300 ${
                  isActive 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-100 scale-110' 
                    : 'text-slate-400 hover:text-slate-600'
                }`}>
                  <tab.icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                </div>
                <span className={`text-[10px] font-bold transition-all ${
                  isActive ? 'text-blue-600 opacity-100' : 'text-slate-400 opacity-0 group-hover:opacity-100'
                }`}>
                  {tab.label}
                </span>
                {isActive && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute -top-1 w-1 h-1 bg-blue-600 rounded-full"
                  />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
