import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, MapPin, Navigation, Star, Search, Clock, Loader2, X, RotateCw } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { logActivity } from '../utils/activityLogger';
import { searchNearbyFacilities } from '../services/gemini';
import ReactMarkdown from 'react-markdown';

export default function NearbyFacilities() {
  const navigate = useNavigate();
  const locationObj = useLocation();
  const queryParams = new URLSearchParams(locationObj.search);
  const initialQuery = queryParams.get('q') || 'pharmacies';

  const { language } = useSettings();
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [isSearching, setIsSearching] = useState(false);
  const [facilities, setFacilities] = useState<any[]>([]);
  const [groundingChunks, setGroundingChunks] = useState<any[]>([]);

  const categories = [
    { label: 'Emergency', value: 'emergency room' },
    { label: '24/7 Pharmacies', value: '24/7 pharmacies' },
    { label: 'Hospitals', value: 'hospitals' },
    { label: 'Clinics', value: 'clinics' },
    { label: 'Pediatricians', value: 'pediatricians' },
    { label: 'Dentists', value: 'dentists' },
  ];

  const performSearch = useCallback(async (lat: number, lng: number, query: string) => {
    setIsSearching(true);
    setFacilities([]);
    setGroundingChunks([]);
    
    try {
      const result = await searchNearbyFacilities(lat, lng, query, language);
      const parsed = JSON.parse(result.text || '{"facilities": []}');
      setFacilities(parsed.facilities || []);
      setGroundingChunks(result.groundingChunks);
      logActivity('Nearby Search', `Searched for: ${query}`);
    } catch (err) {
      console.error('Search error:', err);
      setError('Failed to search nearby facilities. Please try again.');
    } finally {
      setIsSearching(false);
    }
  }, [language]);

  const requestLocation = useCallback(() => {
    setIsLocating(true);
    setError(null);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setUserLocation(loc);
          setIsLocating(false);
          performSearch(loc.lat, loc.lng, searchQuery);
        },
        (err) => {
          console.error(err);
          let msg = 'Location access denied.';
          if (err.code === 1) msg = 'Location access denied. Please enable location permissions in your browser settings.';
          else if (err.code === 2) msg = 'Position unavailable. Please check your GPS signal.';
          else if (err.code === 3) msg = 'Location request timed out.';
          
          setError(msg);
          setIsLocating(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      setError('Geolocation is not supported by your browser.');
      setIsLocating(false);
    }
  }, [performSearch, searchQuery]);

  useEffect(() => {
    requestLocation();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userLocation) {
      performSearch(userLocation.lat, userLocation.lng, searchQuery);
    }
  };

  const handleCategoryClick = (value: string) => {
    setSearchQuery(value);
    if (userLocation) {
      performSearch(userLocation.lat, userLocation.lng, value);
    }
  };

  return (
    <div className="min-h-screen bg-white pb-24">
      {/* Header */}
      <header className="p-4 flex items-center gap-4 sticky top-0 bg-white z-10">
        <button onClick={() => navigate(-1)} className="text-slate-800">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-xl font-bold text-slate-900">Nearby Facilities</h1>
      </header>

      <div className="px-4 space-y-6">
        {/* Search Bar */}
        <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search nearby (e.g. urgent care)" 
              className="w-full bg-white border border-slate-200 rounded-full py-3 pl-12 pr-10 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all text-slate-800"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            )}
          </div>
          <button 
            type="submit"
            disabled={isSearching || !userLocation}
            className="bg-emerald-600 text-white px-6 py-3 rounded-full font-bold text-sm shadow-md active:scale-95 transition-all disabled:opacity-50"
          >
            {isSearching ? '...' : 'Search'}
          </button>
        </form>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat) => (
            <button
              key={cat.label}
              onClick={() => handleCategoryClick(cat.value)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium whitespace-nowrap border transition-all ${
                searchQuery === cat.value
                  ? 'bg-emerald-600 text-white border-emerald-600'
                  : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-500'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Location Status Card */}
        <div className="bg-emerald-700 rounded-[32px] p-8 flex flex-col items-center justify-center text-white gap-4 shadow-lg relative overflow-hidden">
          <div className="bg-white/20 p-4 rounded-full backdrop-blur-sm relative z-10">
            <MapPin size={32} className={`${isLocating ? 'animate-bounce' : ''} text-white`} />
          </div>
          <p className="text-lg font-bold tracking-wide relative z-10">
            {isLocating ? 'Locating...' : userLocation ? 'Location Found' : 'Location Required'}
          </p>
          {!isLocating && !userLocation && (
            <button 
              onClick={requestLocation}
              className="relative z-10 bg-white text-emerald-700 px-6 py-2 rounded-xl font-bold text-sm shadow-md active:scale-95 transition-all"
            >
              Retry
            </button>
          )}
          <div className="absolute -right-4 -bottom-4 opacity-10">
            <MapPin size={120} />
          </div>
        </div>

        {/* Recommended Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Star size={20} className="text-amber-500 fill-amber-500" />
            <h2 className="text-lg font-bold text-slate-800">Recommended for you</h2>
          </div>

          {isSearching ? (
            <div className="flex flex-col items-center justify-center py-12 text-slate-400 gap-3">
              <Loader2 size={32} className="animate-spin text-emerald-500" />
              <p className="text-sm font-medium">Searching nearby facilities...</p>
            </div>
          ) : error ? (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-sm border border-red-100">
              {error}
            </div>
          ) : facilities.length > 0 ? (
            <div className="space-y-4">
              {facilities.map((fac, idx) => (
                <div key={idx} className="bg-white border border-slate-100 rounded-[32px] p-6 shadow-sm space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-slate-900 text-lg">{fac.name}</h3>
                      {fac.address && <p className="text-xs text-slate-500 mt-1">{fac.address}</p>}
                    </div>
                    {fac.distance && (
                      <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">
                        {fac.distance}
                      </span>
                    )}
                  </div>
                  
                  {fac.status && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-600">
                      <Clock size={14} className="text-slate-400" />
                      <span>{fac.status}</span>
                    </div>
                  )}

                  <a 
                    href={fac.googleUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-95"
                  >
                    <Navigation size={18} /> View on Google
                  </a>
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
