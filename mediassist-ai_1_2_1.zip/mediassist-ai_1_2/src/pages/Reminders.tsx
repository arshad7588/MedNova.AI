import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Bell, Plus, Trash2, Clock, Pill, X, Check } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { Reminder, Medicine } from '../types';
import { motion, AnimatePresence } from 'motion/react';

export default function Reminders() {
  const navigate = useNavigate();
  const location = useLocation();
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', dosage: '', time: '', frequency: 'Daily' });
  const [incomingMedicines, setIncomingMedicines] = useState<Medicine[]>([]);

  useEffect(() => {
    // Handle state passed from scanners
    const state = location.state as { medicine?: Medicine; medicines?: Medicine[] };
    if (state) {
      if (state.medicine) {
        setNewMed({
          name: state.medicine.name,
          dosage: state.medicine.dosage || '',
          time: '',
          frequency: 'Daily'
        });
        setShowAdd(true);
      } else if (state.medicines && state.medicines.length > 0) {
        setIncomingMedicines(state.medicines);
      }
    }

    // Fallback for query params
    const params = new URLSearchParams(window.location.search);
    const name = params.get('name');
    const dosage = params.get('dosage');
    if (name && !state) {
      setNewMed(prev => ({ ...prev, name, dosage: dosage || '' }));
      setShowAdd(true);
    }
  }, [location]);

  const handleAddIncoming = async (med: Medicine) => {
    if (!auth.currentUser) return;
    const path = 'reminders';
    try {
      await addDoc(collection(db, path), {
        userId: auth.currentUser.uid,
        medicineName: med.name,
        dosage: med.dosage || 'As prescribed',
        time: '09:00', // Default time
        frequency: 'Daily',
        active: true,
        createdAt: new Date().toISOString()
      });
      setIncomingMedicines(prev => prev.filter(m => m.id !== med.id));
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  useEffect(() => {
    if (!auth.currentUser) return;
    const path = 'reminders';
    const q = query(collection(db, path), where('userId', '==', auth.currentUser.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Reminder));
      setReminders(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
    return () => unsubscribe();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    const path = 'reminders';
    try {
      await addDoc(collection(db, path), {
        userId: auth.currentUser.uid,
        medicineName: newMed.name,
        dosage: newMed.dosage,
        time: newMed.time,
        frequency: newMed.frequency,
        active: true,
        createdAt: new Date().toISOString()
      });
      setShowAdd(false);
      setNewMed({ name: '', dosage: '', time: '', frequency: 'Daily' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const toggleActive = async (id: string, current: boolean) => {
    const path = `reminders/${id}`;
    try {
      await updateDoc(doc(db, 'reminders', id), { active: !current });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  };

  const handleDelete = async (id: string) => {
    const path = `reminders/${id}`;
    try {
      await deleteDoc(doc(db, 'reminders', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-slate-600">
            <ArrowLeft size={24} />
          </button>
          <h1 className="font-bold text-slate-900">Med Reminders</h1>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100"
        >
          <Plus size={24} />
        </button>
      </header>

      <div className="p-6">
        <div className="space-y-4">
          {/* Incoming Medicines from Scanners */}
          <AnimatePresence>
            {incomingMedicines.length > 0 && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-3 mb-8"
              >
                <div className="flex items-center justify-between px-2">
                  <h3 className="text-xs font-black text-orange-600 uppercase tracking-[0.2em]">Scanned Medicines</h3>
                  <button 
                    onClick={() => setIncomingMedicines([])}
                    className="text-[10px] font-bold text-slate-400 hover:text-slate-600"
                  >
                    Clear All
                  </button>
                </div>
                {incomingMedicines.map((med) => (
                  <motion.div
                    key={med.id}
                    layout
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    className="bg-orange-50 p-4 rounded-2xl border border-orange-100 flex items-center gap-4"
                  >
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-orange-600 shadow-sm">
                      <Pill size={20} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-bold text-slate-900 text-sm">{med.name}</h4>
                      <p className="text-[10px] text-orange-600 font-bold">{med.dosage || 'As prescribed'}</p>
                    </div>
                    <button
                      onClick={() => handleAddIncoming(med)}
                      className="bg-orange-600 text-white p-2 rounded-xl shadow-lg shadow-orange-200 active:scale-90 transition-transform"
                    >
                      <Plus size={18} />
                    </button>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          {reminders.length === 0 && incomingMedicines.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                <Bell size={32} />
              </div>
              <p className="text-slate-400">No reminders set yet.</p>
            </div>
          ) : (
            reminders.map((rem) => (
              <motion.div
                layout
                key={rem.id}
                className={`bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4 ${!rem.active && 'opacity-60'}`}
              >
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${rem.active ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                  <Pill size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-800">{rem.medicineName}</h3>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                    <span className="flex items-center gap-1"><Clock size={12} /> {rem.time}</span>
                    <span>•</span>
                    <span>{rem.dosage}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => toggleActive(rem.id!, rem.active)}
                    className={`w-10 h-6 rounded-full relative transition-colors ${rem.active ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${rem.active ? 'right-1' : 'left-1'}`}></div>
                  </button>
                  <button onClick={() => handleDelete(rem.id!)} className="text-slate-300 hover:text-red-500 p-2">
                    <Trash2 size={18} />
                  </button>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      <AnimatePresence>
        {showAdd && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end">
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="bg-white w-full rounded-t-[40px] p-8 space-y-6"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">Add Reminder</h2>
                <button onClick={() => setShowAdd(false)} className="text-slate-400">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleAdd} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Medicine Name</label>
                  <input 
                    type="text" 
                    required
                    className="w-full bg-slate-50 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="e.g. Ibuprofen"
                    value={newMed.name}
                    onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Dosage</label>
                    <input 
                      type="text" 
                      required
                      className="w-full bg-slate-50 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      placeholder="e.g. 200mg"
                      value={newMed.dosage}
                      onChange={(e) => setNewMed({ ...newMed, dosage: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Time</label>
                    <input 
                      type="time" 
                      required
                      className="w-full bg-slate-50 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      value={newMed.time}
                      onChange={(e) => setNewMed({ ...newMed, time: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Frequency</label>
                  <select 
                    className="w-full bg-slate-50 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    value={newMed.frequency}
                    onChange={(e) => setNewMed({ ...newMed, frequency: e.target.value })}
                  >
                    <option>Daily</option>
                    <option>Twice a day</option>
                    <option>Three times a day</option>
                    <option>Weekly</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-emerald-100 mt-4"
                >
                  Set Reminder
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
