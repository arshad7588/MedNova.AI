import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, ArrowLeft, Info, ShieldAlert, Mic, MicOff, Trash2, Clock, MoreVertical, Sparkles, Edit2, RotateCw, X, Share2, Key } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { streamHealthAssistant } from '../services/gemini';
import { motion } from 'motion/react';
import { ChatMessage } from '../types';
import { usePatient } from '../context/PatientContext';
import { useSettings } from '../context/SettingsContext';
import { logActivity } from '../utils/activityLogger';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { doc, getDoc, setDoc, deleteDoc, collection, query, where, orderBy, getDocs, addDoc, updateDoc, onSnapshot, Timestamp } from 'firebase/firestore';
import ReadMore from '../components/ReadMore';
import { ChatSession } from '../types';

export default function HealthAssistant() {
  const navigate = useNavigate();
  const { patientData } = usePatient();
  const { language } = useSettings();
  const getInitialGreeting = (lang: string) => {
    if (lang === 'Hindi') {
      return "Namaste! 🙏 Main MediAssist AI hoon, aapka personal health companion. Aaj aap kaisa feel kar rahe hain? Main aapki kaise madad kar sakta hoon? ✨";
    }
    if (lang === 'Marathi') {
      return "Namaste! 🙏 Me MediAssist AI aahe. Aaj tumhala kase vatate aahe? Me tumchi kashi madat karu shakto? ✨";
    }
    return "Hello! 🤗 I'm MediAssist AI, your personal health companion. How are you feeling today? I'm here to help you with any health concerns or questions you have. ✨";
  };

  const [messages, setMessages] = useState<ChatMessage[]>([]);

  // Initialize greeting based on language
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{ role: 'model', parts: [{ text: getInitialGreeting(language) }] }]);
    }
  }, [language]);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isEditingAI, setIsEditingAI] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const baseInputRef = useRef('');

  // Load sessions on mount
  useEffect(() => {
    if (!auth.currentUser) return;

    const sessionsRef = collection(db, 'chatHistory', auth.currentUser.uid, 'sessions');
    const q = query(sessionsRef, orderBy('updatedAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const sessionsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as ChatSession[];
      setSessions(sessionsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `chatHistory/${auth.currentUser?.uid}/sessions`);
    });

    return () => unsubscribe();
  }, []);

  // Load current session if any
  useEffect(() => {
    const loadActiveSession = async () => {
      if (!auth.currentUser) return;
      try {
        const docRef = doc(db, 'chatHistory', auth.currentUser.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.activeSessionId) {
            setCurrentSessionId(data.activeSessionId);
            const sessionRef = doc(db, 'chatHistory', auth.currentUser.uid, 'sessions', data.activeSessionId);
            const sessionSnap = await getDoc(sessionRef);
            if (sessionSnap.exists()) {
              setMessages(sessionSnap.data().messages);
            }
          }
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `chatHistory/${auth.currentUser.uid}`);
      }
    };
    loadActiveSession();
  }, []);

  const saveToFirestore = async (currentMsgs: ChatMessage[]) => {
    if (!auth.currentUser) return;
    try {
      let sessionId = currentSessionId;
      const updatedAt = new Date().toISOString();
      
      if (!sessionId) {
        // Create new session
        const title = currentMsgs.find(m => m.role === 'user')?.parts[0].text.slice(0, 50) || "New Consultation";
        const sessionsRef = collection(db, 'chatHistory', auth.currentUser.uid, 'sessions');
        const newSession = await addDoc(sessionsRef, {
          userId: auth.currentUser.uid,
          title,
          messages: currentMsgs,
          updatedAt
        });
        sessionId = newSession.id;
        setCurrentSessionId(sessionId);
        
        // Update active session ID in main doc
        const mainDocRef = doc(db, 'chatHistory', auth.currentUser.uid);
        await setDoc(mainDocRef, { 
          activeSessionId: sessionId,
          userId: auth.currentUser.uid,
          updatedAt
        }, { merge: true });
      } else {
        // Update existing session
        const sessionRef = doc(db, 'chatHistory', auth.currentUser.uid, 'sessions', sessionId);
        await updateDoc(sessionRef, {
          messages: currentMsgs,
          updatedAt
        });
        
        // Update main doc timestamp
        const mainDocRef = doc(db, 'chatHistory', auth.currentUser.uid);
        await updateDoc(mainDocRef, { updatedAt });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `chatHistory/${auth.currentUser.uid}`);
    }
  };

  const startNewConsultation = async () => {
    const initialGreeting: ChatMessage[] = [{ role: 'model', parts: [{ text: getInitialGreeting(language) }] }];
    setMessages(initialGreeting);
    setCurrentSessionId(null);
    
    if (auth.currentUser) {
      const mainDocRef = doc(db, 'chatHistory', auth.currentUser.uid);
      await setDoc(mainDocRef, { 
        activeSessionId: null,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  };

  const clearHistory = async () => {
    if (!auth.currentUser) return;
    if (window.confirm("Are you sure you want to clear your entire consultation history?")) {
      try {
        // Delete all sessions
        const sessionsRef = collection(db, 'chatHistory', auth.currentUser.uid, 'sessions');
        const q = query(sessionsRef);
        const snapshot = await getDocs(q);
        const deletePromises = snapshot.docs.map(d => deleteDoc(d.ref));
        await Promise.all(deletePromises);
        
        // Reset main doc
        const mainDocRef = doc(db, 'chatHistory', auth.currentUser.uid);
        await deleteDoc(mainDocRef);
        
        startNewConsultation();
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `chatHistory/${auth.currentUser.uid}`);
      }
    }
  };

  const deleteSession = async (sessionId: string) => {
    if (!auth.currentUser) return;
    try {
      await deleteDoc(doc(db, 'chatHistory', auth.currentUser.uid, 'sessions', sessionId));
      if (currentSessionId === sessionId) {
        startNewConsultation();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `chatHistory/${auth.currentUser.uid}/sessions/${sessionId}`);
    }
  };

  const loadSession = async (session: ChatSession) => {
    setMessages(session.messages);
    setCurrentSessionId(session.id);
    setShowHistory(false);
    
    if (auth.currentUser) {
      const mainDocRef = doc(db, 'chatHistory', auth.currentUser.uid);
      await setDoc(mainDocRef, { 
        activeSessionId: session.id,
        updatedAt: new Date().toISOString()
      }, { merge: true });
    }
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    // Initialize SpeechRecognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      
      // Set language based on app settings (basic mapping)
      if (language === 'Marathi') recognition.lang = 'mr-IN';
      else if (language === 'Hindi') recognition.lang = 'hi-IN';
      else recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        
        const base = baseInputRef.current.trim();
        setInput(base ? `${base} ${transcript}` : transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [language]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      // Store current input to append to it
      baseInputRef.current = input;
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        console.error("Microphone start error:", e);
      }
    }
  };

  const handleSend = async (overrideInput?: string, editIndex?: number) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim() || loading) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    }

    let updatedMessages: ChatMessage[];
    
    if (isEditingAI && editingIndex !== null) {
      // Steering: Update the AI message and ask to continue
      const baseMessages = messages.slice(0, editingIndex);
      const editedAIMessage: ChatMessage = { role: 'model', parts: [{ text: textToSend }] };
      const continuationTrigger: ChatMessage = { role: 'user', parts: [{ text: "Please continue based on this." }] };
      updatedMessages = [...baseMessages, editedAIMessage, continuationTrigger];
      setIsEditingAI(false);
      setEditingIndex(null);
    } else if (editIndex !== undefined) {
      // Branch conversation from edited message
      updatedMessages = messages.slice(0, editIndex);
      updatedMessages.push({ role: 'user', parts: [{ text: textToSend }] });
    } else {
      updatedMessages = [...messages, { role: 'user', parts: [{ text: textToSend }] }];
    }
    
    setMessages(updatedMessages);
    saveToFirestore(updatedMessages);
    logActivity('AI Health Assistant', textToSend);
    
    if (!overrideInput) setInput('');
    setLoading(true);

    try {
      const responseStream = streamHealthAssistant(updatedMessages, patientData, language);
      
      let fullText = '';
      let displayedLines: string[] = [];
      let currentBuffer = '';
      
      // Add a placeholder for the model response
      setMessages(prev => [...prev, { role: 'model', parts: [{ text: '' }] }]);
      
      for await (const chunk of responseStream) {
        fullText += chunk;
        currentBuffer += chunk;
        
        // Check if we have a new line
        if (currentBuffer.includes('\n')) {
          const lines = currentBuffer.split('\n');
          // All but the last one are complete lines
          const completeLines = lines.slice(0, -1);
          displayedLines = [...displayedLines, ...completeLines];
          currentBuffer = lines[lines.length - 1]; // Keep the partial line in buffer
          
          setMessages(prev => {
            const newMsgs = [...prev];
            const textToShow = displayedLines.join('\n') + (currentBuffer ? '\n' + currentBuffer : '');
            newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: textToShow }] };
            return newMsgs;
          });
          
          // Small delay for "professional" line-by-line look
          await new Promise(resolve => setTimeout(resolve, 150));
        } else {
          // Still update for the partial line so user sees progress
          setMessages(prev => {
            const newMsgs = [...prev];
            const textToShow = displayedLines.join('\n') + (displayedLines.length > 0 ? '\n' : '') + currentBuffer;
            newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: textToShow }] };
            return newMsgs;
          });
        }
      }
      
      // Final update to ensure everything is shown
      setMessages(prev => {
        const newMsgs = [...prev];
        newMsgs[newMsgs.length - 1] = { role: 'model', parts: [{ text: fullText }] };
        return newMsgs;
      });
      
      // Save final state with AI response
      const finalMessages: ChatMessage[] = [...updatedMessages, { role: 'model', parts: [{ text: fullText }] }];
      saveToFirestore(finalMessages);
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      let errorMessage = "I'm sorry, I encountered an error. Please try again.";
      
      // Check for specific Gemini errors
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 'PERMISSION_DENIED' || error?.status === 403) {
        errorMessage = "I don't have permission to access the AI service. This usually means the API key is invalid or lacks permissions.";
        
        if (window.aistudio?.openSelectKey) {
          setMessages(prev => [...prev, { 
            role: 'model', 
            parts: [{ text: errorMessage + "\n\nPlease click the button below to configure your Gemini API key." }],
            isSystemAction: true,
            actionLabel: "Configure API Key",
            onAction: async () => {
              await window.aistudio?.openSelectKey();
            }
          }]);
          return;
        }
      }
      
      setMessages(prev => [...prev, { role: 'model', parts: [{ text: errorMessage }] }]);
    } finally {
      setLoading(false);
    }
  };

  const handleRegenerate = () => {
    const lastUserMsgIndex = [...messages].reverse().findIndex(m => m.role === 'user');
    if (lastUserMsgIndex !== -1) {
      const actualIndex = messages.length - 1 - lastUserMsgIndex;
      handleSend(messages[actualIndex].parts[0].text, actualIndex);
    }
  };

  const handleEdit = (index: number) => {
    const msg = messages[index];
    setInput(msg.parts[0].text);
    if (msg.role === 'model') {
      setIsEditingAI(true);
      setEditingIndex(index);
    } else {
      setIsEditingAI(false);
      setEditingIndex(null);
    }
  };

  const handleShare = async (text: string) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'MediAssist AI Health Advice',
          text: text,
          url: window.location.href,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(text);
        alert('Advice copied to clipboard!');
      } catch (error) {
        console.error('Failed to copy:', error);
      }
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <header className="bg-white dark:bg-slate-900 p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 p-2 rounded-full transition-colors">
          <ArrowLeft size={22} />
        </button>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <Sparkles size={20} />
          </div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-slate-900 dark:text-white text-lg tracking-tight">AI Health Assistant</h1>
            <button 
              onClick={() => setShowHistory(true)} 
              className="p-1.5 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors"
              title="Recent History"
            >
              <Clock size={18} />
            </button>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <button onClick={startNewConsultation} className="p-2 text-slate-400 hover:text-emerald-600 transition-colors" title="New Consultation">
            <Sparkles size={20} />
          </button>
          <button onClick={clearHistory} className="p-2 text-slate-400 hover:text-red-500 transition-colors" title="Clear All History">
            <Trash2 size={20} />
          </button>
        </div>
      </header>

      {/* History Modal */}
      {showHistory && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white dark:bg-slate-800 w-full max-w-md rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
          >
            <div className="p-6 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="text-emerald-600" size={20} />
                <h2 className="font-bold text-slate-900 dark:text-white">Consultation History</h2>
              </div>
              <button onClick={() => setShowHistory(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {sessions.length === 0 ? (
                <p className="text-center text-slate-500 py-10">No history yet.</p>
              ) : (
                sessions.map((session) => (
                  <div 
                    key={session.id} 
                    className={`group relative p-3 rounded-xl border transition-all cursor-pointer ${
                      currentSessionId === session.id 
                        ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500/50' 
                        : 'bg-slate-50 dark:bg-slate-900/50 border-slate-100 dark:border-slate-700 hover:border-emerald-500/30'
                    }`} 
                    onClick={() => loadSession(session)}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">
                        {new Date(session.updatedAt).toLocaleDateString()}
                      </p>
                      <button 
                        onClick={(e) => { e.stopPropagation(); deleteSession(session.id); }}
                        className="p-1 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <p className="text-sm text-slate-700 dark:text-slate-300 line-clamp-1 font-bold">{session.title}</p>
                    <p className="text-[10px] text-slate-400 mt-1 line-clamp-1 italic">
                      {session.messages[session.messages.length - 1]?.parts[0].text}
                    </p>
                  </div>
                ))
              )}
            </div>
            <div className="p-4 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-100 dark:border-slate-700">
              <button 
                onClick={() => setShowHistory(false)}
                className="w-full py-3 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-medium"
              >
                Close
              </button>
            </div>
          </motion.div>
        </div>
      )}

      <div className="bg-slate-900 text-white px-4 py-2 flex items-center justify-between text-[10px] font-medium tracking-wider uppercase opacity-80">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
          <span>Secure AI Consultation</span>
        </div>
        <span>End-to-End Encrypted</span>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] group relative ${msg.role === 'user' ? 'flex flex-row-reverse gap-3' : 'flex gap-3'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-1 ${
                msg.role === 'user' ? 'bg-slate-200 dark:bg-slate-700' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600'
              }`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className="relative">
                <div className={`p-4 rounded-2xl shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-emerald-600 text-white rounded-tr-none' 
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-tl-none border border-slate-100 dark:border-slate-700'
                }`}>
                  <div className={`prose prose-sm max-w-none leading-relaxed ${msg.role === 'user' ? 'prose-invert' : 'prose-slate dark:prose-invert'}`}>
                    {msg.role === 'user' ? (
                      <p className="m-0">{msg.parts[0].text}</p>
                    ) : (
                      <div className="whitespace-pre-wrap">{msg.parts[0].text}</div>
                    )}
                  </div>
                  {msg.isSystemAction && msg.actionLabel && (
                    <button
                      onClick={msg.onAction}
                      className="mt-3 w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2"
                    >
                      <Key size={14} />
                      {msg.actionLabel}
                    </button>
                  )}
                </div>

                {/* Action Buttons */}
                <div className={`absolute top-0 ${msg.role === 'user' ? '-left-10' : '-right-10'} flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity`}>
                  <button 
                    onClick={() => handleEdit(idx)}
                    className="p-1.5 bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-emerald-600 transition-colors"
                    title={msg.role === 'user' ? "Edit Query" : "Edit AI Response"}
                  >
                    <Edit2 size={14} />
                  </button>
                  {msg.role === 'model' && (
                    <>
                      <button 
                        onClick={handleRegenerate}
                        className="p-1.5 bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-emerald-600 transition-colors"
                        title="Regenerate Response"
                      >
                        <RotateCw size={14} />
                      </button>
                      <button 
                        onClick={() => handleShare(msg.parts[0].text)}
                        className="p-1.5 bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-emerald-600 transition-colors"
                        title="Share Advice"
                      >
                        <Share2 size={14} />
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl rounded-tl-none border border-slate-100 dark:border-slate-700 shadow-sm flex gap-1">
              <div className="w-2 h-2 bg-slate-300 dark:bg-slate-600 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-slate-300 dark:bg-slate-600 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-2 h-2 bg-slate-300 dark:bg-slate-600 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-[64px] left-0 right-0 p-4 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 z-40">
        <div className="max-w-4xl mx-auto mb-3 flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          <button 
            onClick={() => {
              setInput("I am feeling ");
              toggleListening();
            }}
            className="whitespace-nowrap px-4 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-xl text-xs font-bold border border-emerald-100 dark:border-emerald-800/50 hover:bg-emerald-100 transition-colors flex items-center gap-2"
          >
            <Mic size={14} />
            Speak Symptoms
          </button>
          <button 
            onClick={() => handleSend("What are my current medications?")}
            className="whitespace-nowrap px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-200 transition-colors"
          >
            My Medications
          </button>
          <button 
            onClick={() => handleSend("Check my latest vitals")}
            className="whitespace-nowrap px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-200 transition-colors"
          >
            Check Vitals
          </button>
        </div>
        <div className="max-w-4xl mx-auto relative flex items-center gap-2">
          <button
            onClick={toggleListening}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shrink-0 shadow-sm ${
              isListening 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title={isListening ? "Stop listening" : "Start voice input"}
          >
            {isListening ? <MicOff size={22} /> : <Mic size={22} />}
          </button>
          
          <div className="relative flex-1">
            <input
              type="text"
              placeholder={isListening ? "Listening..." : "Ask MediAssist AI..."}
              className={`w-full bg-slate-100 dark:bg-slate-800 border-none rounded-2xl py-4 pl-5 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 dark:text-white placeholder:text-slate-400 text-sm ${isEditingAI ? 'pr-24' : 'pr-14'}`}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {isEditingAI && (
                <button
                  onClick={() => {
                    setIsEditingAI(false);
                    setEditingIndex(null);
                    setInput('');
                  }}
                  className="w-8 h-8 text-slate-400 hover:text-red-500 transition-colors flex items-center justify-center"
                  title="Cancel Edit"
                >
                  <X size={18} />
                </button>
              )}
              <button
                onClick={() => handleSend()}
                disabled={loading || !input.trim()}
                className="px-3 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center hover:bg-emerald-700 disabled:opacity-50 transition-all shadow-lg shadow-emerald-600/20 gap-2"
              >
                <span className="text-xs font-bold uppercase tracking-wider">
                  {isEditingAI ? 'Regenerate' : 'Send'}
                </span>
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Spacer to prevent content from being hidden behind the fixed input bar */}
      <div className="h-[144px] shrink-0"></div>
    </div>
  );
}
