import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Moon, Globe, Shield, FileText, MessageSquare, Phone, ChevronRight, Check, Key } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export default function Settings() {
  const navigate = useNavigate();
  const { darkMode, toggleDarkMode, language, setLanguage } = useSettings();
  const [showLangModal, setShowLangModal] = useState(false);

  const languages: ('English' | 'Spanish' | 'French' | 'German' | 'Hindi' | 'Marathi')[] = ['English', 'Spanish', 'French', 'German', 'Hindi', 'Marathi'];

  const handleOpenKeySelector = async () => {
    if (window.aistudio?.openSelectKey) {
      try {
        await window.aistudio.openSelectKey();
      } catch (error) {
        console.error('Failed to open key selector:', error);
      }
    } else {
      console.warn('API Key selection is only available in the AI Studio environment.');
    }
  };

  const sections = [
    { 
      title: 'Preferences', 
      items: [
        { id: 'dark', name: 'Dark Mode', icon: <Moon />, type: 'toggle', value: darkMode, onChange: toggleDarkMode },
        { id: 'lang', name: 'Language', icon: <Globe />, type: 'link', value: language, onClick: () => setShowLangModal(true) },
      ]
    },
    {
      title: 'AI Configuration',
      items: [
        { id: 'apiKey', name: 'Configure AI Key', icon: <Key />, type: 'link', onClick: handleOpenKeySelector },
      ]
    },
    { 
      title: 'Legal', 
      items: [
        { id: 'privacy', name: 'Privacy Policy', icon: <Shield />, type: 'link' },
        { id: 'terms', name: 'Terms & Conditions', icon: <FileText />, type: 'link' },
      ]
    },
    { 
      title: 'Support', 
      items: [
        { id: 'feedback', name: 'Send Feedback', icon: <MessageSquare />, type: 'link' },
        { id: 'contact', name: 'Contact Support', icon: <Phone />, type: 'link' },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-24 transition-colors duration-300">
      <header className="bg-white dark:bg-slate-800 p-4 border-b border-slate-200 dark:border-slate-700 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600 dark:text-slate-400">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900 dark:text-white">Settings</h1>
      </header>

      <div className="p-6 space-y-8">
        {sections.map(section => (
          <div key={section.title} className="space-y-3">
            <h2 className="text-xs font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 ml-2">{section.title}</h2>
            <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden">
              {section.items.map((item, idx) => (
                <div 
                  key={item.id} 
                  className={`flex items-center justify-between p-5 ${idx !== section.items.length - 1 ? 'border-b border-slate-50 dark:border-slate-700' : ''}`}
                  onClick={item.type === 'link' ? item.onClick : undefined}
                >
                  <div className="flex items-center gap-4">
                    <div className="text-slate-400 dark:text-slate-500">{item.icon}</div>
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{item.name}</span>
                  </div>
                  
                  {item.type === 'toggle' ? (
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        item.onChange?.();
                      }}
                      className={`w-12 h-7 rounded-full relative transition-colors ${item.value ? 'bg-emerald-500' : 'bg-slate-200 dark:bg-slate-700'}`}
                    >
                      <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all ${item.value ? 'right-1' : 'left-1'}`}></div>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500">
                      {item.value && <span className="text-sm font-medium">{item.value}</span>}
                      <ChevronRight size={20} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}

        <div className="text-center pt-8">
          <p className="text-slate-300 dark:text-slate-600 text-xs font-bold uppercase tracking-widest">MediAssist AI v1.0.0</p>
        </div>
      </div>

      {/* Language Selection Modal */}
      {showLangModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end justify-center z-[60] p-4">
          <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-[40px] p-8 space-y-6 animate-in slide-in-from-bottom duration-300">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-black text-slate-900 dark:text-white">Select Language</h3>
              <button onClick={() => setShowLangModal(false)} className="text-slate-400">
                <ArrowLeft className="rotate-90" size={24} />
              </button>
            </div>
            
            <div className="space-y-2">
              {languages.map(lang => (
                <button
                  key={lang}
                  onClick={() => {
                    setLanguage(lang);
                    setShowLangModal(false);
                  }}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl transition-all ${
                    language === lang 
                      ? 'bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400' 
                      : 'hover:bg-slate-50 dark:hover:bg-slate-700/50 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  <span className="font-bold">{lang}</span>
                  {language === lang && <Check size={20} />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
