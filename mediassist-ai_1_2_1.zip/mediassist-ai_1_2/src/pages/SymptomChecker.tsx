import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Activity, Search, AlertCircle, CheckCircle2, ShieldAlert, Mic, MicOff } from 'lucide-react';
import { streamSymptomAnalysis } from '../services/gemini';
import { motion } from 'motion/react';
import { usePatient } from '../context/PatientContext';
import { useSettings } from '../context/SettingsContext';
import { logActivity } from '../utils/activityLogger';
import ReadMore from '../components/ReadMore';

export default function SymptomChecker() {
  const navigate = useNavigate();
  const { patientData } = usePatient();
  const { language } = useSettings();
  const [symptoms, setSymptoms] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = React.useRef<any>(null);
  const baseInputRef = React.useRef('');

  React.useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      
      if (language === 'Marathi') recognition.lang = 'mr-IN';
      else if (language === 'Hindi') recognition.lang = 'hi-IN';
      else recognition.lang = 'en-US';

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        
        const base = baseInputRef.current.trim();
        setSymptoms(base ? `${base} ${transcript}` : transcript);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [language]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      // Store current input to append to it
      baseInputRef.current = symptoms;
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        console.error("Microphone start error:", e);
      }
    }
  };

  const commonSymptoms = [
    'Headache', 'Fever', 'Cough', 'Fatigue', 'Sore Throat', 
    'Nausea', 'Dizziness', 'Chest Pain', 'Shortness of Breath'
  ];

  const handleAnalyze = async () => {
    if (!symptoms.trim()) return;
    
    setLoading(true);
    setResult('');
    try {
      const stream = streamSymptomAnalysis(symptoms, patientData, language);
      let fullResponse = '';
      let hasReceivedData = false;
      let displayedLines: string[] = [];
      let currentBuffer = '';

      for await (const chunk of stream) {
        if (chunk) {
          hasReceivedData = true;
          fullResponse += chunk;
          currentBuffer += chunk;

          if (currentBuffer.includes('\n')) {
            const lines = currentBuffer.split('\n');
            const completeLines = lines.slice(0, -1);
            displayedLines = [...displayedLines, ...completeLines];
            currentBuffer = lines[lines.length - 1];
            
            const textToShow = displayedLines.join('\n') + (currentBuffer ? '\n' + currentBuffer : '');
            setResult(textToShow);
            
            // Professional line-by-line delay
            await new Promise(resolve => setTimeout(resolve, 150));
          } else {
            const textToShow = displayedLines.join('\n') + (displayedLines.length > 0 ? '\n' : '') + currentBuffer;
            setResult(textToShow);
          }
        }
      }
      
      // Final update
      setResult(fullResponse);

      if (!hasReceivedData) {
        setResult("I couldn't generate an analysis. Please try rephrasing your symptoms. 🩺");
      } else {
        // Log activity after stream finishes
        logActivity('Symptom Checker', symptoms, fullResponse);
      }
    } catch (error: any) {
      console.error("Symptom Analysis Error:", error);
      let errorMessage = "An error occurred while analyzing symptoms. Please try again. 🩺";
      
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 'PERMISSION_DENIED' || error?.status === 403) {
        errorMessage = "I don't have permission to access the AI service. This usually means the API key is invalid or lacks permissions. Please check your settings.";
      } else if (error?.message?.includes('quota') || error?.message?.includes('limit')) {
        errorMessage = "The AI service is currently at its limit. Please try again in a few minutes. 🩺";
      }

      setResult(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const addSymptom = (s: string) => {
    setSymptoms(prev => prev ? `${prev}, ${s}` : s);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-24 transition-colors duration-300">
      <header className="bg-white dark:bg-slate-800 p-4 border-b border-slate-200 dark:border-slate-700 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600 dark:text-slate-400">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900 dark:text-white">Symptom Checker</h1>
      </header>

      <div className="p-6 space-y-6">
        {patientData.consentGiven ? (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 p-4 rounded-2xl flex items-start gap-3">
            <ShieldAlert className="text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="text-emerald-800 dark:text-emerald-300 font-bold text-sm">Personalized Analysis Active</h3>
              <p className="text-emerald-600 dark:text-emerald-400 text-xs mt-1">
                Your saved medical history, allergies, and current medications will be used to provide safer, more accurate insights and medicine suggestions.
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-4 rounded-2xl flex items-start gap-3">
            <AlertCircle className="text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" size={20} />
            <div className="flex-1">
              <h3 className="text-blue-800 dark:text-blue-300 font-bold text-sm">Enable Personalized Analysis</h3>
              <p className="text-blue-600 dark:text-blue-400 text-xs mt-1">
                Enable local storage in your profile to use your medical history for more accurate and safer symptom analysis.
              </p>
              <button 
                onClick={() => navigate('/patient-profile')}
                className="mt-2 text-blue-700 dark:text-blue-300 text-xs font-bold underline"
              >
                Go to Profile
              </button>
            </div>
          </div>
        )}

        {!result ? (
          <>
            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-4">
              <div className="flex items-center gap-3 text-blue-600 dark:text-blue-400 mb-2">
                <Activity size={24} />
                <h2 className="font-bold text-lg">What are you feeling?</h2>
              </div>
              <p className="text-slate-500 dark:text-slate-400 text-sm">Describe your symptoms in detail for a more accurate analysis.</p>
              
              <div className="relative">
                <textarea
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-700 rounded-2xl p-4 min-h-[150px] focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white pr-12"
                  placeholder={isListening ? "Listening..." : "e.g. I have a sharp pain in my lower back that started yesterday..."}
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                />
                <button
                  onClick={toggleListening}
                  className={`absolute right-3 bottom-3 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                    isListening 
                      ? 'bg-red-500 text-white animate-pulse' 
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-600'
                  }`}
                  title={isListening ? "Stop listening" : "Speak symptoms"}
                >
                  {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {commonSymptoms.map(s => (
                  <button
                    key={s}
                    onClick={() => addSymptom(s)}
                    className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-medium px-3 py-2 rounded-full hover:bg-blue-50 dark:hover:bg-blue-900/40 hover:text-blue-600 dark:hover:text-blue-400 transition-all"
                  >
                    + {s}
                  </button>
                ))}
              </div>

              <button
                onClick={handleAnalyze}
                disabled={loading || !symptoms.trim()}
                className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-100 dark:shadow-none flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? 'Analyzing...' : <><Search size={20} /> Analyze Symptoms</>}
              </button>
            </div>

            <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-2xl flex gap-3 text-amber-800 dark:text-amber-400 text-sm border border-amber-100 dark:border-amber-800/50">
              <AlertCircle size={20} className="shrink-0" />
              <p>This tool is for information only. If you have severe symptoms like chest pain or difficulty breathing, seek emergency care immediately.</p>
            </div>
          </>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm prose prose-slate dark:prose-invert max-w-none">
              <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 mb-4">
                <CheckCircle2 size={24} />
                <h2 className="font-bold text-lg m-0">Analysis Result</h2>
              </div>
              <ReadMore text={result} maxLength={500} />
            </div>

            <button
              onClick={() => setResult(null)}
              className="w-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold py-4 rounded-2xl"
            >
              Check New Symptoms
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
