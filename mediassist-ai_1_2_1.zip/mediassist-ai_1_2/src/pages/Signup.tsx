import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { User, Mail, Lock, UserPlus, ShieldCheck, Activity } from 'lucide-react';

export default function Signup() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get role from query params
  const queryParams = new URLSearchParams(location.search);
  const [role, setRole] = useState(queryParams.get('role') || 'patient');
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName: name });
      
      // Create user profile in Firestore
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        uid: userCredential.user.uid,
        name,
        email,
        role,
        createdAt: new Date().toISOString()
      });

      if (role === 'pharmacist') {
        navigate('/pharmacist');
      } else {
        navigate('/home');
      }
    } catch (err: any) {
      if (err.code === 'auth/network-request-failed') {
        setError('Network error: Please check your internet connection or disable ad-blockers and try again.');
      } else {
        setError(err.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col p-6">
      <div className="mt-12 mb-8">
        <h2 className="text-3xl font-bold text-slate-900">Create Account</h2>
        <p className="text-slate-500">Join MediAssist AI today</p>
      </div>

      {error && (
        <div className="bg-red-50 text-red-600 p-4 rounded-xl mb-6 text-sm flex flex-col gap-2">
          <span>{error}</span>
          {error.includes('Network error') && (
            <button 
              onClick={() => window.location.reload()} 
              className="text-red-700 font-bold underline text-left"
            >
              Click here to refresh the page
            </button>
          )}
        </div>
      )}

      <form onSubmit={handleSignup} className="space-y-4">
        <div className="grid grid-cols-2 gap-4 mb-2">
          <button
            type="button"
            onClick={() => setRole('patient')}
            className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${
              role === 'patient' 
                ? 'border-emerald-600 bg-emerald-50 text-emerald-600' 
                : 'border-slate-100 bg-white text-slate-400'
            }`}
          >
            <Activity size={24} />
            <span className="text-xs font-bold">Patient</span>
          </button>
          <button
            type="button"
            onClick={() => setRole('pharmacist')}
            className={`p-4 rounded-2xl border-2 flex flex-col items-center gap-2 transition-all ${
              role === 'pharmacist' 
                ? 'border-blue-600 bg-blue-50 text-blue-600' 
                : 'border-slate-100 bg-white text-slate-400'
            }`}
          >
            <ShieldCheck size={24} />
            <span className="text-xs font-bold">Pharmacist</span>
          </button>
        </div>

        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Full Name"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="email"
            placeholder="Email Address"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="relative">
          <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="password"
            placeholder="Password"
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-emerald-600 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
        >
          {loading ? 'Creating Account...' : <><UserPlus size={20} /> Sign Up</>}
        </button>
      </form>

      <p className="mt-auto text-center text-slate-500 pb-6">
        Already have an account? <Link to="/login" className="text-emerald-600 font-bold">Log In</Link>
      </p>
    </div>
  );
}
