import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Camera, Upload, Info, CheckCircle2, AlertTriangle, Search, Check, Loader2, Sparkles, Database, Scan, Edit2, X, Save, Plus, FileCheck } from 'lucide-react';
import { logActivity } from '../utils/activityLogger';
import { enhancedScanPrescription, predictMedicineFromPattern } from '../services/gemini';
import { useSettings } from '../context/SettingsContext';
import { fuzzySearchMedicines, expandShortForm, addMedicineWithAI, getAllMedicines } from '../services/medicineService';
import { Medicine } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';

interface ExtractedMedicine {
  rawText: string;
  medicine_name: string;
  generic_name: string;
  dosage_form: string;
  strength: string;
  frequency: string;
  duration: string;
  confidence_score: number;
  status: 'Valid' | 'Uncertain' | 'Invalid';
  confidence: 'High' | 'Medium' | 'Low';
  suggestions: { medicine: Medicine; score: number; confidence: 'High' | 'Medium' | 'Low' }[];
  aiPrediction?: { predictedName: string; genericName: string; confidence: string; reason: string };
}

export default function PrescriptionScanner() {
  const navigate = useNavigate();
  const { language } = useSettings();
  const [image, setImage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<ExtractedMedicine[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [pipelineStep, setPipelineStep] = useState<string>('');
  const [confirmedMedicines, setConfirmedMedicines] = useState<{ [key: number]: Medicine | null }>({});
  const [allMedicines, setAllMedicines] = useState<Medicine[]>([]);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<ExtractedMedicine | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [doctorNotes, setDoctorNotes] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSavePrescription = async () => {
    if (!extractedData || extractedData.length === 0) return;
    if (!auth.currentUser) {
      alert('Please log in to save prescriptions.');
      return;
    }

    setIsSaving(true);
    try {
      const prescriptionData = {
        patientId: auth.currentUser.uid,
        doctorId: 'scanned-self', // Marker for self-scanned prescriptions
        medicines: extractedData.map((med, index) => {
          const confirmed = confirmedMedicines[index];
          return {
            name: confirmed ? confirmed.name : med.medicine_name,
            dosage: med.strength || '',
            frequency: med.frequency || '',
            duration: med.duration || '',
            genericName: confirmed ? confirmed.genericName : med.generic_name || ''
          };
        }),
        notes: doctorNotes,
        date: new Date().toISOString(),
        createdAt: new Date().toISOString()
      };

      await addDoc(collection(db, 'prescriptions'), prescriptionData);
      
      logActivity('Prescription Scanner', 'Saved prescription to Firestore');
      alert('Prescription saved successfully! 📄');
      navigate('/patient-profile'); // Redirect to profile or a prescriptions list page if it exists
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'prescriptions');
    } finally {
      setIsSaving(false);
    }
  };

  useEffect(() => {
    const fetchMedicines = async () => {
      try {
        const meds = await getAllMedicines();
        setAllMedicines(meds);
      } catch (error) {
        console.error("Failed to fetch medicines:", error);
      }
    };
    fetchMedicines();
  }, []);

  const cleanText = (text: string): string => {
    if (!text) return '';
    // Remove noise, common prescription symbols that AI might misinterpret, and normalize
    return text
      .replace(/[^\w\s\-\/\.]/g, '') // Keep alphanumeric, space, dash, slash, dot
      .replace(/\s+/g, ' ') // Normalize spaces
      .trim();
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setExtractedData(null);
        setConfirmedMedicines({});
      };
      reader.readAsDataURL(file);
    }
  };

  const compressImage = (base64: string): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1600;
        const MAX_HEIGHT = 1600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
    });
  };

  const handleScan = async () => {
    if (!image) return;
    
    logActivity('Prescription Scanner', 'Started optimized intelligent scan');
    setLoading(true);
    setExtractedData(null);

    try {
      // ✅ STEP 0: IMAGE COMPRESSION
      setPipelineStep('Optimizing image...');
      const compressedImage = await compressImage(image);

      // ✅ STEP 1: OCR TEXT EXTRACTION (PRIMARY)
      setPipelineStep('Extracting text from image...');
      const jsonStr = await enhancedScanPrescription(compressedImage, language);
      
      let parsed: any = {};
      try {
        const cleaned = (jsonStr || "{}").replace(/```json/g, '').replace(/```/g, '').trim();
        parsed = JSON.parse(cleaned);
      } catch (e) {
        console.error("Failed to parse OCR response:", e);
        alert('Could not decode the prescription data. Please ensure the image is clear and try again.');
        setLoading(false);
        return;
      }
      
      if (parsed.status === 'RE_UPLOAD_REQUIRED') {
        alert('Prescription not clearly readable. Please re-upload a clearer image.');
        setLoading(false);
        return;
      }

      const rawMedicines = (parsed.medicines || []) as any[];
      setPipelineStep(`Processing ${rawMedicines.length} medicines in parallel...`);

      // ✅ PARALLEL PROCESSING: Steps 2, 3, and 4
      const processedMedicines = await Promise.all(rawMedicines.map(async (med) => {
        const cleanedRaw = cleanText(med.rawText);
        const cleanedName = cleanText(med.medicine_name);

        // ✅ STEP 2: PARTIAL WORD / SHORT FORM DETECTION
        const expandedName = expandShortForm(cleanedName);

        // ✅ STEP 3: DATABASE MATCHING (CORE)
        const fuzzyResults = await fuzzySearchMedicines(expandedName);

        // ✅ STEP 4: AI + GOOGLE SEARCH FALLBACK
        let aiPrediction = undefined;
        let confidence: 'High' | 'Medium' | 'Low' = 'Low';

        if (fuzzyResults.length > 0) {
          confidence = fuzzyResults[0].confidence;
        }

        if (med.confidence_score > 85 || med.status === 'Valid') {
          if (confidence === 'Low') confidence = 'Medium';
          if (med.confidence_score > 95) confidence = 'High';
        }

        // Parallel AI fallback if needed
        if (confidence !== 'High') {
          try {
            const aiJson = await predictMedicineFromPattern(expandedName, language);
            const parsedAi = JSON.parse(aiJson);
            
            if (parsedAi.predictedName && parsedAi.predictedName !== 'Uncertain') {
              aiPrediction = parsedAi;
              if (parsedAi.confidence === 'High' && confidence === 'Low') {
                confidence = 'Medium';
              }
            }
          } catch (e) {
            console.error("AI Fallback failed:", e);
          }
        }

        return {
          ...med,
          rawText: cleanedRaw,
          medicine_name: expandedName,
          confidence,
          suggestions: fuzzyResults,
          aiPrediction
        };
      }));

      // 🚨 FINAL FALLBACK: Check if we have any readable results
      if (processedMedicines.length === 0) {
        setExtractedData([]);
        setLoading(false);
        return;
      }

      setExtractedData(processedMedicines);
      
      // Initialize confirmed medicines
      const initialConfirmed: { [key: number]: Medicine | null } = {};
      processedMedicines.forEach((med, index) => {
        // Auto-confirm if High confidence
        if (med.confidence === 'High' && med.suggestions.length > 0) {
          initialConfirmed[index] = med.suggestions[0].medicine;
        } else {
          initialConfirmed[index] = null;
        }
      });
      setConfirmedMedicines(initialConfirmed);

      // Log activity
      logActivity('Prescription Scanner', `Scanned prescription with ${processedMedicines.length} medicines detected.`, `Medicines: ${processedMedicines.map(m => m.medicine_name).join(', ')}`);

    } catch (error) {
      console.error(error);
      alert('Error scanning prescription. Please try again.');
    } finally {
      setLoading(false);
      setPipelineStep('');
    }
  };

  const getConfidenceColor = (conf: string) => {
    switch (conf) {
      case 'High': return 'text-emerald-600 bg-emerald-50 border-emerald-100';
      case 'Medium': return 'text-amber-600 bg-amber-50 border-amber-100';
      case 'Low': return 'text-rose-600 bg-rose-50 border-rose-100';
      default: return 'text-slate-600 bg-slate-50 border-slate-100';
    }
  };

  const handleConfirm = (index: number, medicine: Medicine) => {
    setConfirmedMedicines(prev => ({ ...prev, [index]: medicine }));
  };

  const handleEdit = (index: number, medicine: ExtractedMedicine) => {
    setEditingIndex(index);
    setEditForm({ ...medicine });
    setSearchTerm(medicine.medicine_name);
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setEditForm(null);
    setSearchTerm('');
  };

  const handleSaveEdit = async () => {
    if (editingIndex === null || !editForm || !extractedData) return;

    const updatedData = [...extractedData];
    
    // Check if medicine name changed and update generic name if possible
    if (editForm.medicine_name !== extractedData[editingIndex].medicine_name) {
      const match = allMedicines.find(m => m.name.toLowerCase() === editForm.medicine_name.toLowerCase());
      if (match) {
        editForm.generic_name = match.genericName;
        // Update suggestions too
        const fuzzyResults = await fuzzySearchMedicines(editForm.medicine_name);
        editForm.suggestions = fuzzyResults;
      }
    }

    updatedData[editingIndex] = editForm;
    setExtractedData(updatedData);
    setEditingIndex(null);
    setEditForm(null);
    setSearchTerm('');
  };

  const filteredMedicines = allMedicines.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.genericName.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, 5);

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900">Smart Prescription Decoder</h1>
      </header>

      <div className="p-6 space-y-6">
        {extractedData ? (
          <div className="space-y-6">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center text-orange-600">
                  <Sparkles size={20} />
                </div>
                <div>
                  <p className="font-bold text-slate-900">AI Analysis Complete</p>
                  <p className="text-xs text-slate-500">{extractedData.length} medicines detected</p>
                </div>
              </div>
              <button 
                onClick={() => { setExtractedData(null); setImage(null); }}
                className="text-xs font-bold text-orange-600 bg-orange-50 px-3 py-2 rounded-lg"
              >
                Reset
              </button>
            </div>

            <div className="space-y-4">
              {extractedData.length === 0 && (
                <div className="bg-white p-8 rounded-3xl border border-dashed border-slate-200 text-center space-y-4">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
                    <FileText size={32} />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">No Medicines Detected</p>
                    <p className="text-sm text-slate-500">We couldn't clearly read any medicines from this prescription.</p>
                  </div>
                  <button 
                    onClick={() => {
                      const newItem: ExtractedMedicine = {
                        rawText: 'Manual Entry',
                        medicine_name: '',
                        generic_name: '',
                        dosage_form: 'Tablet',
                        strength: '',
                        frequency: '',
                        duration: '',
                        confidence_score: 100,
                        status: 'Valid',
                        confidence: 'High',
                        suggestions: []
                      };
                      setExtractedData([newItem]);
                      setEditingIndex(0);
                      setEditForm(newItem);
                      setSearchTerm('');
                    }}
                    className="bg-slate-900 text-white font-bold px-6 py-3 rounded-xl inline-flex items-center gap-2 mx-auto"
                  >
                    <Plus size={18} /> Add Medicine Manually
                  </button>
                </div>
              )}

              {extractedData.map((item, index) => {
                const confirmedMed = confirmedMedicines[index];
                const confColor = getConfidenceColor(item.confidence);

                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    key={index} 
                    className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden"
                  >
                    <div className="p-5 space-y-4">
                      {editingIndex === index ? (
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <h3 className="font-bold text-slate-900">Edit Medicine Details</h3>
                            <button onClick={handleCancelEdit} className="text-slate-400 hover:text-slate-600">
                              <X size={20} />
                            </button>
                          </div>

                          <div className="space-y-3">
                            <div className="relative">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Medicine Name</label>
                              <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                                <input 
                                  type="text"
                                  value={searchTerm}
                                  onChange={(e) => {
                                    setSearchTerm(e.target.value);
                                    setEditForm(prev => prev ? { ...prev, medicine_name: e.target.value } : null);
                                  }}
                                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                  placeholder="Search or type medicine name..."
                                />
                              </div>
                              {searchTerm && !allMedicines.some(m => m.name.toLowerCase() === searchTerm.toLowerCase()) && (
                                <div className="absolute z-20 left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
                                  {filteredMedicines.map((med) => (
                                    <button
                                      key={med.id}
                                      onClick={() => {
                                        setEditForm(prev => prev ? { 
                                          ...prev, 
                                          medicine_name: med.name,
                                          generic_name: med.genericName 
                                        } : null);
                                        setSearchTerm(med.name);
                                      }}
                                      className="w-full text-left px-4 py-2 text-sm hover:bg-slate-50 border-b border-slate-100 last:border-0"
                                    >
                                      <p className="font-bold text-slate-800">{med.name}</p>
                                      <p className="text-[10px] text-slate-500">{med.genericName}</p>
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Strength</label>
                                <input 
                                  type="text"
                                  value={editForm?.strength || ''}
                                  onChange={(e) => setEditForm(prev => prev ? { ...prev, strength: e.target.value } : null)}
                                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                  placeholder="e.g. 500mg"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Frequency</label>
                                <input 
                                  type="text"
                                  value={editForm?.frequency || ''}
                                  onChange={(e) => setEditForm(prev => prev ? { ...prev, frequency: e.target.value } : null)}
                                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                  placeholder="e.g. 1-0-1"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Duration</label>
                              <input 
                                type="text"
                                value={editForm?.duration || ''}
                                onChange={(e) => setEditForm(prev => prev ? { ...prev, duration: e.target.value } : null)}
                                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                                placeholder="e.g. 5 days"
                              />
                            </div>
                          </div>

                          <button 
                            onClick={handleSaveEdit}
                            className="w-full bg-slate-900 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2"
                          >
                            <Save size={18} /> Save Changes
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="flex justify-between items-start">
                            <div className="space-y-1">
                              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Extracted Pattern</p>
                              <p className="font-mono text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-100 text-xs">
                                {item.rawText}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <button 
                                onClick={() => handleEdit(index, item)}
                                className="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                                title="Edit manually"
                              >
                                <Edit2 size={16} />
                              </button>
                              <div className={`px-3 py-1 rounded-full text-[10px] font-bold border flex items-center gap-1 ${confColor}`}>
                                {item.confidence === 'High' ? <CheckCircle2 size={12} /> : item.confidence === 'Medium' ? <Search size={12} /> : <AlertTriangle size={12} />}
                                {item.confidence} Confidence
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                            <div className="space-y-0.5">
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Name</p>
                              <p className="text-sm font-bold text-slate-900">{item.medicine_name}</p>
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Strength</p>
                              <p className="text-sm font-bold text-slate-700">{item.strength || 'N/A'}</p>
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Frequency</p>
                              <p className="text-sm font-bold text-slate-700">{item.frequency || 'N/A'}</p>
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Duration</p>
                              <p className="text-sm font-bold text-slate-700">{item.duration || 'N/A'}</p>
                            </div>
                          </div>

                          {item.generic_name && (
                            <div className="space-y-1">
                              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Generic Name</p>
                              <p className="text-xs font-medium text-slate-600 italic">{item.generic_name}</p>
                            </div>
                          )}

                          {item.status === 'Uncertain' && (
                            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100 flex gap-2 text-amber-800 text-[11px]">
                              <Search size={14} className="shrink-0" />
                              <p>AI is uncertain about this medicine. Please verify with a physical copy or your doctor.</p>
                            </div>
                          )}

                          {item.confidence === 'Low' && (
                            <div className="bg-rose-50 p-3 rounded-xl border border-rose-100 flex gap-2 text-rose-800 text-[11px]">
                              <AlertTriangle size={14} className="shrink-0" />
                              <p>Handwriting is unclear. AI predicted based on patterns. Please verify carefully with your doctor.</p>
                            </div>
                          )}

                          {item.aiPrediction && item.confidence !== 'High' && (
                            <div className="bg-orange-50 p-3 rounded-xl border border-orange-100 space-y-2">
                              <p className="text-[10px] font-bold text-orange-600 uppercase tracking-widest flex items-center gap-1">
                                <Sparkles size={12} /> AI Prediction Fallback
                              </p>
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="text-sm font-bold text-slate-800">{item.aiPrediction.predictedName}</p>
                                  <p className="text-[10px] text-slate-500">{item.aiPrediction.genericName}</p>
                                </div>
                                <button 
                                  onClick={async () => {
                                    setLoading(true);
                                    try {
                                      const med = await addMedicineWithAI(item.aiPrediction!.predictedName);
                                      handleConfirm(index, med);
                                    } catch (e) {
                                      console.error(e);
                                    } finally {
                                      setLoading(false);
                                    }
                                  }}
                                  className="text-[10px] font-bold bg-orange-600 text-white px-3 py-1.5 rounded-lg"
                                >
                                  Use This
                                </button>
                              </div>
                              <p className="text-[9px] text-slate-500 italic">Reason: {item.aiPrediction.reason}</p>
                            </div>
                          )}

                          <div className="space-y-2">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                              <Database size={12} /> Database Matches
                            </p>
                            
                            {item.suggestions.length > 0 ? (
                              <div className="space-y-2">
                                {item.suggestions.map((suggestion) => (
                                  <button
                                    key={suggestion.medicine.id}
                                    onClick={() => handleConfirm(index, suggestion.medicine)}
                                    className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between ${
                                      confirmedMed?.id === suggestion.medicine.id 
                                        ? 'bg-emerald-50 border-emerald-200 ring-2 ring-emerald-500/20' 
                                        : 'bg-white border-slate-200 hover:border-orange-300'
                                    }`}
                                  >
                                    <div className="flex items-center gap-3">
                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                                        suggestion.confidence === 'High' ? 'bg-emerald-100 text-emerald-600' : 
                                        suggestion.confidence === 'Medium' ? 'bg-amber-100 text-amber-600' : 'bg-rose-100 text-rose-600'
                                      }`}>
                                        {Math.round(suggestion.score * 100)}%
                                      </div>
                                      <div>
                                        <p className="font-bold text-slate-800 text-sm">{suggestion.medicine.name}</p>
                                        <p className="text-[10px] text-slate-500">{suggestion.medicine.genericName}</p>
                                      </div>
                                    </div>
                                    {confirmedMed?.id === suggestion.medicine.id && (
                                      <CheckCircle2 size={20} className="text-emerald-600" />
                                    )}
                                  </button>
                                ))}
                              </div>
                            ) : (
                              <div className="bg-slate-50 p-4 rounded-2xl border border-dashed border-slate-200 text-center space-y-3">
                                <p className="text-xs text-slate-500 italic">No direct database matches found for "{item.medicine_name}".</p>
                                <div className="flex gap-2 justify-center">
                                  <button 
                                    onClick={async () => {
                                      setLoading(true);
                                      setPipelineStep(`Adding ${item.medicine_name} to database...`);
                                      try {
                                        const med = await addMedicineWithAI(item.medicine_name);
                                        handleConfirm(index, med);
                                        // Update local medicines list
                                        const meds = await getAllMedicines();
                                        setAllMedicines(meds);
                                      } catch (e) {
                                        console.error(e);
                                        alert('Failed to add medicine to database.');
                                      } finally {
                                        setLoading(false);
                                        setPipelineStep('');
                                      }
                                    }}
                                    className="text-[10px] font-bold bg-slate-900 text-white px-3 py-2 rounded-lg flex items-center gap-1"
                                  >
                                    <Database size={12} /> Add to Database
                                  </button>
                                  <button 
                                    onClick={() => navigate('/medicines')}
                                    className="text-[10px] font-bold text-orange-600 bg-orange-50 px-3 py-2 rounded-lg"
                                  >
                                    Search Full Database
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  </motion.div>
                );
              })}

              {extractedData.length > 0 && (
                <div className="flex justify-center pt-2">
                  <button 
                    onClick={() => {
                      const newItem: ExtractedMedicine = {
                        rawText: 'Manual Entry',
                        medicine_name: '',
                        generic_name: '',
                        dosage_form: 'Tablet',
                        strength: '',
                        frequency: '',
                        duration: '',
                        confidence_score: 100,
                        status: 'Valid',
                        confidence: 'High',
                        suggestions: []
                      };
                      setExtractedData(prev => [...(prev || []), newItem]);
                      const newIndex = extractedData.length;
                      setEditingIndex(newIndex);
                      setEditForm(newItem);
                      setSearchTerm('');
                    }}
                    className="text-sm font-bold text-slate-600 flex items-center gap-2 hover:text-slate-900 transition-colors bg-slate-100 px-4 py-2 rounded-xl"
                  >
                    <Plus size={16} /> Add Another Medicine
                  </button>
                </div>
              )}
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-3">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Doctor's Notes / Additional Info</label>
              <textarea 
                value={doctorNotes}
                onChange={(e) => setDoctorNotes(e.target.value)}
                placeholder="Add any special instructions or notes from your doctor..."
                className="w-full bg-slate-50 border border-slate-200 rounded-2xl p-4 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 min-h-[100px]"
              />
            </div>

            <div className="pt-4 pb-12 space-y-3">
              <button
                onClick={handleSavePrescription}
                disabled={isSaving || extractedData.length === 0}
                className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSaving ? (
                  <><Loader2 size={20} className="animate-spin" /> Saving...</>
                ) : (
                  <><FileCheck size={20} /> Save Prescription to Records</>
                )}
              </button>
              <button
                onClick={() => { setExtractedData(null); setImage(null); setDoctorNotes(''); }}
                className="w-full bg-slate-900 text-white font-bold py-4 rounded-2xl shadow-lg"
              >
                Scan Another Prescription
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <div className="aspect-[3/4] bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center overflow-hidden relative">
              {image ? (
                <img src={image} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <>
                  <FileText size={48} className="text-slate-300 mb-2" />
                  <p className="text-slate-400 text-sm">Take a photo of your prescription</p>
                </>
              )}
              <input 
                type="file" 
                accept="image/*" 
                capture="environment"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleImageUpload}
              />
            </div>

            <div className="flex gap-4">
              <label className="flex-1 bg-slate-100 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 cursor-pointer">
                <Upload size={20} /> Upload
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
              <button
                onClick={handleScan}
                disabled={!image || loading}
                className="flex-[2] bg-orange-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-100 flex items-center justify-center gap-2 disabled:opacity-50 relative overflow-hidden"
              >
                {loading ? (
                  <div className="flex flex-col items-center gap-1">
                    <div className="flex items-center gap-2">
                      <Loader2 size={20} className="animate-spin" />
                      <span>Processing...</span>
                    </div>
                    <span className="text-[10px] opacity-80 font-normal animate-pulse">{pipelineStep}</span>
                  </div>
                ) : (
                  <><FileText size={20} /> Decode Prescription</>
                )}
              </button>
            </div>

            <div className="bg-blue-50 p-4 rounded-2xl flex gap-3 text-blue-800 text-xs border border-blue-100">
              <Info size={18} className="shrink-0" />
              <p>Our AI will attempt to read the handwriting, detect medicine types, and predict medicine names from partial text. Always verify with your pharmacist.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
