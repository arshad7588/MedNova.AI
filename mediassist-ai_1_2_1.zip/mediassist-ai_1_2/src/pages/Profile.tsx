import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';
import { User, Calendar, Mail, Phone, AlertCircle, Activity, Save, LogOut } from 'lucide-react';
import { UserProfile } from '../types';
import { signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Profile() {
  const { user, userProfile, loading: authLoading } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (userProfile) {
      setProfile(userProfile);
    } else if (user) {
      setProfile({
        uid: user.uid,
        name: user.displayName || '',
        email: user.email || '',
        role: '',
        createdAt: new Date().toISOString()
      });
    }
  }, [user, userProfile]);

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    setSaving(true);
    try {
      await setDoc(doc(db, 'users', user.uid), { ...profile }, { merge: true });
      alert('Profile updated successfully!');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/');
  };

  if (authLoading) return <div className="p-6 text-center">Loading profile...</div>;

  return (
    <div className="p-6 pb-24">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-slate-900">My Profile</h1>
        <button onClick={handleLogout} className="text-red-500 flex items-center gap-1 font-medium">
          <LogOut size={18} /> Logout
        </button>
      </header>

      <form onSubmit={handleUpdate} className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <User size={18} className="text-emerald-600" /> Personal Info
          </h3>
          
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Full Name</label>
            <input 
              type="text" 
              className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={profile?.name || ''}
              onChange={(e) => setProfile(prev => prev ? { ...prev, name: e.target.value } : null)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Role</label>
            <select 
              className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              value={profile?.role || ''}
              onChange={(e) => setProfile(prev => prev ? { ...prev, role: e.target.value as any } : null)}
            >
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
              <option value="pharmacy">Pharmacy</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Age</label>
              <input 
                type="number" 
                className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={profile?.age || ''}
                onChange={(e) => setProfile(prev => prev ? { ...prev, age: parseInt(e.target.value) } : null)}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Gender</label>
              <select 
                className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                value={profile?.gender || ''}
                onChange={(e) => setProfile(prev => prev ? { ...prev, gender: e.target.value } : null)}
              >
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <Activity size={18} className="text-emerald-600" /> Medical Info
          </h3>
          
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Allergies</label>
            <textarea 
              className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="e.g. Penicillin, Peanuts"
              value={profile?.allergies || ''}
              onChange={(e) => setProfile(prev => prev ? { ...prev, allergies: e.target.value } : null)}
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Chronic Diseases</label>
            <textarea 
              className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              placeholder="e.g. Diabetes, Hypertension"
              value={profile?.chronicDiseases || ''}
              onChange={(e) => setProfile(prev => prev ? { ...prev, chronicDiseases: e.target.value } : null)}
            />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-800 flex items-center gap-2">
            <AlertCircle size={18} className="text-red-500" /> Emergency Contact
          </h3>
          <input 
            type="text" 
            placeholder="Name & Phone Number"
            className="w-full bg-slate-50 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            value={profile?.emergencyContact || ''}
            onChange={(e) => setProfile(prev => prev ? { ...prev, emergencyContact: e.target.value } : null)}
          />
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full bg-emerald-600 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
        >
          <Save size={20} /> {saving ? 'Saving...' : 'Save Changes'}
        </button>
      </form>
    </div>
  );
}
