import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, FileText, Plus, Trash2, Calendar } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, orderBy } from 'firebase/firestore';
import { HealthRecord } from '../types';
import ReadMore from '../components/ReadMore';

export default function HealthRecords() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<HealthRecord[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newRecord, setNewRecord] = useState({ title: '', type: 'prescription', content: '' });

  useEffect(() => {
    if (!auth.currentUser) return;
    
    // Fetch Health Records
    const qRecords = query(collection(db, 'healthRecords'), where('userId', '==', auth.currentUser.uid));
    const unsubscribeRecords = onSnapshot(qRecords, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HealthRecord));
      setRecords(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'healthRecords');
    });

    return () => {
      unsubscribeRecords();
    };
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    const path = 'healthRecords';
    try {
      await addDoc(collection(db, path), {
        userId: auth.currentUser.uid,
        ...newRecord,
        date: new Date().toISOString()
      });
      setShowAdd(false);
      setNewRecord({ title: '', type: 'prescription', content: '' });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'healthRecords', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `healthRecords/${id}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-slate-600">
            <ArrowLeft size={24} />
          </button>
          <h1 className="font-bold text-slate-900">Health Records</h1>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-100"
        >
          <Plus size={24} />
        </button>
      </header>

      <div className="p-6">
        <div className="space-y-4">
          {records.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                <FileText size={32} />
              </div>
              <p className="text-slate-400">No records stored yet.</p>
            </div>
          ) : (
            records.map((rec) => (
              <div key={rec.id} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                  <FileText size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-800">{rec.title}</h3>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {new Date(rec.date).toLocaleDateString()}</span>
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-[10px] uppercase font-bold">{rec.type.replace('_', ' ')}</span>
                  </div>
                </div>
                <button onClick={() => handleDelete(rec.id!)} className="text-slate-300 hover:text-red-500 p-2">
                  <Trash2 size={18} />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-sm rounded-[40px] p-8 space-y-6">
            <h2 className="text-2xl font-bold text-slate-900">Add Record</h2>
            <form onSubmit={handleAdd} className="space-y-4">
              <input 
                type="text" 
                placeholder="Title (e.g. Blood Test)" 
                className="w-full bg-slate-50 rounded-2xl p-4"
                value={newRecord.title}
                onChange={(e) => setNewRecord({ ...newRecord, title: e.target.value })}
                required
              />
              <select 
                className="w-full bg-slate-50 rounded-2xl p-4"
                value={newRecord.type}
                onChange={(e) => setNewRecord({ ...newRecord, type: e.target.value as any })}
              >
                <option value="prescription">Prescription</option>
                <option value="lab_report">Lab Report</option>
                <option value="other">Other</option>
              </select>
              <textarea 
                placeholder="Notes or content..." 
                className="w-full bg-slate-50 rounded-2xl p-4 min-h-[100px]"
                value={newRecord.content}
                onChange={(e) => setNewRecord({ ...newRecord, content: e.target.value })}
              />
              <div className="flex gap-3">
                <button type="button" onClick={() => setShowAdd(false)} className="flex-1 bg-slate-100 text-slate-600 font-bold py-4 rounded-2xl">Cancel</button>
                <button type="submit" className="flex-1 bg-emerald-600 text-white font-bold py-4 rounded-2xl">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
