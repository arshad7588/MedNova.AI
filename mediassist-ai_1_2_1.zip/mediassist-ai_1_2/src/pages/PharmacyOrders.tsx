import React from 'react';
import { Package, ShoppingBag, Clock, CheckCircle } from 'lucide-react';

export default function PharmacyOrders() {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Pharmacy Orders</h1>
        <p className="text-slate-500">Manage prescription and medicine orders</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 mb-4">
            <ShoppingBag size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">12</div>
          <div className="text-sm text-slate-500">New Orders</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 mb-4">
            <Clock size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">5</div>
          <div className="text-sm text-slate-500">Pending</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
            <CheckCircle size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">48</div>
          <div className="text-sm text-slate-500">Completed</div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 mb-4">
            <Package size={24} />
          </div>
          <div className="text-2xl font-bold text-slate-900">3</div>
          <div className="text-sm text-slate-500">Out for Delivery</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-semibold text-slate-900">Recent Orders</h2>
        </div>
        <div className="p-6">
          <p className="text-slate-500 text-center py-12">No orders found.</p>
        </div>
      </div>
    </div>
  );
}
