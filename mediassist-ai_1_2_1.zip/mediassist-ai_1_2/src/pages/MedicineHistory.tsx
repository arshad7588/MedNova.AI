import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Pill, Search, Plus, Package, ChevronRight, Sparkles, AlertCircle, ShoppingCart, Filter, Star, Info } from 'lucide-react';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { Medicine } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { addMedicineWithAI } from '../services/medicineService';

export default function MedicineHistory() {
  const navigate = useNavigate();
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearchingGlobal, setIsSearchingGlobal] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const path = 'medicines';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Medicine));
      setMedicines(data);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
    return () => unsubscribe();
  }, []);

  const filteredMedicines = medicines.filter(med => 
    med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    med.genericName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (med.category && med.category.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleGlobalSearch = async () => {
    if (!searchTerm.trim()) return;
    setIsSearchingGlobal(true);
    setSearchError('');
    try {
      const newMed = await addMedicineWithAI(searchTerm);
      if (newMed.id) {
        navigate(`/medicine/${newMed.id}`);
      }
    } catch (err) {
      console.error("Global search error:", err);
      setSearchError('Could not find information for this medicine. Please check the spelling.');
    } finally {
      setIsSearchingGlobal(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFDFD] pb-24 font-sans">
      {/* Premium Header */}
      <header className="bg-white/80 backdrop-blur-xl p-4 border-b border-slate-100 flex items-center justify-between sticky top-0 z-30 shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-50 text-slate-600 transition-colors">
            <ArrowLeft size={22} />
          </button>
          <div>
            <h1 className="font-black text-slate-900 text-xl tracking-tight m-0">Medicine History</h1>
            <p className="text-[10px] uppercase tracking-widest text-emerald-600 font-black leading-none">Your Records</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => navigate('/scanner')}
            className="w-10 h-10 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-emerald-100 active:scale-90 transition-transform"
          >
            <Plus size={22} />
          </button>
        </div>
      </header>

      <div className="p-6 space-y-8">
        {/* Search & Filter Section */}
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="relative flex-1 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={20} />
              <input 
                type="text"
                placeholder="Search medicines, brands..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-50 border-none rounded-2xl py-4 pl-12 pr-4 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 shadow-inner transition-all text-sm font-medium"
              />
            </div>
            <button className="w-14 h-14 bg-white border border-slate-100 rounded-2xl flex items-center justify-center text-slate-600 shadow-sm active:scale-95 transition-transform">
              <Filter size={20} />
            </button>
          </div>
          
          <AnimatePresence mode="wait">
            {searchTerm.trim().length > 2 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 10 }}
                className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-[2.5rem] p-6 text-white shadow-2xl relative overflow-hidden group"
              >
                <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
                  <Sparkles size={80} />
                </div>
                
                <div className="relative z-10 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                      <Sparkles size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-base m-0">Global AI Search</h4>
                      <p className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.2em]">Instant Database Access</p>
                    </div>
                  </div>
                  
                  <p className="text-slate-300 text-sm leading-relaxed">
                    Can't find "{searchTerm}"? Our AI can fetch details, pricing, and alternatives from our global medical database instantly.
                  </p>
                  
                  <button 
                    onClick={handleGlobalSearch}
                    disabled={isSearchingGlobal}
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50 shadow-lg shadow-emerald-500/20"
                  >
                    {isSearchingGlobal ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Fetching Data...
                      </>
                    ) : (
                      <>
                        <Search size={18} />
                        Search Global Database
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {searchError && (
            <motion.div 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-red-50 text-red-600 p-4 rounded-2xl text-xs font-bold flex items-center gap-3 border border-red-100"
            >
              <AlertCircle size={16} /> {searchError}
            </motion.div>
          )}
        </div>

        {/* Categories (Simulated) */}
        {!searchTerm && (
          <div className="space-y-4">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest px-2">Shop by Category</h3>
            <div className="flex gap-3 overflow-x-auto pb-2 custom-scrollbar no-scrollbar">
              {['All', 'Pain Relief', 'Antibiotics', 'Vitamins', 'Skin Care', 'Baby Care'].map((cat) => (
                <button key={cat} className={`px-6 py-3 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${cat === 'All' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'bg-white text-slate-600 border border-slate-100 hover:bg-slate-50'}`}>
                  {cat}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Product Grid */}
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">
              {searchTerm ? 'Search Results' : 'Featured Medicines'}
            </h3>
            <span className="text-[10px] text-slate-400 font-bold">{filteredMedicines.length} Items</span>
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-emerald-600"></div>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Loading History...</p>
            </div>
          ) : filteredMedicines.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-[3rem] border border-slate-100 p-10 shadow-sm">
              <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6 text-slate-200">
                <Package size={40} />
              </div>
              <h3 className="font-black text-slate-900 text-xl mb-2 tracking-tight">Product not found</h3>
              <p className="text-slate-500 text-sm mb-8 leading-relaxed">Try searching with a generic name or use our AI Global Search above.</p>
              <button 
                onClick={() => navigate('/scanner')}
                className="bg-slate-900 text-white font-bold px-10 py-4 rounded-2xl shadow-xl active:scale-95 transition-transform"
              >
                Scan Medicine
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {filteredMedicines.map((med) => (
                <motion.div
                  layout
                  key={med.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col group hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-300"
                >
                  <div 
                    onClick={() => navigate(`/medicine/${med.id}`)}
                    className="relative aspect-square bg-slate-50 flex items-center justify-center p-6 cursor-pointer overflow-hidden"
                  >
                    <div className="absolute top-3 left-3 z-10">
                      <div className="bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1 shadow-sm">
                        <Star size={10} className="text-amber-400 fill-amber-400" />
                        <span className="text-[9px] font-black text-slate-900">4.8</span>
                      </div>
                    </div>
                    
                    {med.imageUrl ? (
                      <img 
                        src={med.imageUrl} 
                        alt={med.name} 
                        className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <Package size={48} className="text-slate-200 group-hover:scale-110 transition-transform duration-500" />
                    )}
                    
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors" />
                  </div>
                  
                    <div className="p-4 flex-1 flex flex-col gap-2">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-slate-900 truncate text-sm m-0 group-hover:text-emerald-600 transition-colors">{med.name}</h4>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider truncate mt-0.5">{med.manufacturer || 'Generic'}</p>
                      </div>
                      
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex flex-col">
                          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{med.dosage || 'N/A'}</span>
                        </div>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            navigate(`/medicine/${med.id}`);
                          }}
                          className="w-10 h-10 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center active:scale-90 transition-transform"
                        >
                          <ChevronRight size={20} />
                        </button>
                      </div>
                    </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Promotional Banner Removed */}
      </div>
    </div>
  );
}
