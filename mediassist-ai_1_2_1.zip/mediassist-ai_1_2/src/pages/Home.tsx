import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { 
  User, Plus, Search, ClipboardList, Package, Brain, Activity, FileText, MapPin,
  Stethoscope, Pill, History, FileCheck, ShieldAlert, Bell, Calculator, HeartPulse, BookOpen, Database, Globe,
  Scan, AlertTriangle, Heart, Settings as SettingsIcon, Sparkles, TrendingUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile } from '../types';
import { UserInsights, LearnedPattern } from '../services/adaptiveLearningService';

export default function Home() {
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [insights, setInsights] = useState<UserInsights | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    const fetchProfile = async () => {
      try {
        const docRef = doc(db, 'users', auth.currentUser!.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setUserProfile(docSnap.data() as UserProfile);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `users/${auth.currentUser?.uid}`);
      }
      setLoading(false);
    };

    const unsubscribeInsights = onSnapshot(doc(db, 'userInsights', auth.currentUser.uid), (doc) => {
      if (doc.exists()) {
        setInsights(doc.data() as UserInsights);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `userInsights/${auth.currentUser?.uid}`);
    });

    fetchProfile();
    return () => unsubscribeInsights();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  const role = userProfile?.role || 'patient';

  const patientFeatures = [
    { id: 'assistant', name: 'AI Health Assistant', icon: <Brain />, color: 'bg-emerald-500', path: '/assistant' },
    { id: 'symptoms', name: 'Symptom Checker', icon: <Activity />, color: 'bg-blue-500', path: '/symptoms' },
    { id: 'patient-profile', name: 'Patient Profile', icon: <User />, color: 'bg-cyan-500', path: '/patient-profile' },
    { id: 'scanner', name: 'Medicine Scanner', icon: <Scan />, color: 'bg-purple-500', path: '/scanner' },
    { id: 'prescription', name: 'Prescription OCR', icon: <FileText />, color: 'bg-orange-500', path: '/prescription' },
    { id: 'interactions', name: 'Drug Interactions', icon: <AlertTriangle />, color: 'bg-red-500', path: '/interactions' },
    { id: 'reminders', name: 'Med Reminders', icon: <Bell />, color: 'bg-pink-500', path: '/reminders' },
    { id: 'facilities', name: 'Nearby Facilities', icon: <MapPin />, color: 'bg-sky-500', path: '/facilities' },
    { id: 'calculators', name: 'Health Calculators', icon: <Calculator />, color: 'bg-indigo-500', path: '/calculators' },
    { id: 'records', name: 'Health Records', icon: <Heart />, color: 'bg-rose-500', path: '/records' },
    { id: 'library', name: 'Disease Library', icon: <BookOpen />, color: 'bg-amber-500', path: '/library' },
    { id: 'first-aid', name: 'First Aid Guide', icon: <Plus />, color: 'bg-emerald-600', path: '/first-aid' },
    { id: 'global-search', name: 'Medicine Search', icon: <Globe />, color: 'bg-sky-500', path: '/global-search' },
    { id: 'settings', name: 'Settings', icon: <SettingsIcon />, color: 'bg-slate-600', path: '/settings' },
  ];

  const pharmacyFeatures = [
    { id: 'orders', name: 'Manage Orders', icon: <Package />, color: 'bg-blue-500', path: '/pharmacy/orders' },
    { id: 'inventory', name: 'Inventory', icon: <ClipboardList />, color: 'bg-purple-500', path: '/pharmacy/inventory' },
    { id: 'assistant', name: 'AI Assistant', icon: <Brain />, color: 'bg-teal-500', path: '/assistant' },
  ];

  const doctorFeatures = [
    { id: 'prescribe', name: 'Write Prescription', icon: <FileText />, color: 'bg-blue-500', path: '/doctor/prescribe' },
    { id: 'appointments', name: 'Appointments', icon: <Activity />, color: 'bg-purple-500', path: '/doctor/appointments' },
    { id: 'assistant', name: 'AI Assistant', icon: <Brain />, color: 'bg-teal-500', path: '/assistant' },
  ];

  const features = role === 'pharmacy' ? pharmacyFeatures : role === 'doctor' ? doctorFeatures : patientFeatures;

  return (
    <div className="p-6 transition-colors duration-300">
      <header className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-slate-400 dark:text-slate-500 font-medium">Hello,</h2>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white capitalize leading-tight">{userProfile?.name || 'User'}</h1>
        </div>
        <button 
          onClick={() => navigate('/profile')}
          className="w-12 h-12 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl flex items-center justify-center text-emerald-600 dark:text-emerald-400"
        >
          <User size={24} />
        </button>
      </header>

      <div className="relative mb-8">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500" size={20} />
        <input 
          type="text" 
          placeholder="Search symptoms, medicines..."
          className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl py-4 pl-12 pr-4 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white transition-all"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        {features.map((feature, idx) => (
          <motion.button
            key={feature.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            onClick={() => navigate(feature.path)}
            className="bg-white dark:bg-slate-800 p-6 rounded-[32px] border border-slate-50 dark:border-slate-700 shadow-sm flex flex-col items-start gap-4 text-left h-full"
          >
            <div className={`${feature.color} text-white p-3 rounded-2xl shadow-lg shadow-${feature.color.split('-')[1]}-100 dark:shadow-none`}>
              {React.cloneElement(feature.icon as React.ReactElement<any>, { size: 24 })}
            </div>
            <span className="font-bold text-slate-900 dark:text-slate-200 text-sm leading-tight">{feature.name}</span>
          </motion.button>
        ))}
      </div>

      {role === 'patient' && insights && insights.patterns.length > 0 && (
        <div className="mt-8 space-y-4">
          <div className="flex items-center gap-2 px-2">
            <Sparkles className="text-emerald-600" size={20} />
            <h2 className="font-bold text-slate-900 dark:text-white">Adaptive Insights</h2>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
            {insights.patterns.map((pattern, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="min-w-[280px] bg-white dark:bg-slate-800 p-6 rounded-[32px] border border-slate-100 dark:border-slate-700 shadow-sm flex flex-col gap-3"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 rounded-2xl flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                    <TrendingUp size={20} />
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {Math.round(pattern.confidence * 100)}% Confidence
                  </span>
                </div>
                <p className="text-sm text-slate-700 dark:text-slate-300 font-medium leading-relaxed">
                  {pattern.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {role === 'patient' && (
        <div className="mt-8 bg-emerald-600 rounded-[32px] p-8 text-white relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="font-bold text-2xl mb-2">Emergency?</h3>
            <p className="text-emerald-100 text-sm mb-6 max-w-[200px]">Quickly find the nearest hospital or emergency room.</p>
            <button 
              onClick={() => navigate('/facilities?q=emergency')} 
              className="bg-white text-emerald-600 font-bold px-8 py-3 rounded-2xl text-sm shadow-lg active:scale-95 transition-all"
            >
              Find Nearest
            </button>
          </div>
          <div className="absolute -right-4 -bottom-4 opacity-10">
            <Plus size={160} />
          </div>
        </div>
      )}
    </div>
  );
}
