import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Shield, User, Activity, HeartPulse, FileText, Syringe, Coffee, FileBadge, AlertTriangle, Download } from 'lucide-react';
import { usePatient, PatientData } from '../context/PatientContext';

export default function PatientProfile() {
  const navigate = useNavigate();
  const { patientData, updatePatientData, setConsent, clearData } = usePatient();
  const [activeTab, setActiveTab] = useState<keyof PatientData>('basicInfo');
  const [showSaved, setShowSaved] = useState(false);

  const handleSave = () => {
    setShowSaved(true);
    setTimeout(() => setShowSaved(false), 3000);
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(patientData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `patient_profile_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const renderInput = (section: keyof PatientData, field: string, label: string, type = 'text', placeholder = '') => {
    const value = (patientData[section] as any)[field] || '';
    return (
      <div className="mb-4">
        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">{label}</label>
        {type === 'textarea' ? (
          <textarea
            value={value}
            onChange={(e) => updatePatientData(section, { [field]: e.target.value })}
            placeholder={placeholder}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
            rows={3}
          />
        ) : (
          <input
            type={type}
            value={value}
            onChange={(e) => updatePatientData(section, { [field]: e.target.value })}
            placeholder={placeholder}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white"
          />
        )}
      </div>
    );
  };

  const tabs = [
    { id: 'basicInfo', label: 'Basic Info', icon: User },
    { id: 'medicalHistory', label: 'Medical History', icon: HeartPulse },
    { id: 'medicationHistory', label: 'Medications', icon: Syringe },
    { id: 'allergies', label: 'Allergies', icon: AlertTriangle },
    { id: 'vitals', label: 'Vitals', icon: Activity },
    { id: 'lifestyle', label: 'Lifestyle', icon: Coffee },
    { id: 'diagnostics', label: 'Diagnostics', icon: FileText },
    { id: 'prescriptions', label: 'Prescriptions', icon: FileBadge },
    { id: 'vaccinations', label: 'Vaccinations', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-24 transition-colors duration-300">
      <header className="bg-white dark:bg-slate-800 p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="text-slate-600 dark:text-slate-400">
            <ArrowLeft size={24} />
          </button>
          <h1 className="font-bold text-slate-900 dark:text-white">Healthcare Profile</h1>
        </div>
        <div className="flex items-center gap-2">
          {patientData.consentGiven && (
            <button onClick={handleExport} className="bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-xl font-bold flex items-center gap-2 text-sm hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
              <Download size={16} /> Export
            </button>
          )}
          <button onClick={handleSave} className="bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 text-sm">
            <Save size={16} /> Save
          </button>
        </div>
      </header>

      <div className="p-6 max-w-4xl mx-auto">
        {/* Privacy Consent Card */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700 mb-6">
          <div className="flex items-start gap-4">
            <div className="bg-emerald-100 dark:bg-emerald-900/30 p-3 rounded-2xl text-emerald-600 dark:text-emerald-400">
              <Shield size={24} />
            </div>
            <div className="flex-1">
              <h2 className="font-bold text-slate-900 dark:text-white text-lg mb-2">Privacy & Local Storage</h2>
              <p className="text-slate-600 dark:text-slate-400 text-sm mb-4 leading-relaxed">
                Your healthcare data is extremely sensitive. By enabling this, your data will be stored <strong>locally on this device only</strong>. It is used to provide personalized medicine suggestions and safety alerts. We do not store this on external servers.
              </p>
              <div className="flex items-center justify-between bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                <span className="font-medium text-slate-800 dark:text-slate-200">Allow local storage of my health data</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={patientData.consentGiven}
                    onChange={(e) => {
                      setConsent(e.target.checked);
                      if (!e.target.checked) clearData();
                    }}
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-slate-600 peer-checked:bg-emerald-500"></div>
                </label>
              </div>
            </div>
          </div>
        </div>

        {showSaved && (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 p-4 rounded-2xl mb-6 font-medium text-center border border-emerald-100 dark:border-emerald-800">
            Profile saved successfully!
          </div>
        )}

        {patientData.consentGiven ? (
          <div className="flex flex-col md:flex-row gap-6">
            {/* Tabs Sidebar */}
            <div className="w-full md:w-64 flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-2 md:pb-0 scrollbar-hide">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as keyof PatientData)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium text-sm whitespace-nowrap transition-colors ${
                    activeTab === tab.id 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  <tab.icon size={18} />
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Content Area */}
            <div className="flex-1 bg-white dark:bg-slate-800 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-700">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                {tabs.find(t => t.id === activeTab)?.label}
              </h2>

              {activeTab === 'basicInfo' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {renderInput('basicInfo', 'fullName', 'Full Name')}
                  {renderInput('basicInfo', 'dob', 'Date of Birth', 'date')}
                  {renderInput('basicInfo', 'gender', 'Gender')}
                  {renderInput('basicInfo', 'bloodGroup', 'Blood Group')}
                  {renderInput('basicInfo', 'email', 'Email', 'email')}
                  <div className="md:col-span-2">{renderInput('basicInfo', 'address', 'Address', 'textarea')}</div>
                  {renderInput('basicInfo', 'emergencyContact', 'Emergency Contact')}
                  {renderInput('basicInfo', 'patientId', 'Patient ID')}
                </div>
              )}

              {activeTab === 'medicalHistory' && (
                <div className="space-y-4">
                  {renderInput('medicalHistory', 'pastIllnesses', 'Past Illnesses', 'textarea', 'e.g., Asthma, Chickenpox')}
                  {renderInput('medicalHistory', 'chronicDiseases', 'Chronic Diseases', 'textarea', 'e.g., Diabetes, Hypertension')}
                  {renderInput('medicalHistory', 'previousHospitalizations', 'Previous Hospitalizations', 'textarea')}
                  {renderInput('medicalHistory', 'surgicalHistory', 'Surgical History', 'textarea')}
                  {renderInput('medicalHistory', 'familyHistory', 'Family Medical History', 'textarea')}
                  {renderInput('medicalHistory', 'geneticDiseases', 'Genetic Diseases', 'textarea')}
                </div>
              )}

              {activeTab === 'medicationHistory' && (
                <div className="space-y-4">
                  {renderInput('medicationHistory', 'currentMedications', 'Current Medications', 'textarea', 'List all current medicines')}
                  {renderInput('medicationHistory', 'pastMedications', 'Past Medications', 'textarea')}
                  {renderInput('medicationHistory', 'dosageAndFrequency', 'Dosage & Frequency', 'textarea')}
                  {renderInput('medicationHistory', 'duration', 'Duration of Treatment')}
                  {renderInput('medicationHistory', 'prescribingDoctor', 'Prescribing Doctor')}
                  {renderInput('medicationHistory', 'pharmacyRecords', 'Pharmacy Records', 'textarea')}
                </div>
              )}

              {activeTab === 'allergies' && (
                <div className="space-y-4">
                  {renderInput('allergies', 'drugAllergies', 'Drug Allergies', 'textarea', 'e.g., Penicillin')}
                  {renderInput('allergies', 'foodAllergies', 'Food Allergies', 'textarea', 'e.g., Peanuts')}
                  {renderInput('allergies', 'environmentalAllergies', 'Environmental Allergies', 'textarea', 'e.g., Pollen, Dust')}
                  {renderInput('allergies', 'reactionDetails', 'Reaction Details', 'textarea', 'e.g., rash, swelling, breathing difficulty')}
                </div>
              )}

              {activeTab === 'vitals' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {renderInput('vitals', 'bloodPressure', 'Blood Pressure', 'text', 'e.g., 120/80')}
                  {renderInput('vitals', 'heartRate', 'Heart Rate', 'text', 'e.g., 72 bpm')}
                  {renderInput('vitals', 'bodyTemperature', 'Body Temperature', 'text', 'e.g., 98.6°F')}
                  {renderInput('vitals', 'bloodSugar', 'Blood Sugar', 'text', 'e.g., 100 mg/dL')}
                  {renderInput('vitals', 'oxygenSaturation', 'Oxygen Saturation', 'text', 'e.g., 98%')}
                  {renderInput('vitals', 'weightBmi', 'Weight / BMI', 'text', 'e.g., 70kg / 22.5')}
                </div>
              )}

              {activeTab === 'lifestyle' && (
                <div className="space-y-4">
                  {renderInput('lifestyle', 'smokingStatus', 'Smoking Status')}
                  {renderInput('lifestyle', 'alcoholConsumption', 'Alcohol Consumption')}
                  {renderInput('lifestyle', 'dietType', 'Diet Type', 'text', 'e.g., Vegetarian, Keto')}
                </div>
              )}

              {activeTab === 'diagnostics' && (
                <div className="space-y-4">
                  <p className="text-sm text-slate-500 mb-4">List your recent diagnostic and lab reports here.</p>
                  {renderInput('diagnostics', 'reports', 'Diagnostic & Lab Reports', 'textarea', 'e.g., Blood tests, X-ray, MRI/CT scan, ECG, Pathology reports')}
                </div>
              )}

              {activeTab === 'prescriptions' && (
                <div className="space-y-4">
                  <p className="text-sm text-slate-500 mb-4">Record your previous doctor prescriptions.</p>
                  {renderInput('prescriptions', 'records', 'Prescription Records', 'textarea', 'Include Date, Doctor Name, Diagnosis, Prescribed Medicines, Instructions')}
                </div>
              )}

              {activeTab === 'vaccinations' && (
                <div className="space-y-4">
                  <p className="text-sm text-slate-500 mb-4">Keep track of your vaccination history.</p>
                  {renderInput('vaccinations', 'records', 'Vaccination Records', 'textarea', 'Include Vaccine name, Date administered, Dose number, Next due date')}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-12 px-4 bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700">
            <Shield size={48} className="mx-auto text-slate-300 dark:text-slate-600 mb-4" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Permission Required</h3>
            <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto">
              Please enable local storage consent above to start building your personal healthcare profile. Your data will remain securely on your device.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
