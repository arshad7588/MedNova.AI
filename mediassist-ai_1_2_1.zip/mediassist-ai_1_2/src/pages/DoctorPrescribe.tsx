import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, User, Plus, Trash2, Save, Search } from 'lucide-react';
import { auth, db } from '../firebase';
import { doc, getDoc, collection, addDoc, query, where, getDocs } from 'firebase/firestore';
import { UserProfile } from '../types';

export default function DoctorPrescribe() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const patientId = searchParams.get('patientId');
  
  const [patient, setPatient] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  const [medicines, setMedicines] = useState([{ name: '', dosage: '', frequency: '', duration: '' }]);
  const [notes, setNotes] = useState('');

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    const fetchPatient = async () => {
      if (!patientId) {
        setLoading(false);
        return;
      }
      try {
        const docRef = doc(db, 'users', patientId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setPatient(docSnap.data() as UserProfile);
        }
      } catch (error) {
        console.error("Error fetching patient:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchPatient();
  }, [patientId]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    setSearching(true);
    try {
      // Simple search by name (in a real app, use Algolia or similar)
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('role', '==', 'patient'));
      const querySnapshot = await getDocs(q);
      
      const results: UserProfile[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data() as UserProfile;
        if (
          data.name.toLowerCase().includes(searchQuery.toLowerCase())
        ) {
          results.push(data);
        }
      });
      setSearchResults(results);
    } catch (error) {
      console.error("Error searching patients:", error);
    } finally {
      setSearching(false);
    }
  };

  const addMedicine = () => {
    setMedicines([...medicines, { name: '', dosage: '', frequency: '', duration: '' }]);
  };

  const removeMedicine = (index: number) => {
    setMedicines(medicines.filter((_, i) => i !== index));
  };

  const updateMedicine = (index: number, field: string, value: string) => {
    const newMedicines = [...medicines];
    newMedicines[index] = { ...newMedicines[index], [field]: value };
    setMedicines(newMedicines);
  };

  const handleSave = async () => {
    if (!auth.currentUser || !patientId) return;
    
    // Validate
    const validMedicines = medicines.filter(m => m.name.trim() !== '');
    if (validMedicines.length === 0) {
      alert("Please add at least one medicine.");
      return;
    }

    setSaving(true);
    try {
      await addDoc(collection(db, 'prescriptions'), {
        doctorId: auth.currentUser.uid,
        patientId: patientId,
        medicines: validMedicines,
        notes,
        date: new Date().toISOString()
      });
      alert("Prescription saved successfully!");
      navigate('/home');
    } catch (error) {
      console.error("Error saving prescription:", error);
      alert("Failed to save prescription.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  if (!patientId || !patient) {
    return (
      <div className="min-h-screen bg-slate-50 pb-24">
        <header className="bg-white px-6 py-4 flex items-center gap-4 sticky top-0 z-10 shadow-sm">
          <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors">
            <ArrowLeft size={24} className="text-slate-700" />
          </button>
          <h1 className="text-xl font-bold text-slate-900">Select Patient</h1>
        </header>
        
        <div className="p-6">
          <form onSubmit={handleSearch} className="relative mb-6 flex">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text" 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search patient by name..."
                className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-24 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <button 
                type="submit"
                disabled={searching || !searchQuery.trim()}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-bold disabled:opacity-50"
              >
                {searching ? 'Searching...' : 'Search'}
              </button>
            </div>
          </form>

          {searchResults.length > 0 ? (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-2">Results</h3>
              {searchResults.map((p) => (
                <button
                  key={p.uid}
                  onClick={() => navigate(`/doctor/prescribe?patientId=${p.uid}`)}
                  className="w-full bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4 text-left hover:border-emerald-500 transition-colors"
                >
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
                    <User size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{p.name}</h4>
                    <p className="text-sm text-slate-500">{p.email}</p>
                  </div>
                </button>
              ))}
            </div>
          ) : searchQuery && !searching ? (
            <div className="text-center py-12">
              <p className="text-slate-500">No patients found matching "{searchQuery}"</p>
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search size={24} className="text-slate-400" />
              </div>
              <p className="text-slate-500">Search for a patient to write a prescription.</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white px-6 py-4 flex items-center gap-4 sticky top-0 z-10 shadow-sm">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-slate-100 rounded-full transition-colors">
          <ArrowLeft size={24} className="text-slate-700" />
        </button>
        <h1 className="text-xl font-bold text-slate-900">Write Prescription</h1>
      </header>

      <div className="p-6 space-y-6">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
            <User size={24} />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Patient</p>
            <h2 className="font-bold text-slate-900">{patient.name}</h2>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold text-slate-800 flex items-center justify-between">
            Medicines
            <button onClick={addMedicine} className="text-emerald-600 text-sm flex items-center gap-1">
              <Plus size={16} /> Add
            </button>
          </h3>
          
          {medicines.map((med, index) => (
            <div key={index} className="bg-white p-4 rounded-2xl border border-slate-200 space-y-3 relative">
              {medicines.length > 1 && (
                <button 
                  onClick={() => removeMedicine(index)}
                  className="absolute top-4 right-4 text-red-400 hover:text-red-600"
                >
                  <Trash2 size={18} />
                </button>
              )}
              
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Medicine Name</label>
                <input 
                  type="text" 
                  value={med.name}
                  onChange={(e) => updateMedicine(index, 'name', e.target.value)}
                  placeholder="e.g. Paracetamol 500mg"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Dosage</label>
                  <input 
                    type="text" 
                    value={med.dosage}
                    onChange={(e) => updateMedicine(index, 'dosage', e.target.value)}
                    placeholder="e.g. 1 tablet"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Frequency</label>
                  <input 
                    type="text" 
                    value={med.frequency}
                    onChange={(e) => updateMedicine(index, 'frequency', e.target.value)}
                    placeholder="e.g. Twice a day"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Duration</label>
                <input 
                  type="text" 
                  value={med.duration}
                  onChange={(e) => updateMedicine(index, 'duration', e.target.value)}
                  placeholder="e.g. 5 days"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>
          ))}
        </div>

        <div>
          <label className="block text-sm font-bold text-slate-800 mb-2">Additional Notes</label>
          <textarea 
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Any specific instructions for the patient..."
            className="w-full bg-white border border-slate-200 rounded-2xl p-4 min-h-[100px] focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <button 
          onClick={handleSave}
          disabled={saving}
          className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {saving ? 'Saving...' : <><Save size={20} /> Save Prescription</>}
        </button>
      </div>
    </div>
  );
}
