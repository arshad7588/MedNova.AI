import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Activity, Brain, ShieldCheck } from 'lucide-react';

export default function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="mb-8"
      >
        <div className="w-24 h-24 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-xl shadow-emerald-200 mx-auto mb-6">
          <div className="relative">
            <Activity className="text-white w-12 h-12" />
            <Brain className="text-emerald-300 w-6 h-6 absolute -top-2 -right-2" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 mb-2">MediAssist AI</h1>
        <p className="text-slate-500 max-w-xs mx-auto">Your Smart Medical Companion for a healthier life.</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl px-4">
        <motion.button
          whileHover={{ y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/login?role=patient')}
          className="bg-white p-8 rounded-3xl border-2 border-emerald-50 shadow-xl shadow-emerald-50/50 text-left group hover:border-emerald-200 transition-all"
        >
          <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <Activity className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Patient</h2>
          <p className="text-sm text-slate-500 leading-relaxed">
            Scan prescriptions, check symptoms, and get personalized health assistance.
          </p>
        </motion.button>

        <motion.button
          whileHover={{ y: -5 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/login?role=pharmacist')}
          className="bg-white p-8 rounded-3xl border-2 border-blue-50 shadow-xl shadow-blue-50/50 text-left group hover:border-blue-200 transition-all"
        >
          <div className="w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 mb-2">Pharmacist</h2>
          <p className="text-sm text-slate-500 leading-relaxed">
            Manage inventory, track sales, and optimize your pharmacy operations.
          </p>
        </motion.button>
      </div>

      <div className="mt-12 flex flex-col items-center gap-4">
        <button
          onClick={() => navigate('/signup')}
          className="text-emerald-600 font-bold hover:underline"
        >
          New here? Create an account
        </button>
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <ShieldCheck size={16} />
          <span>Secure & HIPAA Compliant</span>
        </div>
      </div>
    </div>
  );
}
