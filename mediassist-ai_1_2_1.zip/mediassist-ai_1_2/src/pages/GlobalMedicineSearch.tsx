import React, { useState } from 'react';
import { Search, Pill, ExternalLink, Globe, Info, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from "@google/genai";

interface GlobalMedicine {
  name: string;
  manufacturer: string;
  origin: string;
  description: string;
  type: 'Branded' | 'Standard' | 'Generic';
  alternatives: string[];
}

export default function GlobalMedicineSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GlobalMedicine[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Search for information about the medicine "${query}" in the Indian market. 
        Provide a list of 2-3 variants or related products available in India.
        For each product, include:
        1. Name
        2. Likely major manufacturer (Indian or global company active in India)
        3. Primary region of origin/market (e.g., India)
        4. Brief description of its availability and use in India
        5. Type: Categorize it as 'Branded', 'Standard', or 'Generic'
        6. Alternatives: List 2-3 common substitution or alternative medicines available in India (generic or other brands).`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                manufacturer: { type: Type.STRING },
                origin: { type: Type.STRING },
                description: { type: Type.STRING },
                type: { type: Type.STRING, enum: ['Branded', 'Standard', 'Generic'] },
                alternatives: { 
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
              },
              required: ["name", "manufacturer", "origin", "description", "type", "alternatives"]
            }
          }
        }
      });

      const text = response.text;
      if (text) {
        const parsedResults = JSON.parse(text) as GlobalMedicine[];
        setResults(parsedResults);
      } else {
        setResults([]);
      }
    } catch (err) {
      console.error("Error searching medicine in India:", err);
      setError("Failed to fetch medicine data for India. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const getGoogleSearchUrl = (name: string) => {
    return `https://www.google.com/search?q=${encodeURIComponent(name + ' medicine India market availability')}`;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Branded': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300';
      case 'Standard': return 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300';
      case 'Generic': return 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300';
      default: return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-6 pb-24 transition-colors duration-300">
      <header className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl">
            <Globe size={28} />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">India Market Search</h1>
        </div>
        <p className="text-slate-500 dark:text-slate-400">Find medicines available in the Indian market and explore details on Google.</p>
      </header>

      <form onSubmit={handleSearch} className="relative mb-8">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter medicine name (e.g. Paracetamol, Telma)..."
          className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl py-4 pl-12 pr-4 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 dark:text-white transition-all"
        />
        <button 
          type="submit"
          disabled={loading}
          className="absolute right-2 top-1/2 -translate-y-1/2 bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors disabled:opacity-50"
        >
          {loading ? 'Searching...' : 'Search'}
        </button>
      </form>

      {error && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400">
          <AlertCircle size={20} />
          <p className="text-sm">{error}</p>
        </div>
      )}

      <div className="space-y-4">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-600 mb-4"></div>
            <p className="text-slate-500 dark:text-slate-400">Searching Indian databases...</p>
          </div>
        ) : results.length > 0 ? (
          <AnimatePresence>
            {results.map((med, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white dark:bg-slate-800 p-5 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl">
                      <Pill size={20} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-slate-900 dark:text-white">{med.name}</h3>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${getTypeColor(med.type)}`}>
                          {med.type}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">{med.manufacturer} • {med.origin}</p>
                    </div>
                  </div>
                  <a 
                    href={getGoogleSearchUrl(med.name)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-xl transition-colors"
                    title="View on Google"
                  >
                    <ExternalLink size={20} />
                  </a>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                  {med.description}
                </p>
                
                {med.alternatives && med.alternatives.length > 0 && (
                  <div className="mb-4">
                    <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">Alternatives / Substitutions</h4>
                    <div className="flex flex-wrap gap-2">
                      {med.alternatives.map((alt, i) => (
                        <button 
                          key={i}
                          onClick={() => {
                            setQuery(alt);
                            // Trigger search manually or just update query
                          }}
                          className="text-xs bg-slate-50 dark:bg-slate-700/50 text-slate-600 dark:text-slate-300 px-3 py-1.5 rounded-lg border border-slate-100 dark:border-slate-700 hover:border-emerald-500 transition-colors"
                        >
                          {alt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-2 text-xs font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-2 rounded-lg w-fit">
                  <Info size={14} />
                  India Availability Confirmed
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        ) : query && !loading ? (
          <div className="text-center py-12">
            <div className="bg-slate-100 dark:bg-slate-800 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
              <Search size={32} />
            </div>
            <p className="text-slate-500 dark:text-slate-400">No specific matches found for "{query}" in India. Try another name or check Google directly.</p>
            <a 
              href={getGoogleSearchUrl(query)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 text-emerald-600 font-semibold"
            >
              Search "{query}" on Google <ExternalLink size={16} />
            </a>
          </div>
        ) : (
          <div className="bg-emerald-50 dark:bg-emerald-900/10 p-6 rounded-3xl border border-emerald-100 dark:border-emerald-900/20">
            <div className="flex gap-4">
              <div className="text-emerald-600 dark:text-emerald-400 shrink-0">
                <Info size={24} />
              </div>
              <div>
                <h4 className="font-bold text-emerald-900 dark:text-emerald-100 mb-1">India Market Insights</h4>
                <p className="text-sm text-emerald-700 dark:text-emerald-300 leading-relaxed">
                  Search for any medicine to see its Indian variants, manufacturers, and direct links to comprehensive Google search results for local pricing and availability.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
