import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, AlertTriangle, Plus, X, Search, CheckCircle2, ShieldAlert } from 'lucide-react';
import { streamMedicineSafety } from '../services/gemini';
import { usePatient } from '../context/PatientContext';
import { useSettings } from '../context/SettingsContext';
import { logActivity } from '../utils/activityLogger';
import ReadMore from '../components/ReadMore';

export default function DrugInteraction() {
  const navigate = useNavigate();
  const { patientData } = usePatient();
  const { language } = useSettings();
  const [drugs, setDrugs] = useState<string[]>([]);
  const [currentDrug, setCurrentDrug] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const addDrug = () => {
    if (currentDrug.trim() && !drugs.includes(currentDrug.trim())) {
      setDrugs([...drugs, currentDrug.trim()]);
      setCurrentDrug('');
    }
  };

  const removeDrug = (index: number) => {
    setDrugs(drugs.filter((_, i) => i !== index));
  };

  const handleCheck = async () => {
    if (drugs.length < 1) return;
    
    setLoading(true);
    setResult('');
    try {
      const query = drugs.join(', ');
      const stream = streamMedicineSafety(query, patientData, language);
      let fullResponse = '';
      let hasReceivedData = false;
      let displayedLines: string[] = [];
      let currentBuffer = '';

      for await (const chunk of stream) {
        if (chunk) {
          hasReceivedData = true;
          fullResponse += chunk;
          currentBuffer += chunk;

          if (currentBuffer.includes('\n')) {
            const lines = currentBuffer.split('\n');
            const completeLines = lines.slice(0, -1);
            displayedLines = [...displayedLines, ...completeLines];
            currentBuffer = lines[lines.length - 1];
            
            const textToShow = displayedLines.join('\n') + (currentBuffer ? '\n' + currentBuffer : '');
            setResult(textToShow);
            
            // Professional line-by-line delay
            await new Promise(resolve => setTimeout(resolve, 150));
          } else {
            const textToShow = displayedLines.join('\n') + (displayedLines.length > 0 ? '\n' : '') + currentBuffer;
            setResult(textToShow);
          }
        }
      }
      
      // Final update
      setResult(fullResponse);

      if (!hasReceivedData) {
        setResult("I couldn't generate a safety analysis. Please try again. 💊");
      } else {
        // Log activity after stream finishes
        logActivity('Medicine Safety', `Checked safety for: ${query}`, fullResponse);
      }
    } catch (error: any) {
      console.error("Medicine Safety Error:", error);
      let errorMessage = "An error occurred while analyzing the medicines. Please try again. 💊";
      
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 'PERMISSION_DENIED' || error?.status === 403) {
        errorMessage = "I don't have permission to access the AI service. This usually means the API key is invalid or lacks permissions. Please check your settings.";
      } else if (error?.message?.includes('quota') || error?.message?.includes('limit')) {
        errorMessage = "The AI service is currently at its limit. Please try again in a few minutes. 💊";
      }

      setResult(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 pb-24 transition-colors duration-300">
      <header className="bg-white dark:bg-slate-800 p-4 border-b border-slate-200 dark:border-slate-700 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600 dark:text-slate-400">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900 dark:text-white">Medicine Safety & Interactions</h1>
      </header>

      <div className="p-6 space-y-6">
        {patientData.consentGiven && (
          <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800 p-4 rounded-2xl flex items-start gap-3">
            <ShieldAlert className="text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" size={20} />
            <div>
              <h3 className="text-emerald-800 dark:text-emerald-300 font-bold text-sm">Personalized Safety Active</h3>
              <p className="text-emerald-600 dark:text-emerald-400 text-xs mt-1">
                Your saved medical history, allergies, and current medications will be cross-referenced to ensure these medicines are safe for you.
              </p>
            </div>
          </div>
        )}

        {!result ? (
          <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm space-y-6">
            <div className="flex items-center gap-3 text-red-600 dark:text-red-400 mb-2">
              <AlertTriangle size={24} />
              <h2 className="font-bold text-lg">Check Safety</h2>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-sm">Add one or more medicines to check for potential interactions, side effects, and personalized risks.</p>

            <div className="space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter medicine name..."
                  className="flex-1 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-700 rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-red-500 dark:text-white"
                  value={currentDrug}
                  onChange={(e) => setCurrentDrug(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addDrug()}
                />
                <button
                  onClick={addDrug}
                  className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 p-4 rounded-2xl hover:bg-red-100 dark:hover:bg-red-900/40 transition-all"
                >
                  <Plus size={24} />
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {drugs.map((drug, idx) => (
                  <div key={idx} className="bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-xl flex items-center gap-2 font-medium">
                    {drug}
                    <button onClick={() => removeDrug(idx)} className="text-slate-400 hover:text-red-500 dark:hover:text-red-400">
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={handleCheck}
              disabled={loading || drugs.length < 1}
              className="w-full bg-red-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-red-100 dark:shadow-none flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? 'Analyzing...' : <><Search size={20} /> Check Safety</>}
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400 mb-4">
                <CheckCircle2 size={24} />
                <h2 className="font-bold text-lg m-0">Safety Analysis</h2>
              </div>
              <ReadMore text={result} maxLength={500} />
            </div>
            <button
              onClick={() => setResult(null)}
              className="w-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold py-4 rounded-2xl"
            >
              Check New Medicine
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
