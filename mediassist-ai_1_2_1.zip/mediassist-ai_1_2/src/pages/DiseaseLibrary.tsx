import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, BookOpen, Search, ChevronRight } from 'lucide-react';

export default function DiseaseLibrary() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState<any | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const diseases = [
    { 
      id: 'diabetes', 
      name: 'Diabetes', 
      causes: 'Genetics, obesity, inactive lifestyle.', 
      symptoms: 'Increased thirst, frequent urination, fatigue, blurred vision.',
      prevention: 'Healthy diet, regular exercise, weight management.',
      treatment: 'Insulin, medication, blood sugar monitoring.'
    },
    { 
      id: 'hypertension', 
      name: 'Hypertension', 
      causes: 'High salt intake, stress, genetics, smoking.', 
      symptoms: 'Often silent, but can cause headaches, nosebleeds, or shortness of breath.',
      prevention: 'Low salt diet, exercise, stress management.',
      treatment: 'Lifestyle changes, blood pressure medication.'
    },
    { 
      id: 'asthma', 
      name: 'Asthma', 
      causes: 'Allergens, air pollution, respiratory infections.', 
      symptoms: 'Wheezing, shortness of breath, chest tightness, coughing.',
      prevention: 'Avoiding triggers, regular check-ups.',
      treatment: 'Inhalers, avoiding allergens.'
    },
    {
      id: 'influenza',
      name: 'Influenza (Flu)',
      causes: 'Influenza viruses (Type A, B, C).',
      symptoms: 'Fever, chills, muscle aches, cough, congestion, runny nose, headaches, and fatigue.',
      prevention: 'Annual flu vaccine, frequent handwashing, avoiding close contact with sick people.',
      treatment: 'Rest, fluids, and antiviral medications if prescribed by a doctor.'
    },
    {
      id: 'common-cold',
      name: 'Common Cold',
      causes: 'Rhinoviruses and other respiratory viruses.',
      symptoms: 'Runny or stuffy nose, sore throat, cough, congestion, slight body aches, mild headache, sneezing, low-grade fever.',
      prevention: 'Handwashing, avoiding touching face, disinfecting surfaces.',
      treatment: 'Rest, fluids, over-the-counter cold remedies to manage symptoms.'
    },
    {
      id: 'pneumonia',
      name: 'Pneumonia',
      causes: 'Bacteria, viruses, or fungi infecting the lungs.',
      symptoms: 'Chest pain when breathing or coughing, confusion (in older adults), cough with phlegm, fatigue, fever, sweating, shaking chills.',
      prevention: 'Vaccination (Pneumococcal), hand hygiene, not smoking.',
      treatment: 'Antibiotics (for bacterial), antivirals (for viral), rest, fluids.'
    },
    {
      id: 'bronchitis',
      name: 'Bronchitis',
      causes: 'Viruses (usually the same as cold/flu), smoking, air pollution.',
      symptoms: 'Cough with mucus, fatigue, shortness of breath, slight fever and chills, chest discomfort.',
      prevention: 'Avoiding cigarette smoke, washing hands, wearing a mask in polluted areas.',
      treatment: 'Rest, fluids, humidifiers, cough suppressants.'
    },
    {
      id: 'tuberculosis',
      name: 'Tuberculosis (TB)',
      causes: 'Mycobacterium tuberculosis bacteria.',
      symptoms: 'Coughing for 3+ weeks, coughing up blood, chest pain, unintentional weight loss, fatigue, fever, night sweats.',
      prevention: 'BCG vaccine (in some countries), avoiding close contact with active TB patients, good ventilation.',
      treatment: 'Long-term course of multiple antibiotics (6-9 months).'
    },
    {
      id: 'malaria',
      name: 'Malaria',
      causes: 'Plasmodium parasites transmitted by infected Anopheles mosquitoes.',
      symptoms: 'Fever, chills, headache, nausea, vomiting, muscle pain, fatigue.',
      prevention: 'Mosquito nets, insect repellent, antimalarial medication when traveling to endemic areas.',
      treatment: 'Antimalarial drugs (e.g., Artemisinin-based combination therapy).'
    },
    {
      id: 'dengue',
      name: 'Dengue Fever',
      causes: 'Dengue virus transmitted by Aedes mosquitoes.',
      symptoms: 'High fever, severe headache, pain behind eyes, joint and muscle pain, rash, mild bleeding (nose/gums).',
      prevention: 'Eliminating standing water, using mosquito repellent, wearing long-sleeved clothes.',
      treatment: 'Supportive care, fluids, pain relievers (avoiding aspirin/ibuprofen).'
    },
    {
      id: 'typhoid',
      name: 'Typhoid Fever',
      causes: 'Salmonella Typhi bacteria, usually through contaminated food or water.',
      symptoms: 'Sustained high fever, weakness, stomach pain, headache, diarrhea or constipation, cough, loss of appetite.',
      prevention: 'Vaccination, safe drinking water, proper food hygiene, handwashing.',
      treatment: 'Antibiotics, fluids.'
    },
    {
      id: 'cholera',
      name: 'Cholera',
      causes: 'Vibrio cholerae bacteria in contaminated water or food.',
      symptoms: 'Severe watery diarrhea (rice-water stools), vomiting, leg cramps, rapid dehydration.',
      prevention: 'Safe water (boiled/treated), proper sanitation, handwashing, vaccine.',
      treatment: 'Oral rehydration salts (ORS), intravenous fluids, antibiotics in severe cases.'
    },
    {
      id: 'hepatitis-a',
      name: 'Hepatitis A',
      causes: 'Hepatitis A virus (HAV) through contaminated food/water or close contact.',
      symptoms: 'Fatigue, sudden nausea/vomiting, abdominal pain, clay-colored stools, loss of appetite, low-grade fever, dark urine, jaundice.',
      prevention: 'Hepatitis A vaccine, good hand hygiene, avoiding contaminated food/water.',
      treatment: 'Rest, nutrition, fluids; usually resolves on its own.'
    },
    {
      id: 'hepatitis-b',
      name: 'Hepatitis B',
      causes: 'Hepatitis B virus (HBV) through blood, semen, or other body fluids.',
      symptoms: 'Abdominal pain, dark urine, fever, joint pain, loss of appetite, nausea/vomiting, weakness, jaundice.',
      prevention: 'Hepatitis B vaccine, safe sex, avoiding sharing needles.',
      treatment: 'Antiviral medications for chronic cases, liver transplant in severe cases.'
    },
    {
      id: 'hepatitis-c',
      name: 'Hepatitis C',
      causes: 'Hepatitis C virus (HCV) primarily through blood-to-blood contact.',
      symptoms: 'Often asymptomatic for years; fatigue, jaundice, nausea, loss of appetite when chronic.',
      prevention: 'Avoiding sharing needles, safe tattoo/piercing practices, screening blood donations.',
      treatment: 'Direct-acting antiviral (DAA) medications.'
    },
    {
      id: 'hiv-aids',
      name: 'HIV/AIDS',
      causes: 'Human Immunodeficiency Virus (HIV) through blood, semen, vaginal fluids, or breast milk.',
      symptoms: 'Fever, headache, muscle aches, rash, sore throat, swollen lymph glands (early); weight loss, recurring fever, extreme tiredness (AIDS).',
      prevention: 'Safe sex (condoms), PrEP, not sharing needles, screening blood products.',
      treatment: 'Antiretroviral therapy (ART) to manage the virus.'
    },
    {
      id: 'syphilis',
      name: 'Syphilis',
      causes: 'Treponema pallidum bacteria through sexual contact.',
      symptoms: 'Painless sores (chancre), skin rash, swollen lymph nodes, fever, fatigue (stages vary).',
      prevention: 'Safe sex, regular STI testing.',
      treatment: 'Penicillin or other antibiotics.'
    },
    {
      id: 'gonorrhea',
      name: 'Gonorrhea',
      causes: 'Neisseria gonorrhoeae bacteria through sexual contact.',
      symptoms: 'Painful urination, abnormal discharge from penis/vagina, pelvic pain in women.',
      prevention: 'Safe sex, regular STI testing.',
      treatment: 'Antibiotics (often dual therapy due to resistance).'
    },
    {
      id: 'chlamydia',
      name: 'Chlamydia',
      causes: 'Chlamydia trachomatis bacteria through sexual contact.',
      symptoms: 'Often asymptomatic; painful urination, discharge, pelvic pain.',
      prevention: 'Safe sex, regular STI testing.',
      treatment: 'Antibiotics (e.g., Azithromycin or Doxycycline).'
    },
    {
      id: 'herpes',
      name: 'Herpes Simplex',
      causes: 'Herpes Simplex Virus (HSV-1 or HSV-2).',
      symptoms: 'Blisters or sores around mouth (cold sores) or genitals, itching, burning, flu-like symptoms.',
      prevention: 'Avoiding contact during outbreaks, safe sex (reduces but doesn\'t eliminate risk).',
      treatment: 'Antiviral medications (e.g., Acyclovir) to manage outbreaks.'
    },
    {
      id: 'chickenpox',
      name: 'Chickenpox',
      causes: 'Varicella-zoster virus.',
      symptoms: 'Itchy, fluid-filled blisters (rash), fever, tiredness, loss of appetite, headache.',
      prevention: 'Varicella vaccine.',
      treatment: 'Supportive care (calamine lotion, cool baths), antivirals for high-risk individuals.'
    },
    {
      id: 'measles',
      name: 'Measles',
      causes: 'Measles virus (highly contagious respiratory virus).',
      symptoms: 'High fever, cough, runny nose, red/watery eyes, tiny white spots inside mouth, rash that spreads from face down.',
      prevention: 'MMR vaccine.',
      treatment: 'Supportive care, Vitamin A supplements, monitoring for complications.'
    },
    {
      id: 'mumps',
      name: 'Mumps',
      causes: 'Mumps virus.',
      symptoms: 'Swollen, painful salivary glands (puffy cheeks), fever, headache, muscle aches, fatigue, loss of appetite.',
      prevention: 'MMR vaccine.',
      treatment: 'Supportive care (rest, fluids, pain relievers).'
    },
    {
      id: 'rubella',
      name: 'Rubella (German Measles)',
      causes: 'Rubella virus.',
      symptoms: 'Fine pink rash, low-grade fever, headache, mild pink eye, swollen lymph nodes.',
      prevention: 'MMR vaccine.',
      treatment: 'Supportive care.'
    },
    {
      id: 'pertussis',
      name: 'Whooping Cough (Pertussis)',
      causes: 'Bordetella pertussis bacteria.',
      symptoms: 'Severe coughing fits followed by a high-pitched "whoop" sound, vomiting after coughing, exhaustion.',
      prevention: 'DTaP/Tdap vaccine.',
      treatment: 'Antibiotics, supportive care.'
    },
    {
      id: 'tetanus',
      name: 'Tetanus',
      causes: 'Clostridium tetani bacteria entering through wounds.',
      symptoms: 'Jaw cramping (lockjaw), muscle spasms (often in stomach), painful muscle stiffness all over, trouble swallowing, fever.',
      prevention: 'Tetanus vaccine and boosters, proper wound care.',
      treatment: 'Hospitalization, tetanus immune globulin, wound cleaning, medications to control spasms.'
    },
    {
      id: 'diphtheria',
      name: 'Diphtheria',
      causes: 'Corynebacterium diphtheriae bacteria.',
      symptoms: 'Thick gray coating in nose and throat, sore throat, hoarseness, swollen glands, difficulty breathing.',
      prevention: 'DTaP/Tdap vaccine.',
      treatment: 'Antitoxin, antibiotics.'
    },
    {
      id: 'polio',
      name: 'Polio',
      causes: 'Poliovirus.',
      symptoms: 'Fever, sore throat, headache, vomiting, fatigue, back/neck pain (non-paralytic); loss of reflexes, severe muscle aches, loose/floppy limbs (paralytic).',
      prevention: 'Polio vaccine (IPV or OPV).',
      treatment: 'Supportive care, physical therapy.'
    },
    {
      id: 'meningitis',
      name: 'Meningitis',
      causes: 'Bacteria, viruses, or fungi infecting the membranes around brain/spinal cord.',
      symptoms: 'Sudden high fever, stiff neck, severe headache, nausea/vomiting, confusion, seizures, sleepiness, sensitivity to light.',
      prevention: 'Vaccination (Meningococcal, Hib), hand hygiene.',
      treatment: 'Antibiotics (bacterial), supportive care (viral), antifungals (fungal).'
    },
    {
      id: 'encephalitis',
      name: 'Encephalitis',
      causes: 'Viral infections (e.g., Herpes, West Nile), autoimmune reactions.',
      symptoms: 'Fever, headache, confusion, seizures, problems with movement/senses, flu-like symptoms.',
      prevention: 'Vaccination (where available), mosquito/tick protection.',
      treatment: 'Antivirals, steroids, supportive care.'
    },
    {
      id: 'lyme',
      name: 'Lyme Disease',
      causes: 'Borrelia burgdorferi bacteria transmitted by black-legged ticks.',
      symptoms: 'Bull\'s-eye rash (erythema migrans), fever, chills, headache, fatigue, muscle/joint aches, swollen lymph nodes.',
      prevention: 'Tick repellent, wearing long clothes in wooded areas, tick checks.',
      treatment: 'Antibiotics (e.g., Doxycycline).'
    },
    {
      id: 'zika',
      name: 'Zika Virus',
      causes: 'Zika virus transmitted by Aedes mosquitoes.',
      symptoms: 'Fever, rash, joint pain, conjunctivitis (red eyes), muscle pain, headache (often mild).',
      prevention: 'Mosquito protection, safe sex (can be sexually transmitted).',
      treatment: 'Rest, fluids, pain relievers.'
    },
    {
      id: 'ebola',
      name: 'Ebola Virus Disease',
      causes: 'Ebolavirus through direct contact with infected blood/body fluids.',
      symptoms: 'Fever, severe headache, muscle pain, weakness, fatigue, diarrhea, vomiting, abdominal pain, unexplained hemorrhage (bleeding/bruising).',
      prevention: 'Avoiding contact with infected people/animals, strict infection control, vaccine (in specific areas).',
      treatment: 'Supportive care (fluids/electrolytes), monoclonal antibody treatments.'
    },
    {
      id: 'covid-19',
      name: 'COVID-19',
      causes: 'SARS-CoV-2 virus.',
      symptoms: 'Fever, cough, tiredness, loss of taste/smell, sore throat, headache, aches/pains, diarrhea, rash, red eyes.',
      prevention: 'Vaccination, masks, social distancing, hand hygiene, ventilation.',
      treatment: 'Antivirals (e.g., Paxlovid), supportive care, oxygen/ventilation in severe cases.'
    },
    {
      id: 'osteoarthritis',
      name: 'Osteoarthritis',
      causes: 'Wear and tear of joint cartilage over time.',
      symptoms: 'Joint pain, stiffness (especially in morning), tenderness, loss of flexibility, grating sensation, bone spurs.',
      prevention: 'Maintaining healthy weight, staying active, avoiding joint injuries.',
      treatment: 'Pain relievers, physical therapy, weight loss, surgery (joint replacement).'
    },
    {
      id: 'rheumatoid-arthritis',
      name: 'Rheumatoid Arthritis',
      causes: 'Autoimmune disorder where the body attacks its own joint tissues.',
      symptoms: 'Tender/warm/swollen joints, joint stiffness (worse in morning/after inactivity), fatigue, fever, loss of appetite.',
      prevention: 'Not smoking, maintaining healthy weight.',
      treatment: 'DMARDs, biologics, steroids, physical therapy.'
    },
    {
      id: 'gout',
      name: 'Gout',
      causes: 'Accumulation of urate crystals in joints due to high uric acid levels.',
      symptoms: 'Intense joint pain (often in big toe), lingering discomfort, inflammation, redness, limited range of motion.',
      prevention: 'Limiting alcohol and purine-rich foods (red meat/seafood), staying hydrated.',
      treatment: 'NSAIDs, Colchicine, corticosteroids, medications to lower uric acid.'
    },
    {
      id: 'osteoporosis',
      name: 'Osteoporosis',
      causes: 'Bone loss exceeding bone formation, often due to aging/hormonal changes.',
      symptoms: 'Back pain (caused by fractured/collapsed vertebra), loss of height over time, stooped posture, bones that break easily.',
      prevention: 'Calcium and Vitamin D intake, weight-bearing exercise, not smoking.',
      treatment: 'Bisphosphonates, hormone therapy, bone-building medications.'
    },
    {
      id: 'alzheimers',
      name: 'Alzheimer\'s Disease',
      causes: 'Complex brain changes involving plaques and tangles, genetics, aging.',
      symptoms: 'Memory loss that disrupts daily life, challenges in planning/solving problems, confusion with time/place, personality changes.',
      prevention: 'Mental stimulation, physical exercise, healthy diet, social engagement.',
      treatment: 'Medications to manage symptoms (e.g., Donepezil), supportive care.'
    },
    {
      id: 'parkinsons',
      name: 'Parkinson\'s Disease',
      causes: 'Loss of dopamine-producing neurons in the brain.',
      symptoms: 'Tremor (shaking), slowed movement (bradykinesia), rigid muscles, impaired posture/balance, speech/writing changes.',
      prevention: 'Regular exercise, healthy diet (some research suggests caffeine/green tea might help).',
      treatment: 'Levodopa, dopamine agonists, deep brain stimulation (DBS).'
    },
    {
      id: 'multiple-sclerosis',
      name: 'Multiple Sclerosis (MS)',
      causes: 'Autoimmune attack on the protective sheath (myelin) covering nerve fibers.',
      symptoms: 'Numbness/weakness in limbs, electric-shock sensations with neck movements, tremor, lack of coordination, vision problems, fatigue, slurred speech.',
      prevention: 'Unknown, but Vitamin D and not smoking are associated with lower risk.',
      treatment: 'Disease-modifying therapies (DMTs), steroids for relapses, physical therapy.'
    },
    {
      id: 'epilepsy',
      name: 'Epilepsy',
      causes: 'Brain injury, genetics, stroke, brain tumors, infections.',
      symptoms: 'Recurrent seizures, temporary confusion, staring spells, uncontrollable jerking movements, loss of consciousness.',
      prevention: 'Preventing head injuries, managing health conditions like stroke.',
      treatment: 'Anti-epileptic drugs (AEDs), ketogenic diet, vagus nerve stimulation, surgery.'
    },
    {
      id: 'migraine',
      name: 'Migraine',
      causes: 'Genetics, environmental triggers (stress, food, light).',
      symptoms: 'Severe throbbing pain (usually on one side), nausea, vomiting, sensitivity to light/sound, aura (visual disturbances).',
      prevention: 'Identifying/avoiding triggers, regular sleep/meals, preventive medications.',
      treatment: 'Pain relievers (Triptans, NSAIDs), anti-nausea drugs, rest in a dark room.'
    },
    {
      id: 'depression',
      name: 'Depression',
      causes: 'Biological chemistry, hormones, genetics, life events/trauma.',
      symptoms: 'Persistent sadness, loss of interest in activities, changes in appetite/weight, sleep disturbances, fatigue, feelings of worthlessness, difficulty concentrating.',
      prevention: 'Stress management, social support, regular exercise.',
      treatment: 'Psychotherapy (CBT), antidepressants, lifestyle changes.'
    },
    {
      id: 'anxiety',
      name: 'Anxiety Disorder',
      causes: 'Genetics, brain chemistry, environmental stress, trauma.',
      symptoms: 'Excessive worry, restlessness, fatigue, difficulty concentrating, irritability, muscle tension, sleep problems, panic attacks.',
      prevention: 'Stress reduction, avoiding caffeine/nicotine, social support.',
      treatment: 'Psychotherapy, anti-anxiety medications, antidepressants, relaxation techniques.'
    },
    {
      id: 'bipolar',
      name: 'Bipolar Disorder',
      causes: 'Genetics, brain structure/chemistry, environmental factors.',
      symptoms: 'Manic episodes (high energy, euphoria, racing thoughts) alternating with depressive episodes (low energy, sadness).',
      prevention: 'Early intervention, stress management.',
      treatment: 'Mood stabilizers (e.g., Lithium), antipsychotics, psychotherapy.'
    },
    {
      id: 'schizophrenia',
      name: 'Schizophrenia',
      causes: 'Genetics, brain chemistry, environmental factors during development.',
      symptoms: 'Hallucinations, delusions, disorganized thinking/speech, extremely disorganized motor behavior, "negative" symptoms (reduced functioning).',
      prevention: 'Unknown; early treatment can improve long-term outlook.',
      treatment: 'Antipsychotic medications, psychosocial therapy.'
    },
    {
      id: 'anemia',
      name: 'Anemia',
      causes: 'Iron deficiency, Vitamin B12 deficiency, chronic disease, blood loss.',
      symptoms: 'Fatigue, weakness, pale or yellowish skin, irregular heartbeats, shortness of breath, dizziness, cold hands/feet, chest pain.',
      prevention: 'Iron-rich diet (meat, beans, leafy greens), Vitamin C to aid absorption.',
      treatment: 'Iron/vitamin supplements, treating underlying cause.'
    },
    {
      id: 'leukemia',
      name: 'Leukemia',
      causes: 'Genetics, environmental factors (radiation, chemicals) affecting blood cells.',
      symptoms: 'Fever/chills, persistent fatigue, frequent infections, losing weight without trying, swollen lymph nodes, easy bleeding/bruising, nosebleeds.',
      prevention: 'Avoiding high-dose radiation and certain chemicals (benzene).',
      treatment: 'Chemotherapy, targeted therapy, radiation therapy, stem cell transplant.'
    },
    {
      id: 'lymphoma',
      name: 'Lymphoma',
      causes: 'Mutations in lymphocytes (immune cells).',
      symptoms: 'Painless swelling of lymph nodes (neck/armpit/groin), persistent fatigue, fever, night sweats, shortness of breath, unexplained weight loss, itchy skin.',
      prevention: 'Unknown; maintaining a healthy immune system.',
      treatment: 'Chemotherapy, immunotherapy, radiation therapy, stem cell transplant.'
    },
    {
      id: 'melanoma',
      name: 'Skin Cancer (Melanoma)',
      causes: 'UV radiation from sun or tanning beds damaging skin cell DNA.',
      symptoms: 'Change in an existing mole, development of a new pigmented or unusual-looking growth on skin.',
      prevention: 'Sunscreen, protective clothing, avoiding tanning beds, regular skin checks.',
      treatment: 'Surgery, immunotherapy, targeted therapy, chemotherapy.'
    },
    {
      id: 'breast-cancer',
      name: 'Breast Cancer',
      causes: 'Genetics (BRCA1/2), aging, hormonal factors, lifestyle.',
      symptoms: 'Lump in breast/underarm, change in breast size/shape, dimpling of skin, nipple discharge, redness/flaky skin in nipple area.',
      prevention: 'Regular screenings (mammograms), healthy weight, limiting alcohol.',
      treatment: 'Surgery, radiation, chemotherapy, hormone therapy, targeted therapy.'
    },
    {
      id: 'lung-cancer',
      name: 'Lung Cancer',
      causes: 'Smoking (primary), secondhand smoke, radon gas, asbestos.',
      symptoms: 'New cough that doesn\'t go away, coughing up blood, shortness of breath, chest pain, hoarseness, losing weight without trying, bone pain, headache.',
      prevention: 'Not smoking, avoiding secondhand smoke, testing home for radon.',
      treatment: 'Surgery, chemotherapy, radiation therapy, targeted therapy, immunotherapy.'
    },
  ];

  const filteredDiseases = diseases.filter(d => 
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.symptoms.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900">Disease Library</h1>
      </header>

      <div className="p-6">
        {!selected ? (
          <div className="space-y-4">
            <div className="relative mb-6">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input 
                type="text" 
                placeholder="Search diseases or symptoms..." 
                className="w-full bg-white border border-slate-100 rounded-2xl py-4 pl-12 pr-4 shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            {filteredDiseases.length > 0 ? (
              filteredDiseases.map(d => (
                <button
                  key={d.id}
                  onClick={() => setSelected(d)}
                  className="w-full bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between text-left hover:bg-slate-50 transition-all"
                >
                  <div>
                    <h3 className="font-bold text-slate-800">{d.name}</h3>
                    <p className="text-slate-400 text-xs truncate max-w-[200px]">{d.symptoms}</p>
                  </div>
                  <ChevronRight className="text-slate-300" size={20} />
                </button>
              ))
            ) : (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                  <BookOpen size={32} />
                </div>
                <p className="text-slate-400">No diseases found matching "{searchQuery}"</p>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm space-y-8">
              <h2 className="text-3xl font-black text-emerald-600">{selected.name}</h2>
              
              <Section title="Causes" content={selected.causes} color="text-blue-600" bg="bg-blue-50" />
              <Section title="Symptoms" content={selected.symptoms} color="text-orange-600" bg="bg-orange-50" />
              <Section title="Prevention" content={selected.prevention} color="text-emerald-600" bg="bg-emerald-50" />
              <Section title="Treatment" content={selected.treatment} color="text-purple-600" bg="bg-purple-50" />
            </div>

            <button
              onClick={() => setSelected(null)}
              className="w-full bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl"
            >
              Back to Library
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Section({ title, content, color, bg }: { title: string; content: string; color: string; bg: string }) {
  return (
    <div className="space-y-2">
      <h4 className={`text-xs font-black uppercase tracking-widest ${color} ${bg} px-3 py-1 rounded-lg inline-block`}>{title}</h4>
      <p className="text-slate-700 font-medium leading-relaxed">{content}</p>
    </div>
  );
}
