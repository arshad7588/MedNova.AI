import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Scan, Camera, Upload, Info, CheckCircle2, AlertTriangle, Bell, Check } from 'lucide-react';
import { logActivity } from '../utils/activityLogger';
import { addMedicineWithAI } from '../services/medicineService';
import { enhancedScanMedicine } from '../services/gemini';
import ReadMore from '../components/ReadMore';
import { useSettings } from '../context/SettingsContext';
import { motion, AnimatePresence } from 'motion/react';

export default function MedicineScanner() {
  const navigate = useNavigate();
  const { language } = useSettings();
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [showReminderModal, setShowReminderModal] = useState(false);
  const [scanDetails, setScanDetails] = useState<{
    medicineName?: string;
    genericName?: string;
    confidenceScore?: number;
    reasoning?: string;
    description?: string;
  } | null>(null);

  const [scannedMedicine, setScannedMedicine] = useState<any>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!image) return;
    
    setLoading(true);
    setResult('');
    setScanDetails(null);
    try {
      const jsonStr = await enhancedScanMedicine(image, language);
      const parsed = JSON.parse(jsonStr || "{}");
      
      if (parsed.status === 'RE_UPLOAD_REQUIRED') {
        setResult('Could not identify medicine even after deep scanning and search. Please try a clearer photo with better lighting.');
        setScanDetails({
          reasoning: "The image was too blurry or the label was obscured. I couldn't find a match even with Google Search."
        });
        return;
      }

      setScanDetails(parsed);

      // Try to extract medicine name from the scan result
      const medicine = await addMedicineWithAI(parsed.medicineName || parsed.description || 'Unknown', image);
      setScannedMedicine({
        ...medicine,
        confidenceScore: parsed.confidenceScore || 0
      });
      
      // Log activity
      logActivity('Medicine Scanner', `Scanned and identified: ${medicine.genericName}`, `Saved to database with ID: ${medicine.id}`);
      
      // Show reminder suggestion modal instead of immediate redirect
      setShowReminderModal(true);
    } catch (error: any) {
      console.error("Medicine Scan Error:", error);
      let errorMessage = "Error scanning medicine. Please try again. 💊";
      
      if (error?.message?.includes('PERMISSION_DENIED') || error?.status === 'PERMISSION_DENIED' || error?.status === 403) {
        errorMessage = "I don't have permission to access the AI service. This usually means the API key is invalid or lacks permissions. Please check your settings.";
      } else if (error?.message?.includes('quota') || error?.message?.includes('limit')) {
        errorMessage = "The AI service is currently at its limit. Please try again in a few minutes. 💊";
      }

      setResult(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      <header className="bg-white p-4 border-b border-slate-200 flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="text-slate-600">
          <ArrowLeft size={24} />
        </button>
        <h1 className="font-bold text-slate-900">Medicine Scanner</h1>
      </header>

      <div className="p-6 space-y-6">
        {!result ? (
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <div className="aspect-square bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center overflow-hidden relative">
              {image ? (
                <img src={image} alt="Preview" className="w-full h-full object-cover" />
              ) : (
                <>
                  <Camera size={48} className="text-slate-300 mb-2" />
                  <p className="text-slate-400 text-sm">Take a photo of the medicine</p>
                </>
              )}
              <input 
                type="file" 
                accept="image/*" 
                capture="environment"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleImageUpload}
              />
            </div>

            <div className="flex gap-4">
              <label className="flex-1 bg-slate-100 text-slate-700 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 cursor-pointer">
                <Upload size={20} /> Upload
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
              </label>
              <button
                onClick={handleScan}
                disabled={!image || loading}
                className="flex-[2] bg-purple-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-purple-100 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>Deep Scanning...</span>
                  </div>
                ) : (
                  <><Scan size={20} /> Scan Medicine</>
                )}
              </button>
            </div>

            <div className="bg-blue-50 p-4 rounded-2xl flex gap-3 text-blue-800 text-xs border border-blue-100">
              <Info size={18} className="shrink-0" />
              <p>Ensure the medicine name and label are clearly visible in the photo for accurate detection.</p>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className={`bg-white p-6 rounded-3xl border ${result.includes('Error') || result.includes('Could not') ? 'border-red-100' : 'border-slate-100'} shadow-sm prose prose-slate max-w-none`}>
              <div className={`flex items-center gap-2 ${result.includes('Error') || result.includes('Could not') ? 'text-red-600' : 'text-purple-600'} mb-4`}>
                {result.includes('Error') || result.includes('Could not') ? (
                  <AlertTriangle size={24} />
                ) : (
                  <CheckCircle2 size={24} />
                )}
                <h2 className="font-bold text-lg m-0">
                  {result.includes('Error') || result.includes('Could not') ? 'Scan Failed' : 'Medicine Details'}
                </h2>
              </div>
              <p className={result.includes('Error') || result.includes('Could not') ? 'text-red-600' : 'text-slate-700'}>
                {result}
              </p>

              {(result.includes('Error') || result.includes('Could not')) && (
                <div className="mt-6 space-y-4 bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                    <Info size={16} className="text-purple-600" />
                    Tips for a Better Scan
                  </h3>
                  <ul className="text-xs text-slate-600 space-y-2 list-disc pl-4">
                    <li>Ensure the medicine name is clearly visible.</li>
                    <li>Avoid glares or shadows on the packaging.</li>
                    <li>Hold the phone steady to avoid blur.</li>
                    <li>Use good lighting (natural light is best).</li>
                    <li>Try scanning the back or side of the pack if the front is unclear.</li>
                  </ul>
                </div>
              )}

              {scanDetails && !result.includes('Error') && !result.includes('Could not') && (
                <div className="mt-6 space-y-4 border-t border-slate-100 pt-6">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">AI Confidence</span>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full ${
                            (scanDetails.confidenceScore || 0) > 80 ? 'bg-emerald-500' : 
                            (scanDetails.confidenceScore || 0) > 50 ? 'bg-amber-500' : 'bg-rose-500'
                          }`}
                          style={{ width: `${scanDetails.confidenceScore || 0}%` }}
                        />
                      </div>
                      <span className="text-sm font-bold text-slate-700">{scanDetails.confidenceScore || 0}%</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Reasoning</span>
                    <p className="text-sm text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 italic">
                      "{scanDetails.reasoning}"
                    </p>
                  </div>

                  {scanDetails.description && (
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">AI Description</span>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {scanDetails.description}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
            <button
              onClick={() => { setResult(null); setImage(null); }}
              className="w-full bg-slate-200 text-slate-700 font-bold py-4 rounded-2xl"
            >
              Scan Another
            </button>
          </div>
        )}
      </div>

      {/* Reminder Suggestion Modal */}
      <AnimatePresence>
        {showReminderModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
              onClick={() => {
                setShowReminderModal(false);
                if (scannedMedicine) navigate(`/medicine/${scannedMedicine.id}`);
              }}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 relative z-10 shadow-2xl border border-slate-100"
            >
              <div className="w-20 h-20 bg-purple-100 rounded-3xl flex items-center justify-center text-purple-600 mx-auto mb-6">
                <Bell size={40} className="animate-bounce" />
              </div>
              
              <div className="text-center space-y-3 mb-8">
                <h3 className="text-2xl font-black text-slate-900 tracking-tight">Add to Reminders?</h3>
                <div className="flex flex-col items-center gap-2">
                  <p className="text-slate-500 text-sm leading-relaxed">
                    We've successfully identified <strong>{scannedMedicine?.name}</strong>.
                  </p>
                  <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 border border-emerald-100 rounded-full">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">
                      {scannedMedicine?.confidenceScore}% AI Accuracy
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => navigate('/reminders', { state: { medicine: scannedMedicine } })}
                  className="w-full bg-purple-600 text-white font-black py-4 rounded-2xl shadow-lg shadow-purple-200 flex items-center justify-center gap-2 active:scale-95 transition-transform"
                >
                  <Check size={20} /> Yes, Set Reminder
                </button>
                <button
                  onClick={() => {
                    setShowReminderModal(false);
                    if (scannedMedicine) navigate(`/medicine/${scannedMedicine.id}`);
                  }}
                  className="w-full bg-slate-100 text-slate-600 font-bold py-4 rounded-2xl active:scale-95 transition-transform"
                >
                  No, Just View Details
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
