import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import ErrorBoundary from './components/ErrorBoundary';

import { PharmacyProvider } from './contexts/PharmacyContext';

// Pages
import Welcome from './pages/Welcome';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './pages/Home';
import Profile from './pages/Profile';
import PatientProfile from './pages/PatientProfile';
import HealthAssistant from './pages/HealthAssistant';
import SymptomChecker from './pages/SymptomChecker';
import MedicineScanner from './pages/MedicineScanner';
import MedicineDetail from './pages/MedicineDetail';
import MedicineHistory from './pages/MedicineHistory';
import PrescriptionScanner from './pages/PrescriptionScanner';
import DrugInteraction from './pages/DrugInteraction';
import Reminders from './pages/Reminders';
import HealthCalculators from './pages/HealthCalculators';
import NearbyFacilities from './pages/NearbyFacilities';
import FirstAid from './pages/FirstAid';
import DiseaseLibrary from './pages/DiseaseLibrary';
import HealthRecords from './pages/HealthRecords';
import GlobalMedicineSearch from './pages/GlobalMedicineSearch';
import Settings from './pages/Settings';
import DoctorPrescribe from './pages/DoctorPrescribe';
import PharmacyOrders from './pages/PharmacyOrders';
import PharmacyInventory from './pages/PharmacyInventory';
import DoctorAppointments from './pages/DoctorAppointments';
import PharmacistDashboard from './pages/PharmacistDashboard';

export default function App() {
  return (
    <ErrorBoundary>
      <Router>
        <PharmacyProvider>
          <Layout>
            <Routes>
              <Route path="/" element={<Welcome />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              
              <Route path="/home" element={<ProtectedRoute><Home /></ProtectedRoute>} />
              <Route path="/pharmacist/*" element={<ProtectedRoute><PharmacistDashboard /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/patient-profile" element={<ProtectedRoute><PatientProfile /></ProtectedRoute>} />
            <Route path="/assistant" element={<ProtectedRoute><HealthAssistant /></ProtectedRoute>} />
            <Route path="/symptoms" element={<ProtectedRoute><SymptomChecker /></ProtectedRoute>} />
            <Route path="/scanner" element={<ProtectedRoute><MedicineScanner /></ProtectedRoute>} />
            <Route path="/medicines" element={<ProtectedRoute><MedicineHistory /></ProtectedRoute>} />
            <Route path="/medicine/:id" element={<ProtectedRoute><MedicineDetail /></ProtectedRoute>} />
            <Route path="/prescription" element={<ProtectedRoute><PrescriptionScanner /></ProtectedRoute>} />
            <Route path="/interactions" element={<ProtectedRoute><DrugInteraction /></ProtectedRoute>} />
            <Route path="/reminders" element={<ProtectedRoute><Reminders /></ProtectedRoute>} />
            <Route path="/calculators" element={<ProtectedRoute><HealthCalculators /></ProtectedRoute>} />
            <Route path="/facilities" element={<ProtectedRoute><NearbyFacilities /></ProtectedRoute>} />
            <Route path="/first-aid" element={<ProtectedRoute><FirstAid /></ProtectedRoute>} />
            <Route path="/library" element={<ProtectedRoute><DiseaseLibrary /></ProtectedRoute>} />
            <Route path="/records" element={<ProtectedRoute><HealthRecords /></ProtectedRoute>} />
            <Route path="/global-search" element={<ProtectedRoute><GlobalMedicineSearch /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
            <Route path="/doctor/prescribe" element={<ProtectedRoute><DoctorPrescribe /></ProtectedRoute>} />
            <Route path="/pharmacy/orders" element={<ProtectedRoute><PharmacyOrders /></ProtectedRoute>} />
            <Route path="/pharmacy/inventory" element={<ProtectedRoute><PharmacyInventory /></ProtectedRoute>} />
            <Route path="/doctor/appointments" element={<ProtectedRoute><DoctorAppointments /></ProtectedRoute>} />
          </Routes>
        </Layout>
      </PharmacyProvider>
    </Router>
  </ErrorBoundary>
  );
}
