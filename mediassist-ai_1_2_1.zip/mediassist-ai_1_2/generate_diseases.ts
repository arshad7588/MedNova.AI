import { GoogleGenAI, Type } from "@google/genai";
import fs from 'fs';
import path from 'path';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

async function run() {
  console.log("Generating diseases...");
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a JSON array of exactly 100 different medical diseases. Each disease should have the following string properties: 'id' (kebab-case), 'name', 'causes', 'symptoms', 'prevention', 'treatment'. Make the descriptions concise (1 sentence max per field). Do not include common ones like diabetes, hypertension, asthma, flu, cold, pneumonia.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              name: { type: Type.STRING },
              causes: { type: Type.STRING },
              symptoms: { type: Type.STRING },
              prevention: { type: Type.STRING },
              treatment: { type: Type.STRING }
            },
            required: ["id", "name", "causes", "symptoms", "prevention", "treatment"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No text returned");
    const diseases = JSON.parse(text);
    fs.mkdirSync(path.join(process.cwd(), 'src/data'), { recursive: true });
    fs.writeFileSync(path.join(process.cwd(), 'src/data/extra_diseases.json'), JSON.stringify(diseases, null, 2));
    console.log(`Generated ${diseases.length} diseases.`);
  } catch (e) {
    console.error("Error generating diseases:", e);
  }
}

run();
